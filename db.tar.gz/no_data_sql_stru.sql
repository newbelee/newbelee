-- MySQL dump 10.13  Distrib 5.6.27, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: sqlmonitordb
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='de94d50e-fb59-11e7-bf35-000c29903c5f:1-5380';

--
-- Current Database: `sqlmonitordb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sqlmonitordb` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `sqlmonitordb`;

--
-- Table structure for table `alert_cf_dba_duty`
--

DROP TABLE IF EXISTS `alert_cf_dba_duty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_dba_duty` (
  `domain_name` varchar(64) DEFAULT NULL,
  `member_name` varchar(64) NOT NULL,
  `work_type` tinyint(4) DEFAULT NULL,
  `work_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_group`
--

DROP TABLE IF EXISTS `alert_cf_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_group` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(64) NOT NULL,
  `group_desc` varchar(128) NOT NULL,
  `main_group_id` int(11) NOT NULL DEFAULT '-1',
  `isvalid` int(11) NOT NULL DEFAULT '1',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`),
  KEY `idx_groupname` (`group_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_group_member`
--

DROP TABLE IF EXISTS `alert_cf_group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_group_member` (
  `group_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expire_time` datetime NOT NULL DEFAULT '1900-01-01 00:00:00',
  PRIMARY KEY (`group_id`,`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_jobinfo`
--

DROP TABLE IF EXISTS `alert_cf_jobinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_jobinfo` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_code` varchar(128) NOT NULL,
  `job_name` varchar(256) NOT NULL,
  `job_type` smallint(6) NOT NULL DEFAULT '0',
  `machine_name` varchar(64) NOT NULL DEFAULT '',
  `service_name` varchar(64) NOT NULL DEFAULT '',
  `isvalid` int(11) NOT NULL DEFAULT '1',
  `job_remedy_status` char(1) NOT NULL DEFAULT 'F',
  `job_sms_status` char(1) NOT NULL DEFAULT 'F',
  `job_owner` varchar(128) NOT NULL DEFAULT 'DBA',
  `job_team` varchar(64) NOT NULL DEFAULT '数据库运维组',
  `job_deal` varchar(128) DEFAULT NULL,
  `job_schedule` varchar(256) NOT NULL DEFAULT '',
  `job_desc` varchar(512) NOT NULL DEFAULT '',
  `job_timeout` smallint(6) NOT NULL DEFAULT '10',
  `job_sendinterval` smallint(5) unsigned NOT NULL DEFAULT '10',
  `job_period` smallint(5) unsigned NOT NULL DEFAULT '1440',
  `is_diffmachine` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `is_pdsplit` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operator` varchar(64) NOT NULL DEFAULT 'admin',
  `maint_timestamp` timestamp NOT NULL DEFAULT '2013-12-31 16:00:00',
  `sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`job_id`),
  UNIQUE KEY `idx_jobcode` (`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_jobinfo_v1`
--

DROP TABLE IF EXISTS `alert_cf_jobinfo_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_jobinfo_v1` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_code` varchar(128) NOT NULL,
  `job_name` varchar(256) NOT NULL,
  `job_type` smallint(6) NOT NULL DEFAULT '0',
  `machine_name` varchar(64) NOT NULL DEFAULT '',
  `service_name` varchar(64) NOT NULL DEFAULT '',
  `isvalid` int(11) NOT NULL DEFAULT '1',
  `job_remedy_status` char(1) NOT NULL DEFAULT 'F',
  `job_email_status` char(1) NOT NULL,
  `job_sms_status` char(1) NOT NULL DEFAULT 'F',
  `job_owner` varchar(128) NOT NULL DEFAULT 'DBA',
  `job_team` varchar(64) NOT NULL DEFAULT '数据库运维组',
  `job_deal` varchar(128) DEFAULT NULL,
  `job_schedule` varchar(256) NOT NULL DEFAULT '',
  `job_desc` varchar(512) NOT NULL DEFAULT '',
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `operator` varchar(64) NOT NULL DEFAULT 'admin',
  `maint_timestamp` timestamp NOT NULL DEFAULT '2013-12-31 16:00:00',
  `job_sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`job_id`),
  UNIQUE KEY `idx_jobcode` (`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_member`
--

DROP TABLE IF EXISTS `alert_cf_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_member` (
  `member_id` int(11) NOT NULL,
  `member_name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `mobile` char(11) DEFAULT NULL,
  `email_status` char(1) NOT NULL,
  `mobile_status` char(1) NOT NULL,
  `dept_name` varchar(64) NOT NULL DEFAULT 'unknown',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_program`
--

DROP TABLE IF EXISTS `alert_cf_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_program` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(64) NOT NULL,
  `program_status` int(11) NOT NULL DEFAULT '1',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `id_programname` (`program_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_receiver`
--

DROP TABLE IF EXISTS `alert_cf_receiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_receiver` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `upgrade_typeid` smallint(6) NOT NULL DEFAULT '1',
  `upgrade_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `email_status` char(1) NOT NULL,
  `mobile_status` char(1) NOT NULL,
  `expire_time` datetime NOT NULL DEFAULT '1900-01-01 00:00:00',
  PRIMARY KEY (`upgrade_typeid`,`upgrade_id`,`member_id`),
  UNIQUE KEY `ix_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_receiver_v1`
--

DROP TABLE IF EXISTS `alert_cf_receiver_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_receiver_v1` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `upgrade_typeid` smallint(6) NOT NULL DEFAULT '1',
  `upgrade_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `rec_email_status` char(1) NOT NULL,
  `rec_sms_status` char(1) NOT NULL,
  `expire_time` datetime NOT NULL DEFAULT '1900-01-01 00:00:00',
  PRIMARY KEY (`upgrade_typeid`,`upgrade_id`,`member_id`),
  UNIQUE KEY `ix_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_script_exectime`
--

DROP TABLE IF EXISTS `alert_cf_script_exectime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_script_exectime` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `object_name` varchar(64) NOT NULL,
  `begin_time` datetime(3) DEFAULT NULL,
  `end_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`rid`),
  UNIQUE KEY `ix_u_object` (`object_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_sms_whitelist`
--

DROP TABLE IF EXISTS `alert_cf_sms_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_sms_whitelist` (
  `source` varchar(12) NOT NULL,
  `job_id` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `ci_code` varchar(64) NOT NULL DEFAULT '',
  `job_code` varchar(128) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`source`,`job_id`,`error_typeid`,`ci_code`),
  KEY `ix_source_id` (`source`,`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_template_jobinfo`
--

DROP TABLE IF EXISTS `alert_cf_template_jobinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_template_jobinfo` (
  `template_id` int(11) NOT NULL,
  `job_name` varchar(128) NOT NULL,
  `code_` int(11) NOT NULL DEFAULT '1',
  `isvalid` int(11) NOT NULL DEFAULT '1',
  `job_remedy_status` char(1) NOT NULL DEFAULT 'F',
  `job_sms_status` char(1) NOT NULL DEFAULT 'F',
  `job_owner` varchar(128) NOT NULL DEFAULT 'DBA',
  `job_team` varchar(64) NOT NULL DEFAULT '数据库运维组',
  `job_deal` varchar(128) DEFAULT NULL,
  `job_timeout` smallint(6) NOT NULL DEFAULT '10',
  `job_sendinterval` smallint(5) unsigned NOT NULL DEFAULT '10',
  `job_period` smallint(5) unsigned NOT NULL DEFAULT '1440',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `ix_job_name` (`job_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_template_upgrade`
--

DROP TABLE IF EXISTS `alert_cf_template_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_template_upgrade` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `level_id` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `bubble_status` char(1) NOT NULL DEFAULT 'F',
  `remedy_status` char(1) NOT NULL DEFAULT 'F',
  `email_status` char(1) NOT NULL DEFAULT 'F',
  `sms_status` char(1) NOT NULL DEFAULT 'F',
  `member_list` varchar(256) NOT NULL,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  UNIQUE KEY `ix_job_name` (`template_id`,`error_typeid`,`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade`
--

DROP TABLE IF EXISTS `alert_cf_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `level_id` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `bubble_status` char(1) NOT NULL DEFAULT 'F',
  `remedy_status` char(1) NOT NULL DEFAULT 'F',
  `email_status` char(1) NOT NULL DEFAULT 'F',
  `sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_subperiod` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`upgrade_id`),
  UNIQUE KEY `uidx_job_errortype_level` (`job_id`,`error_typeid`,`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade_dbtype`
--

DROP TABLE IF EXISTS `alert_cf_upgrade_dbtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade_dbtype` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `db_type` varchar(16) NOT NULL,
  `env_type` varchar(16) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `level_id` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `bubble_status` char(1) NOT NULL DEFAULT 'F',
  `remedy_status` char(1) NOT NULL DEFAULT 'F',
  `email_status` char(1) NOT NULL DEFAULT 'F',
  `sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_subperiod` smallint(5) unsigned DEFAULT NULL,
  `sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`upgrade_id`),
  UNIQUE KEY `uidx_job_errortype_level` (`job_id`,`db_type`,`env_type`,`error_typeid`,`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade_dbtype_v1`
--

DROP TABLE IF EXISTS `alert_cf_upgrade_dbtype_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade_dbtype_v1` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `db_type` varchar(16) NOT NULL,
  `env_type` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `alert_sendinterval` smallint(5) unsigned NOT NULL DEFAULT '10',
  `alert_period` smallint(5) unsigned NOT NULL DEFAULT '1440',
  `upg_remedy_status` char(1) NOT NULL DEFAULT 'F',
  `upg_email_status` char(1) NOT NULL DEFAULT 'F',
  `upg_sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_subperiod` smallint(5) unsigned DEFAULT NULL,
  `upg_sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`upgrade_id`,`upg_sms_alwayson`),
  UNIQUE KEY `uidx_job_errortype_level` (`job_id`,`db_type`,`env_type`,`error_typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade_pdservice`
--

DROP TABLE IF EXISTS `alert_cf_upgrade_pdservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade_pdservice` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `service_name` varchar(64) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `email_status` char(1) NOT NULL DEFAULT 'F',
  `sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`upgrade_id`),
  UNIQUE KEY `uidx_job_errortype` (`job_id`,`service_name`,`error_typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade_pdservice_v1`
--

DROP TABLE IF EXISTS `alert_cf_upgrade_pdservice_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade_pdservice_v1` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `service_name` varchar(64) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `alert_sendinterval` smallint(5) unsigned NOT NULL DEFAULT '10',
  `alert_period` smallint(5) unsigned NOT NULL DEFAULT '1440',
  `email_status` char(1) NOT NULL DEFAULT 'F',
  `sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_subperiod` smallint(5) unsigned DEFAULT NULL,
  `sms_alwayson` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`upgrade_id`),
  UNIQUE KEY `uidx_job_errortype` (`job_id`,`service_name`,`error_typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_cf_upgrade_v1`
--

DROP TABLE IF EXISTS `alert_cf_upgrade_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_cf_upgrade_v1` (
  `upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `alert_count` int(10) unsigned NOT NULL,
  `alert_sendinterval` smallint(5) unsigned NOT NULL DEFAULT '10',
  `alert_period` smallint(5) unsigned NOT NULL DEFAULT '1440',
  `upg_remedy_status` char(1) NOT NULL DEFAULT 'F',
  `upg_email_status` char(1) NOT NULL DEFAULT 'F',
  `upg_sms_status` char(1) NOT NULL DEFAULT 'F',
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `job_subperiod` smallint(5) unsigned DEFAULT NULL,
  `upg_sms_alwayson` smallint(5) DEFAULT NULL,
  PRIMARY KEY (`upgrade_id`),
  UNIQUE KEY `uidx_job_errortype_level` (`job_id`,`error_typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_alertsendwait`
--

DROP TABLE IF EXISTS `alert_data_alertsendwait`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_alertsendwait` (
  `alert_msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(64) NOT NULL,
  `service_name` varchar(64) NOT NULL,
  `db_type` varchar(16) NOT NULL DEFAULT 'unknown',
  `env_type` varchar(16) NOT NULL DEFAULT 'unknown',
  `ci_code` varchar(64) NOT NULL,
  `data_source` varchar(64) NOT NULL,
  `job_id` int(11) NOT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `job_type` smallint(6) NOT NULL,
  `job_stepid` int(11) NOT NULL,
  `error_typeid` smallint(5) unsigned NOT NULL,
  `level_id` smallint(5) unsigned NOT NULL,
  `code_` smallint(6) NOT NULL DEFAULT '0',
  `counts` int(11) NOT NULL DEFAULT '1',
  `period` smallint(6) NOT NULL DEFAULT '0',
  `upgrade_typeid` smallint(6) NOT NULL DEFAULT '0',
  `send_typeid` smallint(6) NOT NULL,
  `send_status` smallint(6) NOT NULL,
  `send_errormsg` varchar(200) DEFAULT NULL,
  `send_filtertypeid` smallint(6) NOT NULL DEFAULT '0',
  `send_begintime` datetime(3) NOT NULL,
  `send_endtime` datetime(3) DEFAULT NULL,
  `send_remedy` varchar(64) NOT NULL,
  `send_emaillist` varchar(2000) NOT NULL,
  `send_mobilelist` varchar(1200) NOT NULL,
  `msg_createtime` datetime(3) NOT NULL,
  `msg_type` varchar(16) DEFAULT NULL,
  `msg_email` mediumtext NOT NULL,
  `msg_sms` varchar(2000) NOT NULL,
  `msg_subject` varchar(256) NOT NULL,
  `msg_sendername` varchar(64) DEFAULT NULL,
  `msg_sendermail` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`alert_msgid`,`msg_createtime`),
  KEY `idx_sendid` (`send_status`,`send_typeid`,`send_filtertypeid`),
  KEY `idx_jobid` (`job_id`,`error_typeid`,`machine_name`,`send_typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(msg_createtime)
(PARTITION p20160723 VALUES LESS THAN ('2016-07-24') ENGINE = InnoDB,
 PARTITION p20160724 VALUES LESS THAN ('2016-07-25') ENGINE = InnoDB,
 PARTITION p20160725 VALUES LESS THAN ('2016-07-26') ENGINE = InnoDB,
 PARTITION p20160726 VALUES LESS THAN ('2016-07-27') ENGINE = InnoDB,
 PARTITION p20160727 VALUES LESS THAN ('2016-07-28') ENGINE = InnoDB,
 PARTITION p20160728 VALUES LESS THAN ('2016-07-29') ENGINE = InnoDB,
 PARTITION p20160729 VALUES LESS THAN ('2016-07-30') ENGINE = InnoDB,
 PARTITION p20160730 VALUES LESS THAN ('2016-07-31') ENGINE = InnoDB,
 PARTITION p20160731 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p20160801 VALUES LESS THAN ('2016-08-02') ENGINE = InnoDB,
 PARTITION p20160802 VALUES LESS THAN ('2016-08-03') ENGINE = InnoDB,
 PARTITION p20160803 VALUES LESS THAN ('2016-08-04') ENGINE = InnoDB,
 PARTITION p20160804 VALUES LESS THAN ('2016-08-05') ENGINE = InnoDB,
 PARTITION p20160805 VALUES LESS THAN ('2016-08-06') ENGINE = InnoDB,
 PARTITION p20160806 VALUES LESS THAN ('2016-08-07') ENGINE = InnoDB,
 PARTITION p20160807 VALUES LESS THAN ('2016-08-08') ENGINE = InnoDB,
 PARTITION p20160808 VALUES LESS THAN ('2016-08-09') ENGINE = InnoDB,
 PARTITION p20160809 VALUES LESS THAN ('2016-08-10') ENGINE = InnoDB,
 PARTITION p20160810 VALUES LESS THAN ('2016-08-11') ENGINE = InnoDB,
 PARTITION p20160811 VALUES LESS THAN ('2016-08-12') ENGINE = InnoDB,
 PARTITION p20160812 VALUES LESS THAN ('2016-08-13') ENGINE = InnoDB,
 PARTITION p20160813 VALUES LESS THAN ('2016-08-14') ENGINE = InnoDB,
 PARTITION p20160814 VALUES LESS THAN ('2016-08-15') ENGINE = InnoDB,
 PARTITION p20160815 VALUES LESS THAN ('2016-08-16') ENGINE = InnoDB,
 PARTITION p20160816 VALUES LESS THAN ('2016-08-17') ENGINE = InnoDB,
 PARTITION p20160817 VALUES LESS THAN ('2016-08-18') ENGINE = InnoDB,
 PARTITION p20160818 VALUES LESS THAN ('2016-08-19') ENGINE = InnoDB,
 PARTITION p20160819 VALUES LESS THAN ('2016-08-20') ENGINE = InnoDB,
 PARTITION p20160820 VALUES LESS THAN ('2016-08-21') ENGINE = InnoDB,
 PARTITION p20160821 VALUES LESS THAN ('2016-08-22') ENGINE = InnoDB,
 PARTITION p20160822 VALUES LESS THAN ('2016-08-23') ENGINE = InnoDB,
 PARTITION p20160823 VALUES LESS THAN ('2016-08-24') ENGINE = InnoDB,
 PARTITION p20160824 VALUES LESS THAN ('2016-08-25') ENGINE = InnoDB,
 PARTITION p20160825 VALUES LESS THAN ('2016-08-26') ENGINE = InnoDB,
 PARTITION p20160826 VALUES LESS THAN ('2016-08-27') ENGINE = InnoDB,
 PARTITION p20160827 VALUES LESS THAN ('2016-08-28') ENGINE = InnoDB,
 PARTITION p20160828 VALUES LESS THAN ('2016-08-29') ENGINE = InnoDB,
 PARTITION p20160829 VALUES LESS THAN ('2016-08-30') ENGINE = InnoDB,
 PARTITION p20160830 VALUES LESS THAN ('2016-08-31') ENGINE = InnoDB,
 PARTITION p20160831 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN ('2016-09-02') ENGINE = InnoDB,
 PARTITION p20160902 VALUES LESS THAN ('2016-09-03') ENGINE = InnoDB,
 PARTITION p20160903 VALUES LESS THAN ('2016-09-04') ENGINE = InnoDB,
 PARTITION p20160904 VALUES LESS THAN ('2016-09-05') ENGINE = InnoDB,
 PARTITION p20160905 VALUES LESS THAN ('2016-09-06') ENGINE = InnoDB,
 PARTITION p20160906 VALUES LESS THAN ('2016-09-07') ENGINE = InnoDB,
 PARTITION p20160907 VALUES LESS THAN ('2016-09-08') ENGINE = InnoDB,
 PARTITION p20160908 VALUES LESS THAN ('2016-09-09') ENGINE = InnoDB,
 PARTITION p20160909 VALUES LESS THAN ('2016-09-10') ENGINE = InnoDB,
 PARTITION p20160910 VALUES LESS THAN ('2016-09-11') ENGINE = InnoDB,
 PARTITION p20160911 VALUES LESS THAN ('2016-09-12') ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN ('2016-09-13') ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN ('2016-09-14') ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_alertsendwait_speedmsg`
--

DROP TABLE IF EXISTS `alert_data_alertsendwait_speedmsg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_alertsendwait_speedmsg` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `status_` int(11) NOT NULL DEFAULT '0',
  `machine_name` varchar(64) NOT NULL,
  `service_name` varchar(64) NOT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `send_typeid` smallint(6) NOT NULL,
  `send_emaillist` varchar(2000) NOT NULL,
  `send_mobilelist` varchar(1200) NOT NULL,
  `msg_createtime` datetime(3) NOT NULL,
  `msg_email` mediumtext NOT NULL,
  `msg_sms` mediumtext NOT NULL,
  `msg_subject` varchar(256) NOT NULL,
  `msg_sendername` varchar(64) DEFAULT NULL,
  `msg_sendermail` varchar(64) DEFAULT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`rid`,`msg_createtime`),
  KEY `ix_status_` (`status_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(msg_createtime)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_alwayson_log`
--

DROP TABLE IF EXISTS `alert_data_alwayson_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_alwayson_log` (
  `ag_name` varchar(128) NOT NULL DEFAULT '',
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `db_name` varchar(128) NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `value` varchar(128) NOT NULL DEFAULT '',
  `is_alert` tinyint(4) DEFAULT NULL,
  `data_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  KEY `machine_name` (`machine_name`,`ag_name`,`data_time`),
  KEY `IDX2` (`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_block_log`
--

DROP TABLE IF EXISTS `alert_data_block_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_block_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `grade` int(11) DEFAULT NULL,
  `timecount` int(11) DEFAULT NULL,
  `blockcount` int(11) DEFAULT NULL,
  `maxduration` int(11) DEFAULT NULL,
  `maxtime` datetime DEFAULT NULL,
  `alerttime` datetime DEFAULT NULL,
  `sendstatus` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `service_name` (`service_name`,`alerttime`),
  KEY `machine_name` (`machine_name`,`alerttime`),
  KEY `alerttime` (`alerttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_bubble_incident`
--

DROP TABLE IF EXISTS `alert_data_bubble_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_bubble_incident` (
  `bubble_msggid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ci_code` varchar(64) DEFAULT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `sms_flag` int(11) NOT NULL DEFAULT '0',
  `start_time` datetime(3) NOT NULL,
  `last_time` datetime(3) NOT NULL,
  `assign_time` datetime(3) DEFAULT NULL,
  `solve_time` datetime(3) DEFAULT NULL,
  `close_time` datetime(3) DEFAULT NULL,
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `incident_id` varchar(20) DEFAULT NULL,
  `modify_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `alert_msgid` int(10) unsigned NOT NULL,
  `counts` int(11) NOT NULL DEFAULT '1',
  `operator` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`bubble_msggid`),
  KEY `ix_status_alert` (`alert_status`,`ci_code`,`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_bubble_message`
--

DROP TABLE IF EXISTS `alert_data_bubble_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_bubble_message` (
  `bubble_msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bubble_msggid` int(10) unsigned DEFAULT NULL,
  `alert_msgid` int(10) unsigned DEFAULT NULL,
  `ci_code` varchar(64) DEFAULT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `service_name` varchar(64) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(16) DEFAULT NULL,
  `job_type` smallint(6) DEFAULT NULL,
  `send_bubble` varchar(64) DEFAULT NULL,
  `send_mobilelist` varchar(1200) NOT NULL,
  `msg_createtime` datetime(3) DEFAULT NULL,
  `msg_type` varchar(16) DEFAULT NULL,
  `msg_subject` varchar(256) DEFAULT NULL,
  `msg` mediumtext,
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `alert_createtime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`bubble_msgid`,`alert_createtime`),
  KEY `idx_gid` (`bubble_msggid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(alert_createtime)
(PARTITION p20160601 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p20160701 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p20160801 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p20161101 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p20161201 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p20170101 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p20170201 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p20170301 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p20170401 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_bubble_operationlog`
--

DROP TABLE IF EXISTS `alert_data_bubble_operationlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_bubble_operationlog` (
  `bubble_logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bubble_msggid` int(10) unsigned NOT NULL,
  `rid` int(11) NOT NULL,
  `alert_status` char(1) NOT NULL,
  `log_content` text NOT NULL,
  `operator` varchar(64) NOT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`bubble_logid`),
  KEY `ix_bubble_msggid` (`bubble_msggid`,`alert_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_cluster_health`
--

DROP TABLE IF EXISTS `alert_data_cluster_health`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_cluster_health` (
  `batch_id` int(11) DEFAULT NULL,
  `win_cluster_name` varchar(128) DEFAULT NULL,
  `service_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `check_type` varchar(256) DEFAULT NULL,
  `ret` int(11) DEFAULT NULL,
  `message` varchar(4000) DEFAULT NULL,
  `checkdate` datetime DEFAULT NULL,
  `need_alert` int(11) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `batch_id` (`batch_id`),
  KEY `win_cluster_name` (`win_cluster_name`,`checkdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(checkdate)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_dbasys_autosendemailsms`
--

DROP TABLE IF EXISTS `alert_data_dbasys_autosendemailsms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_dbasys_autosendemailsms` (
  `id` int(11) NOT NULL,
  `send_user` varchar(64) DEFAULT NULL,
  `send_emaillist` varchar(2000) DEFAULT NULL,
  `send_mobilelist` varchar(1200) DEFAULT NULL,
  `status_` int(11) NOT NULL DEFAULT '0',
  `msg_subject` varchar(256) DEFAULT NULL,
  `msg` mediumtext NOT NULL,
  `msg_createtime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `msg_sendername` varchar(64) NOT NULL DEFAULT 'DBA管理系统',
  `msg_sendermail` varchar(64) NOT NULL DEFAULT 'DBA@ctrip.com',
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_job_lastsuccesstime`
--

DROP TABLE IF EXISTS `alert_data_job_lastsuccesstime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_job_lastsuccesstime` (
  `ci_code` varchar(64) NOT NULL,
  `job_code` varchar(128) NOT NULL DEFAULT '',
  `last_success_time` datetime NOT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ci_code`,`job_code`),
  KEY `ix_inserttime` (`insert_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_joblogic`
--

DROP TABLE IF EXISTS `alert_data_joblogic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_joblogic` (
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `errormessage` varchar(8000) DEFAULT NULL,
  `checktime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_longtimequery_control`
--

DROP TABLE IF EXISTS `alert_data_longtimequery_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_longtimequery_control` (
  `service_name` varchar(256) DEFAULT NULL,
  `machine_name` varchar(256) DEFAULT NULL,
  `alerttime` datetime DEFAULT NULL,
  `is_send` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_program_log`
--

DROP TABLE IF EXISTS `alert_data_program_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_program_log` (
  `program_name` varchar(64) NOT NULL,
  `machine_name` varchar(64) NOT NULL,
  `exec_flag` int(11) NOT NULL,
  `exec_time` datetime(3) NOT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  KEY `idx_flag_service` (`exec_flag`,`program_name`,`machine_name`),
  KEY `idx_time` (`exec_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(exec_time)
(PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_remedy_incident`
--

DROP TABLE IF EXISTS `alert_data_remedy_incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_remedy_incident` (
  `remedy_msggid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ci_code` varchar(64) DEFAULT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `sms_flag` int(11) NOT NULL DEFAULT '0',
  `start_time` datetime(3) NOT NULL,
  `last_time` datetime(3) NOT NULL,
  `assign_time` datetime(3) DEFAULT NULL,
  `solve_time` datetime(3) DEFAULT NULL,
  `close_time` datetime(3) DEFAULT NULL,
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `incident_id` varchar(20) DEFAULT NULL,
  `modify_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  `alert_msgid` int(10) unsigned NOT NULL,
  `counts` int(11) NOT NULL DEFAULT '1',
  `operator` varchar(64) DEFAULT NULL,
  `err_counts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`remedy_msggid`),
  KEY `ix_status_alert` (`alert_status`,`ci_code`,`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_remedy_message`
--

DROP TABLE IF EXISTS `alert_data_remedy_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_remedy_message` (
  `remedy_msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `remedy_msggid` int(10) unsigned DEFAULT NULL,
  `alert_msgid` int(10) unsigned DEFAULT NULL,
  `ci_code` varchar(64) DEFAULT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `service_name` varchar(64) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(16) DEFAULT NULL,
  `job_type` smallint(6) DEFAULT NULL,
  `send_remedy` varchar(64) DEFAULT NULL,
  `send_mobilelist` varchar(1200) NOT NULL,
  `msg_createtime` datetime(3) DEFAULT NULL,
  `msg_type` varchar(16) DEFAULT NULL,
  `msg_subject` varchar(256) DEFAULT NULL,
  `msg` mediumtext,
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `alert_createtime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`remedy_msgid`,`alert_createtime`),
  KEY `idx_gid` (`remedy_msggid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(alert_createtime)
(PARTITION p20160601 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p20160701 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p20160801 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p20161101 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p20161201 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p20170101 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p20170201 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p20170301 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p20170401 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_repl_delay_log`
--

DROP TABLE IF EXISTS `alert_data_repl_delay_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_repl_delay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `max_delay` int(11) DEFAULT NULL,
  `subscriber_time` datetime DEFAULT NULL,
  `alert_time` datetime DEFAULT NULL,
  `send_status` int(11) DEFAULT NULL,
  `batchid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_name` (`service_name`,`alert_time`),
  KEY `machine_name` (`machine_name`,`alert_time`),
  KEY `alert_time` (`alert_time`),
  KEY `batchid` (`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_repldelaycheck_monitor`
--

DROP TABLE IF EXISTS `alert_data_repldelaycheck_monitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_repldelaycheck_monitor` (
  `machine_name` varchar(128) DEFAULT NULL,
  `subscriber_db` varchar(128) DEFAULT NULL,
  `publisher` varchar(128) DEFAULT NULL,
  `publisher_db` varchar(128) DEFAULT NULL,
  `publication` varchar(128) DEFAULT NULL,
  `article` varchar(128) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_sqlmonitor_message`
--

DROP TABLE IF EXISTS `alert_data_sqlmonitor_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_sqlmonitor_message` (
  `sqlmonitor_msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(64) DEFAULT NULL,
  `data_source` varchar(64) NOT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `job_name` varchar(256) DEFAULT NULL,
  `job_stepid` int(11) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `msg_type` varchar(16) NOT NULL DEFAULT 'Error',
  `msg` mediumtext,
  `msg_subject` varchar(256) DEFAULT NULL,
  `msg_createtime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `msg_sendername` varchar(64) DEFAULT NULL,
  `msg_sendermail` varchar(64) DEFAULT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `data_source_env` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`sqlmonitor_msgid`,`msg_createtime`),
  KEY `idx_jobcode` (`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(msg_createtime)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_sqlmonitor_message_v1`
--

DROP TABLE IF EXISTS `alert_data_sqlmonitor_message_v1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_sqlmonitor_message_v1` (
  `sqlmonitor_msgid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(64) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `data_source` varchar(64) NOT NULL,
  `job_code` varchar(128) DEFAULT NULL,
  `job_name` varchar(256) DEFAULT NULL,
  `job_stepid` int(11) NOT NULL DEFAULT '0',
  `alert_status` char(1) NOT NULL DEFAULT 'W',
  `msg_type` varchar(16) NOT NULL DEFAULT 'Error',
  `msg` mediumtext,
  `msg_subject` varchar(256) DEFAULT NULL,
  `msg_createtime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `msg_sendername` varchar(64) DEFAULT NULL,
  `msg_sendermail` varchar(64) DEFAULT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `data_source_env` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`sqlmonitor_msgid`,`msg_createtime`),
  KEY `idx_jobcode` (`job_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(msg_createtime)
(PARTITION p20160619 VALUES LESS THAN ('2016-06-20') ENGINE = InnoDB,
 PARTITION p20160620 VALUES LESS THAN ('2016-06-21') ENGINE = InnoDB,
 PARTITION p20160621 VALUES LESS THAN ('2016-06-22') ENGINE = InnoDB,
 PARTITION p20160622 VALUES LESS THAN ('2016-06-23') ENGINE = InnoDB,
 PARTITION p20160623 VALUES LESS THAN ('2016-06-24') ENGINE = InnoDB,
 PARTITION p20160624 VALUES LESS THAN ('2016-06-25') ENGINE = InnoDB,
 PARTITION p20160625 VALUES LESS THAN ('2016-06-26') ENGINE = InnoDB,
 PARTITION p20160626 VALUES LESS THAN ('2016-06-27') ENGINE = InnoDB,
 PARTITION p20160627 VALUES LESS THAN ('2016-06-28') ENGINE = InnoDB,
 PARTITION p20160628 VALUES LESS THAN ('2016-06-29') ENGINE = InnoDB,
 PARTITION p20160629 VALUES LESS THAN ('2016-06-30') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_tracestatus`
--

DROP TABLE IF EXISTS `alert_data_tracestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_tracestatus` (
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `message` varchar(8000) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_tracetimecheck`
--

DROP TABLE IF EXISTS `alert_data_tracetimecheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_tracetimecheck` (
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `tabletoday` int(11) DEFAULT NULL,
  `maxtime` datetime DEFAULT NULL,
  `checktime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alert_data_tts`
--

DROP TABLE IF EXISTS `alert_data_tts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_data_tts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(256) DEFAULT NULL COMMENT '任务ID',
  `content` varchar(1000) NOT NULL COMMENT '自动外呼的放音内容，文本长度不超过500个中文字符，含标点符号',
  `phone_num` varchar(255) NOT NULL COMMENT '外呼电话号码列表，最多5个',
  `ob_result` int(11) DEFAULT '3' COMMENT '外呼结果“0” 表示成功，”1” 表示失败，“2” 表示任务撤销,"3" 未发送，"4" 已发送',
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `update_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `task_result` varchar(255) DEFAULT NULL COMMENT '''返回结果''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bak20160506_cf_db_level`
--

DROP TABLE IF EXISTS `bak20160506_cf_db_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bak20160506_cf_db_level` (
  `id` int(11) NOT NULL DEFAULT '0',
  `db_type` varchar(255) DEFAULT NULL,
  `env_type` varchar(255) DEFAULT NULL,
  `machine_name` varchar(255) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `dns` varchar(255) DEFAULT NULL,
  `DbticketUser` varchar(255) DEFAULT NULL,
  `ArchPortal` varchar(255) DEFAULT NULL,
  `db_name` varchar(255) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `db_status` varchar(255) DEFAULT NULL,
  `Server` varchar(255) DEFAULT NULL,
  `PDName` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `PDEmail` varchar(255) DEFAULT NULL,
  `Owner` varchar(255) DEFAULT NULL,
  `Remark` varchar(255) DEFAULT NULL,
  `Level` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bak20160506_cf_service`
--

DROP TABLE IF EXISTS `bak20160506_cf_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bak20160506_cf_service` (
  `service_name` varchar(64) NOT NULL,
  `dns` varchar(200) NOT NULL DEFAULT '',
  `dns_port` varchar(10) NOT NULL,
  `vip_service` varchar(16) DEFAULT NULL,
  `vip_backup` varchar(16) DEFAULT NULL,
  `dns_cname` varchar(256) DEFAULT '',
  `dns_arecord` varchar(256) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(32) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `maintain_batch` int(11) DEFAULT NULL,
  `maintain_type` varchar(16) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `dns_status` tinyint(4) NOT NULL DEFAULT '1',
  `available_status` tinyint(4) DEFAULT '1',
  `pd_name` varchar(32) DEFAULT '',
  `organization_id` int(11) DEFAULT NULL,
  `organization_code` varchar(24) DEFAULT NULL,
  `flag` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `capacity_details_mssql`
--

DROP TABLE IF EXISTS `capacity_details_mssql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capacity_details_mssql` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(255) NOT NULL DEFAULT '',
  `machine_name` varchar(255) DEFAULT NULL,
  `host_name` varchar(28) DEFAULT NULL,
  `db_name` varchar(28) NOT NULL DEFAULT '',
  `table_name` varchar(128) NOT NULL DEFAULT '',
  `schema_name` varchar(128) DEFAULT NULL,
  `row_count` bigint(20) DEFAULT NULL,
  `reserved_kb` int(11) DEFAULT NULL,
  `data_kb` int(11) DEFAULT NULL,
  `index_size_kb` int(11) DEFAULT NULL,
  `unused_kb` int(11) DEFAULT NULL,
  `collection_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`,`service_name`,`db_name`,`table_name`,`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_a10`
--

DROP TABLE IF EXISTS `cf_a10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_a10` (
  `a10_cluster_name` varchar(128) DEFAULT NULL,
  `a10_cluster_ip` varchar(16) DEFAULT NULL,
  `a10_cluster_port` varchar(8) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_machine` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_bu_email`
--

DROP TABLE IF EXISTS `cf_bu_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_bu_email` (
  `db_business` varchar(512) DEFAULT NULL,
  `email` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_bu_email_biserver`
--

DROP TABLE IF EXISTS `cf_bu_email_biserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_bu_email_biserver` (
  `db_business` varchar(512) DEFAULT NULL,
  `service_name` varchar(64) DEFAULT NULL,
  `email` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_cicode_ipnic`
--

DROP TABLE IF EXISTS `cf_cicode_ipnic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_cicode_ipnic` (
  `ci_code` varchar(128) NOT NULL,
  `ip_service` varchar(48) NOT NULL,
  `ip_physical` varchar(48) NOT NULL,
  `nic_name` varchar(64) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ci_code`,`ip_service`,`ip_physical`,`nic_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_citsm_releasedb`
--

DROP TABLE IF EXISTS `cf_citsm_releasedb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_citsm_releasedb` (
  `dns` varchar(128) DEFAULT NULL,
  `db_name` varchar(64) DEFAULT NULL,
  `data_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_couchdb_machine`
--

DROP TABLE IF EXISTS `cf_couchdb_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_couchdb_machine` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_type` varchar(45) DEFAULT NULL,
  `machine_status` varchar(45) DEFAULT '线上',
  `machine_owner` varchar(45) DEFAULT '待定',
  `maintain_type` varchar(10) DEFAULT '手动',
  `short_ci` varchar(64) DEFAULT NULL,
  `ip_business` varchar(45) DEFAULT NULL,
  `ip_backup` varchar(45) DEFAULT NULL,
  `cpu_number` smallint(6) DEFAULT NULL,
  `cpu_cores` smallint(6) DEFAULT NULL,
  `cpu_logical_number` smallint(6) DEFAULT NULL,
  `logical_disk` varchar(400) DEFAULT NULL,
  `mem_gb` smallint(6) DEFAULT NULL,
  `db_maxmem_gb` int(11) DEFAULT NULL,
  `os` varchar(256) DEFAULT NULL,
  `dbserver_edition` varchar(256) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cluster_name` varchar(255) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `is_check` int(11) DEFAULT '1' COMMENT '是否监控',
  `env` varchar(255) DEFAULT 'prd' COMMENT '环境: fat / lpt / uat / prd',
  `machine_function` varchar(255) DEFAULT '',
  `machine_located` varchar(255) DEFAULT '',
  `remedy_msg` varchar(255) DEFAULT '',
  `remark` varchar(1024) DEFAULT '',
  `server_status` varchar(12) DEFAULT 'Good' COMMENT '服务器状态: Good / Fair / Critical',
  PRIMARY KEY (`machine_id`,`machine_name`),
  UNIQUE KEY `machine_name_UNIQUE` (`machine_name`),
  KEY `idx_cluster` (`cluster_name`),
  KEY `idx_ip` (`ip_business`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_db_ciservice`
--

DROP TABLE IF EXISTS `cf_db_ciservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_db_ciservice` (
  `ci_code` varchar(64) NOT NULL,
  `ci_managedepartment` varchar(12) NOT NULL DEFAULT '',
  `ci_assetdepartment` varchar(12) NOT NULL DEFAULT '',
  `ci_status` varchar(12) NOT NULL DEFAULT '',
  `ci_supportteam` varchar(64) NOT NULL DEFAULT '',
  `ci_applicationresponseteam` varchar(64) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ci_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_db_level`
--

DROP TABLE IF EXISTS `cf_db_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_db_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_type` varchar(255) DEFAULT NULL,
  `env_type` varchar(255) DEFAULT NULL,
  `machine_name` varchar(255) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `dns` varchar(255) DEFAULT NULL,
  `DbticketUser` varchar(255) DEFAULT NULL,
  `ArchPortal` varchar(255) DEFAULT NULL,
  `db_name` varchar(255) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `db_status` varchar(255) DEFAULT NULL,
  `Server` varchar(255) DEFAULT NULL,
  `PDName` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `PDEmail` varchar(255) DEFAULT NULL,
  `Owner` varchar(255) DEFAULT NULL,
  `Remark` varchar(255) DEFAULT NULL,
  `Level` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_service_name` (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_db_level_tmp`
--

DROP TABLE IF EXISTS `cf_db_level_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_db_level_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `db_type` varchar(255) DEFAULT NULL,
  `env_type` varchar(255) DEFAULT NULL,
  `machine_name` varchar(255) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `dns` varchar(255) DEFAULT NULL,
  `DbticketUser` varchar(255) DEFAULT NULL,
  `ArchPortal` varchar(255) DEFAULT NULL,
  `db_name` varchar(255) DEFAULT NULL,
  `create_date` timestamp NULL DEFAULT NULL,
  `db_status` varchar(255) DEFAULT NULL,
  `Server` varchar(255) DEFAULT NULL,
  `PDName` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `PDEmail` varchar(255) DEFAULT NULL,
  `Owner` varchar(255) DEFAULT NULL,
  `Remark` varchar(255) DEFAULT NULL,
  `Level` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_service_name` (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_db_web`
--

DROP TABLE IF EXISTS `cf_db_web`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_db_web` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `db_machine` varchar(128) DEFAULT NULL,
  `web_machine` varchar(128) DEFAULT NULL,
  `short_ci` varchar(128) DEFAULT NULL,
  `web_machineip` varchar(16) NOT NULL,
  `update_time` timestamp NULL DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `idx_web` (`web_machine`),
  KEY `IDX_IP` (`web_machineip`),
  KEY `idx_db` (`db_machine`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_dbticket_dbinfo`
--

DROP TABLE IF EXISTS `cf_dbticket_dbinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_dbticket_dbinfo` (
  `FlowInstanceID` int(11) DEFAULT NULL,
  `keyname` varchar(300) DEFAULT NULL,
  `db_logicname` varchar(300) DEFAULT NULL,
  `db_name` varchar(300) DEFAULT NULL,
  `db_business` varchar(300) DEFAULT NULL,
  `isWR` varchar(300) DEFAULT NULL,
  `pd_textarea_3` varchar(300) DEFAULT NULL,
  `pd_textarea_22` varchar(300) DEFAULT NULL,
  `lpt_server` varchar(300) DEFAULT NULL,
  `lpt_port` varchar(300) DEFAULT NULL,
  `fat_server` varchar(300) DEFAULT NULL,
  `fpt_port` varchar(300) DEFAULT NULL,
  `uat_server` varchar(300) DEFAULT NULL,
  `upt_port` varchar(300) DEFAULT NULL,
  `product_server` varchar(300) DEFAULT NULL,
  `product_port` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_dictionary`
--

DROP TABLE IF EXISTS `cf_dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_dictionary` (
  `tbl_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  `col_value` varchar(64) NOT NULL,
  `desc1` varchar(64) DEFAULT NULL,
  `desc2` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`tbl_name`,`col_name`,`col_value`),
  KEY `idx_desc1` (`tbl_name`,`col_name`,`desc1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_dimtime_onemi`
--

DROP TABLE IF EXISTS `cf_dimtime_onemi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_dimtime_onemi` (
  `time_stamp` int(11) NOT NULL DEFAULT '0',
  `time_date` datetime DEFAULT NULL,
  `time_date1` datetime DEFAULT NULL,
  `number_of_year` int(11) DEFAULT '0',
  `number_of_month` int(11) DEFAULT '0',
  `number_of_day` int(11) DEFAULT '0',
  `number_of_hour` int(11) DEFAULT '0',
  `number_of_minute` int(11) DEFAULT '0',
  `number_of_quarter` int(11) DEFAULT '0',
  `number_of_weekday` int(11) DEFAULT '0',
  `number_of_week` int(11) DEFAULT '0',
  `number_of_fivemi` int(11) DEFAULT '0',
  PRIMARY KEY (`time_stamp`),
  KEY `idx_date` (`time_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_env`
--

DROP TABLE IF EXISTS `cf_env`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_env` (
  `id` bigint(20) NOT NULL DEFAULT '0',
  `env_type` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_etl_tsql`
--

DROP TABLE IF EXISTS `cf_etl_tsql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_etl_tsql` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `etl_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `tsql` varchar(4000) DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `owner_name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_festival`
--

DROP TABLE IF EXISTS `cf_festival`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_festival` (
  `relate_date` date DEFAULT NULL,
  `festival` varchar(24) DEFAULT NULL,
  `date_status` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_groupline`
--

DROP TABLE IF EXISTS `cf_groupline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_groupline` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(48) DEFAULT NULL,
  `category_alias` varchar(80) DEFAULT NULL,
  `group_name` varchar(48) DEFAULT NULL,
  `group_alias` varchar(80) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_jobmodule`
--

DROP TABLE IF EXISTS `cf_jobmodule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_jobmodule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Job_Name` varchar(256) NOT NULL,
  `Job_Program` varchar(50) DEFAULT NULL,
  `Job_Similar` varchar(256) DEFAULT NULL,
  `Env_Types` bigint(20) NOT NULL DEFAULT '0',
  `Proc_Scripts` varchar(256) NOT NULL,
  `IsAutoCreate` char(1) NOT NULL,
  `IsForceCreate_Proc` char(1) NOT NULL,
  `IsForceCreate_Job` char(1) NOT NULL,
  `IsValid` int(11) NOT NULL,
  `FilterCause` varchar(256) NOT NULL DEFAULT '',
  `Insert_Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Update_Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine`
--

DROP TABLE IF EXISTS `cf_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_type` varchar(45) DEFAULT NULL,
  `machine_status` varchar(45) DEFAULT '线上',
  `machine_owner` varchar(45) DEFAULT '待定',
  `maintain_type` varchar(10) DEFAULT '手动',
  `short_ci` varchar(64) DEFAULT NULL,
  `ip_business` varchar(45) DEFAULT NULL,
  `ip_backup` varchar(45) DEFAULT NULL,
  `cpu_number` smallint(6) DEFAULT NULL,
  `cpu_cores` smallint(6) DEFAULT NULL,
  `cpu_logical_number` smallint(6) DEFAULT NULL,
  `logical_disk` varchar(400) DEFAULT NULL,
  `mem_gb` smallint(6) DEFAULT NULL,
  `db_maxmem_gb` int(11) DEFAULT NULL,
  `os` varchar(256) DEFAULT NULL,
  `dbserver_edition` varchar(256) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `job_codeid_list` varchar(255) DEFAULT NULL,
  `machine_function` varchar(255) DEFAULT '',
  `machine_located` varchar(255) DEFAULT '',
  `remedy_msg` varchar(255) DEFAULT '',
  `remark` varchar(1024) DEFAULT '',
  `guarantee_date` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`machine_id`,`machine_name`),
  UNIQUE KEY `machine_name_UNIQUE` (`machine_name`),
  KEY `idx_ip` (`ip_business`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_20160126`
--

DROP TABLE IF EXISTS `cf_machine_20160126`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_20160126` (
  `machine_id` int(11) NOT NULL DEFAULT '0',
  `machine_name` varchar(128) NOT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_type` varchar(45) DEFAULT NULL,
  `machine_status` varchar(45) DEFAULT '线上',
  `machine_owner` varchar(45) DEFAULT '待定',
  `maintain_type` varchar(10) DEFAULT '手动',
  `short_ci` varchar(64) DEFAULT NULL,
  `ip_business` varchar(45) DEFAULT NULL,
  `ip_backup` varchar(45) DEFAULT NULL,
  `cpu_number` smallint(6) DEFAULT NULL,
  `cpu_cores` smallint(6) DEFAULT NULL,
  `cpu_logical_number` smallint(6) DEFAULT NULL,
  `logical_disk` varchar(400) DEFAULT NULL,
  `mem_gb` smallint(6) DEFAULT NULL,
  `db_maxmem_gb` int(11) DEFAULT NULL,
  `os` varchar(256) DEFAULT NULL,
  `dbserver_edition` varchar(256) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `job_codeid_list` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_20160205`
--

DROP TABLE IF EXISTS `cf_machine_20160205`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_20160205` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_type` varchar(45) DEFAULT NULL,
  `machine_status` varchar(45) DEFAULT '线上',
  `machine_owner` varchar(45) DEFAULT '待定',
  `maintain_type` varchar(10) DEFAULT '手动',
  `short_ci` varchar(64) DEFAULT NULL,
  `ip_business` varchar(45) DEFAULT NULL,
  `ip_backup` varchar(45) DEFAULT NULL,
  `cpu_number` smallint(6) DEFAULT NULL,
  `cpu_cores` smallint(6) DEFAULT NULL,
  `cpu_logical_number` smallint(6) DEFAULT NULL,
  `logical_disk` varchar(400) DEFAULT NULL,
  `mem_gb` smallint(6) DEFAULT NULL,
  `db_maxmem_gb` int(11) DEFAULT NULL,
  `os` varchar(256) DEFAULT NULL,
  `dbserver_edition` varchar(256) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `job_codeid_list` varchar(255) DEFAULT NULL,
  `machine_function` varchar(255) DEFAULT '',
  `machine_located` varchar(255) DEFAULT '',
  `remedy_msg` varchar(255) DEFAULT '',
  PRIMARY KEY (`machine_id`,`machine_name`),
  UNIQUE KEY `machine_name_UNIQUE` (`machine_name`),
  KEY `idx_ip` (`ip_business`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_jobcodeid`
--

DROP TABLE IF EXISTS `cf_machine_jobcodeid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_jobcodeid` (
  `short_ci` varchar(64) NOT NULL,
  `job_codeid` int(11) NOT NULL,
  `machine_name` varchar(64) NOT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `maint_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `applicant` varchar(64) DEFAULT NULL,
  `operator` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`short_ci`,`job_codeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_log`
--

DROP TABLE IF EXISTS `cf_machine_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_log` (
  `machine_name` varchar(128) DEFAULT NULL,
  `machine_status` varchar(45) DEFAULT NULL,
  `machine_owner` varchar(45) DEFAULT NULL,
  `maintain_type` varchar(10) DEFAULT NULL,
  `short_ci` varchar(64) DEFAULT NULL,
  `ip_business` varchar(45) DEFAULT NULL,
  `ip_backup` varchar(45) DEFAULT NULL,
  `cpu_number` smallint(6) DEFAULT NULL,
  `cpu_cores` smallint(6) DEFAULT NULL,
  `cpu_logical_number` smallint(6) DEFAULT NULL,
  `logical_disk` varchar(400) DEFAULT NULL,
  `mem_gb` smallint(6) DEFAULT NULL,
  `db_maxmem_gb` int(11) DEFAULT NULL,
  `os` varchar(256) DEFAULT NULL,
  `dbserver_edition` varchar(256) DEFAULT NULL,
  `content` varchar(1024) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `op_type` varchar(128) DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_type` varchar(45) DEFAULT NULL,
  `machine_function` varchar(255) DEFAULT NULL,
  `machine_located` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='serverlist页面中, cf_machine的增删改日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_remedy`
--

DROP TABLE IF EXISTS `cf_machine_remedy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_remedy` (
  `ci_code` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `machine_status` varchar(32) DEFAULT NULL,
  `machine_function` varchar(4000) DEFAULT NULL,
  `ip_business` varchar(128) DEFAULT NULL,
  `located` varchar(128) DEFAULT NULL,
  `physical_location` varchar(64) DEFAULT NULL,
  `u_number` varchar(32) DEFAULT NULL,
  `physical_disk` varchar(128) DEFAULT NULL,
  `disk_rotatespeed` int(11) DEFAULT NULL,
  `disk_size` float DEFAULT NULL,
  `cpu_model` varchar(256) DEFAULT NULL,
  `security_type` varchar(32) DEFAULT NULL,
  `department` varchar(8) DEFAULT NULL,
  `service_type` varchar(1024) DEFAULT NULL,
  `parent_ci_code` varchar(1024) DEFAULT NULL,
  `parent_machine` varchar(1024) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_machine` (`machine_name`),
  KEY `idx_cicode` (`ci_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_machine_storage`
--

DROP TABLE IF EXISTS `cf_machine_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_machine_storage` (
  `short_ci` varchar(64) DEFAULT NULL,
  `disk_array` varchar(256) DEFAULT NULL,
  `volumn` varchar(128) DEFAULT NULL,
  `total_space_gb` float DEFAULT NULL,
  `free_space_gb` float DEFAULT NULL,
  `data_date` date DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_maintain_dictionary`
--

DROP TABLE IF EXISTS `cf_maintain_dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_maintain_dictionary` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_name` varchar(128) DEFAULT NULL,
  `col_name` varchar(128) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `data_source` varchar(128) DEFAULT NULL,
  `maintenance` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_mssql_alwayson`
--

DROP TABLE IF EXISTS `cf_mssql_alwayson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mssql_alwayson` (
  `machine_name` varchar(128) NOT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `ag_name` varchar(128) DEFAULT NULL,
  `db_name` varchar(128) NOT NULL,
  `secondary_machine` varchar(128) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`db_name`,`secondary_machine`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_mssql_cluster`
--

DROP TABLE IF EXISTS `cf_mssql_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mssql_cluster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) DEFAULT NULL,
  `winclsname` varchar(128) DEFAULT NULL,
  `winclsip` varchar(50) DEFAULT NULL,
  `machine_name` varchar(50) DEFAULT NULL,
  `host_name` varchar(50) DEFAULT NULL,
  `instance` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `ip_business` varchar(50) DEFAULT NULL,
  `ip_backup` varchar(50) DEFAULT NULL,
  `modify_timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_host_name` (`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_mysql_cluster`
--

DROP TABLE IF EXISTS `cf_mysql_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mysql_cluster` (
  `cluster_name` varchar(128) NOT NULL,
  `mastervip` varchar(20) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `role` varchar(10) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `in_mhaconf` int(11) NOT NULL DEFAULT '1' COMMENT '0:not in 1:in',
  `no_master` int(11) NOT NULL DEFAULT '0' COMMENT 'same as mha configuration no_master',
  `ignore_fail` int(11) NOT NULL DEFAULT '0' COMMENT 'same as mha configuration ignore_fail',
  `drvip` varchar(20) DEFAULT '' COMMENT 'vip of dr node',
  `db_ip` varchar(32) NOT NULL DEFAULT '',
  `db_port` int(11) NOT NULL DEFAULT '3306',
  PRIMARY KEY (`cluster_name`,`db_ip`,`db_port`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_mysql_mhawhilelist`
--

DROP TABLE IF EXISTS `cf_mysql_mhawhilelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mysql_mhawhilelist` (
  `cluster_name` varchar(50) NOT NULL,
  PRIMARY KEY (`cluster_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_organization`
--

DROP TABLE IF EXISTS `cf_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_organization` (
  `organization_id` int(11) NOT NULL,
  `organization_code` varchar(24) NOT NULL DEFAULT '',
  `priority_id` int(11) DEFAULT NULL,
  `organization_name` varchar(64) NOT NULL DEFAULT '',
  `organization_ename` varchar(64) NOT NULL DEFAULT '',
  `organization_status` varchar(24) NOT NULL DEFAULT '',
  `organization_type` varchar(12) NOT NULL DEFAULT '',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EmailList` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_pool`
--

DROP TABLE IF EXISTS `cf_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_pool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchid` int(11) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `organization_code` varchar(15) DEFAULT NULL,
  `organization_name` varchar(15) DEFAULT NULL,
  `pool_id` int(11) NOT NULL,
  `pool_name` varchar(128) NOT NULL,
  `ci_code` varchar(50) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `idc` varchar(50) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_servererrorlog_warningmessage`
--

DROP TABLE IF EXISTS `cf_servererrorlog_warningmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_servererrorlog_warningmessage` (
  `message_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `severity` int(11) DEFAULT NULL,
  `is_event_logged` int(11) DEFAULT NULL,
  `text` mediumtext,
  `like_clause` varchar(200) DEFAULT NULL,
  `is_valid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_service`
--

DROP TABLE IF EXISTS `cf_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_service` (
  `service_name` varchar(64) NOT NULL,
  `dns` varchar(200) NOT NULL DEFAULT '',
  `dns_port` varchar(10) NOT NULL,
  `vip_service` varchar(16) DEFAULT NULL,
  `vip_backup` varchar(16) DEFAULT NULL,
  `dns_cname` varchar(256) DEFAULT '',
  `dns_arecord` varchar(256) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(32) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `maintain_batch` int(11) DEFAULT NULL,
  `maintain_type` varchar(16) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `dns_status` tinyint(4) NOT NULL DEFAULT '1',
  `available_status` tinyint(4) DEFAULT '1',
  `pd_name` varchar(32) DEFAULT '',
  `organization_id` int(11) DEFAULT NULL,
  `organization_code` varchar(24) DEFAULT NULL,
  `flag` int(11) DEFAULT '0',
  PRIMARY KEY (`dns`),
  KEY `idx_machine_name` (`machine_name`),
  KEY `idx_db_type` (`db_type`),
  KEY `idx_host_name` (`host_name`),
  KEY `idx_service_name` (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_service_20160126`
--

DROP TABLE IF EXISTS `cf_service_20160126`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_service_20160126` (
  `service_name` varchar(64) NOT NULL,
  `dns` varchar(200) NOT NULL DEFAULT '',
  `dns_port` varchar(10) DEFAULT NULL,
  `vip_service` varchar(16) DEFAULT NULL,
  `vip_backup` varchar(16) DEFAULT NULL,
  `dns_cname` varchar(256) DEFAULT '',
  `dns_arecord` varchar(256) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(32) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `maintain_batch` int(11) DEFAULT NULL,
  `maintain_type` varchar(16) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `dns_status` tinyint(4) NOT NULL DEFAULT '1',
  `available_status` tinyint(4) DEFAULT '1',
  `pd_name` varchar(32) DEFAULT '',
  `organization_id` int(11) DEFAULT NULL,
  `organization_code` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_service_20160513`
--

DROP TABLE IF EXISTS `cf_service_20160513`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_service_20160513` (
  `service_name` varchar(64) NOT NULL,
  `dns` varchar(200) NOT NULL DEFAULT '',
  `dns_port` varchar(10) NOT NULL,
  `vip_service` varchar(16) DEFAULT NULL,
  `vip_backup` varchar(16) DEFAULT NULL,
  `dns_cname` varchar(256) DEFAULT '',
  `dns_arecord` varchar(256) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(32) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `maintain_batch` int(11) DEFAULT NULL,
  `maintain_type` varchar(16) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `dns_status` tinyint(4) NOT NULL DEFAULT '1',
  `available_status` tinyint(4) DEFAULT '1',
  `pd_name` varchar(32) DEFAULT '',
  `organization_id` int(11) DEFAULT NULL,
  `organization_code` varchar(24) DEFAULT NULL,
  `flag` int(11) DEFAULT '0',
  PRIMARY KEY (`dns`),
  KEY `idx_machine_name` (`machine_name`),
  KEY `idx_db_type` (`db_type`),
  KEY `idx_host_name` (`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_service_description`
--

DROP TABLE IF EXISTS `cf_service_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_service_description` (
  `service_name` varchar(64) NOT NULL,
  `db_type` varchar(45) NOT NULL,
  `description` varchar(4000) DEFAULT NULL,
  `business` varchar(4000) DEFAULT NULL,
  `department` varchar(4000) DEFAULT NULL,
  `test_scope` varchar(4000) DEFAULT NULL,
  `maintain_content` varchar(4000) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_name`,`db_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_service_log`
--

DROP TABLE IF EXISTS `cf_service_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_service_log` (
  `service_name` varchar(64) DEFAULT NULL,
  `dns` varchar(256) DEFAULT NULL,
  `dns_port` varchar(10) DEFAULT NULL,
  `dns_status` tinyint(4) DEFAULT NULL,
  `vip_service` varchar(16) DEFAULT NULL,
  `vip_backup` varchar(16) DEFAULT NULL,
  `dns_arecord` varchar(256) DEFAULT NULL,
  `dns_cname` varchar(128) DEFAULT NULL,
  `db_type` varchar(16) DEFAULT NULL,
  `env_type` varchar(32) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `maintain_batch` int(11) DEFAULT NULL,
  `maintain_type` varchar(16) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `op_type` varchar(128) DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160822 VALUES LESS THAN ('2016-08-23') ENGINE = InnoDB,
 PARTITION p20160823 VALUES LESS THAN ('2016-08-24') ENGINE = InnoDB,
 PARTITION p20160824 VALUES LESS THAN ('2016-08-25') ENGINE = InnoDB,
 PARTITION p20160825 VALUES LESS THAN ('2016-08-26') ENGINE = InnoDB,
 PARTITION p20160826 VALUES LESS THAN ('2016-08-27') ENGINE = InnoDB,
 PARTITION p20160827 VALUES LESS THAN ('2016-08-28') ENGINE = InnoDB,
 PARTITION p20160828 VALUES LESS THAN ('2016-08-29') ENGINE = InnoDB,
 PARTITION p20160829 VALUES LESS THAN ('2016-08-30') ENGINE = InnoDB,
 PARTITION p20160830 VALUES LESS THAN ('2016-08-31') ENGINE = InnoDB,
 PARTITION p20160831 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN ('2016-09-02') ENGINE = InnoDB,
 PARTITION p20160902 VALUES LESS THAN ('2016-09-03') ENGINE = InnoDB,
 PARTITION p20160903 VALUES LESS THAN ('2016-09-04') ENGINE = InnoDB,
 PARTITION p20160904 VALUES LESS THAN ('2016-09-05') ENGINE = InnoDB,
 PARTITION p20160905 VALUES LESS THAN ('2016-09-06') ENGINE = InnoDB,
 PARTITION p20160906 VALUES LESS THAN ('2016-09-07') ENGINE = InnoDB,
 PARTITION p20160907 VALUES LESS THAN ('2016-09-08') ENGINE = InnoDB,
 PARTITION p20160908 VALUES LESS THAN ('2016-09-09') ENGINE = InnoDB,
 PARTITION p20160909 VALUES LESS THAN ('2016-09-10') ENGINE = InnoDB,
 PARTITION p20160910 VALUES LESS THAN ('2016-09-11') ENGINE = InnoDB,
 PARTITION p20160911 VALUES LESS THAN ('2016-09-12') ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN ('2016-09-13') ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN ('2016-09-14') ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_spt_values`
--

DROP TABLE IF EXISTS `cf_spt_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_spt_values` (
  `type` varchar(10) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_web_cluster`
--

DROP TABLE IF EXISTS `cf_web_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_web_cluster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_alias` varchar(128) DEFAULT NULL,
  `cluster_name` varchar(128) DEFAULT NULL,
  `cluster_ip` varchar(16) DEFAULT NULL,
  `ci_code` varchar(128) DEFAULT NULL,
  `shortci` varchar(128) DEFAULT NULL,
  `machine_ip` varchar(16) DEFAULT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`machine_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_webinfo`
--

DROP TABLE IF EXISTS `cf_webinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_webinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchid` int(11) NOT NULL,
  `aliascluster` varchar(100) NOT NULL,
  `clusterip` varchar(15) NOT NULL,
  `clustervport` int(11) NOT NULL,
  `cicode` varchar(128) NOT NULL,
  `shortci` varchar(128) NOT NULL,
  `ipaddress` varchar(15) NOT NULL,
  `port` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `zone` int(11) DEFAULT NULL,
  `cpu` smallint(6) DEFAULT NULL,
  `mem` smallint(6) DEFAULT NULL,
  `disk` int(11) DEFAULT NULL,
  `weight` smallint(6) DEFAULT NULL,
  `os` varchar(24) DEFAULT NULL,
  `groupname` varchar(160) DEFAULT NULL,
  `isfort` int(11) DEFAULT NULL,
  `protocol` int(11) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_CreateTime` (`createtime`),
  KEY `index_1` (`cicode`,`createtime`),
  KEY `index_2` (`createtime`,`cicode`),
  KEY `idx_batchid_status` (`batchid`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_webinfo_domain`
--

DROP TABLE IF EXISTS `cf_webinfo_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_webinfo_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchid` int(11) NOT NULL,
  `clusterip` varchar(15) NOT NULL,
  `cluster` varchar(100) NOT NULL,
  `createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IX_BatchID` (`batchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cf_whiteserver`
--

DROP TABLE IF EXISTS `cf_whiteserver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_whiteserver` (
  `host_name` varchar(128) NOT NULL,
  `machine_name` varchar(128) NOT NULL,
  `remark` varchar(500) NOT NULL DEFAULT '',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`host_name`,`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cgroup_config`
--

DROP TABLE IF EXISTS `cgroup_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cgroup_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machineName` varchar(128) DEFAULT NULL,
  `machineIp` varchar(64) DEFAULT NULL,
  `clusterName` varchar(128) NOT NULL,
  `servervip` varchar(64) DEFAULT NULL,
  `role` varchar(32) DEFAULT NULL,
  `subsystem` varchar(64) DEFAULT NULL,
  `node` varchar(128) DEFAULT NULL,
  `nodevalue` varchar(128) DEFAULT NULL,
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'datachange_lasttime',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unidx_key` (`machineName`,`clusterName`,`subsystem`,`servervip`,`node`),
  KEY `idx_machineName` (`machineName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `chksharddbobj_config`
--

DROP TABLE IF EXISTS `chksharddbobj_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chksharddbobj_config` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `db_name` varchar(128) NOT NULL DEFAULT '',
  `dns` varchar(256) NOT NULL DEFAULT '',
  `dns_port` varchar(128) NOT NULL DEFAULT '',
  `db_type` varchar(128) NOT NULL DEFAULT '',
  `env_type` varchar(128) NOT NULL DEFAULT '',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ShardGroup` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_alltrace_analysisservers`
--

DROP TABLE IF EXISTS `control_alltrace_analysisservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_alltrace_analysisservers` (
  `machine_name` varchar(128) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `ip_product` varchar(15) DEFAULT NULL,
  `is_valid` int(11) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `infobright` varchar(256) DEFAULT NULL,
  `remark` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_alltrace_deploylist`
--

DROP TABLE IF EXISTS `control_alltrace_deploylist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_alltrace_deploylist` (
  `deployid` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `analysis_machine_name` varchar(128) DEFAULT NULL,
  `file_size` int(11) DEFAULT '300',
  `load_infobright` int(11) DEFAULT '1',
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `job_count` int(11) DEFAULT '0',
  `remark` varchar(128) DEFAULT NULL,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`deployid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_alltrace_todolist`
--

DROP TABLE IF EXISTS `control_alltrace_todolist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_alltrace_todolist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `operator` varchar(64) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `is_finished` char(1) DEFAULT NULL,
  `trace_status` varchar(1000) DEFAULT NULL,
  `success` int(11) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `analysis_ip` varchar(100) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `load_infobright` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_cf_monitortemplate`
--

DROP TABLE IF EXISTS `control_cf_monitortemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_cf_monitortemplate` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `property` varchar(128) DEFAULT NULL,
  `default_value` tinyint(4) DEFAULT NULL,
  `scope` varchar(24) DEFAULT NULL,
  `category` varchar(24) DEFAULT NULL,
  `is_show` tinyint(4) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_etl_machine`
--

DROP TABLE IF EXISTS `control_etl_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_etl_machine` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `counter_source` varchar(64) DEFAULT NULL,
  `counter_onemi` datetime DEFAULT CURRENT_TIMESTAMP,
  `counter_onemi_history` datetime DEFAULT CURRENT_TIMESTAMP,
  `counter_base_cpu` datetime DEFAULT NULL,
  `counter_base_uc` datetime DEFAULT NULL,
  `counter_alert_onemi` datetime DEFAULT NULL,
  `counter_arule` datetime DEFAULT NULL,
  `counter_brule` datetime DEFAULT NULL,
  `monitor_message` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `db_process` datetime DEFAULT NULL,
  PRIMARY KEY (`rid`,`machine_name`),
  UNIQUE KEY `machine_name_UNIQUE` (`machine_name`),
  KEY `idx_machine` (`machine_name`),
  KEY `idx_time` (`counter_onemi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_machine_monitorstatus`
--

DROP TABLE IF EXISTS `control_machine_monitorstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_machine_monitorstatus` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `property` varchar(64) NOT NULL DEFAULT '',
  `property_value` varchar(32) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `reason` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operator` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`machine_name`,`property`),
  KEY `index_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_machine_monitorstatuslog`
--

DROP TABLE IF EXISTS `control_machine_monitorstatuslog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_machine_monitorstatuslog` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT '',
  `property` varchar(64) DEFAULT '',
  `property_value_old` varchar(32) DEFAULT NULL,
  `property_value_new` varchar(32) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `reason` varchar(1024) DEFAULT NULL,
  `operator` varchar(32) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `index_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_service_monitorstatus`
--

DROP TABLE IF EXISTS `control_service_monitorstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_service_monitorstatus` (
  `service_name` varchar(128) NOT NULL DEFAULT '',
  `property` varchar(64) NOT NULL DEFAULT '',
  `property_value` varchar(32) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `reason` varchar(1024) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operator` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `control_service_monitorstatuslog`
--

DROP TABLE IF EXISTS `control_service_monitorstatuslog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_service_monitorstatuslog` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(128) DEFAULT '',
  `property` varchar(64) DEFAULT '',
  `property_value_old` varchar(32) DEFAULT NULL,
  `property_value_new` varchar(32) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `reason` varchar(1024) DEFAULT NULL,
  `operator` varchar(32) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `index_service_name` (`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_cf_diskspecialsize`
--

DROP TABLE IF EXISTS `counter_cf_diskspecialsize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_cf_diskspecialsize` (
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(128) DEFAULT NULL,
  `used_percentline` int(11) DEFAULT NULL,
  `free_spaceline` int(11) DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_cf_key`
--

DROP TABLE IF EXISTS `counter_cf_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_cf_key` (
  `keyid` int(11) NOT NULL AUTO_INCREMENT,
  `db_type` varchar(45) DEFAULT NULL,
  `key_` varchar(256) DEFAULT NULL,
  `object_type` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(128) DEFAULT NULL,
  `display_name` varchar(128) DEFAULT NULL,
  `divisor` float DEFAULT NULL,
  `delay` int(11) DEFAULT NULL,
  `measure` varchar(10) DEFAULT NULL,
  `tendency` varchar(10) DEFAULT NULL,
  `boundary` int(11) DEFAULT NULL,
  `modify_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mobile_monitor` int(11) DEFAULT '0',
  PRIMARY KEY (`keyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data`
--

DROP TABLE IF EXISTS `counter_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(200) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `counter_value` float DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`data_time`),
  KEY `idx_time` (`machine_name`,`data_time`,`object_name`,`counter_name`),
  KEY `index_1` (`counter_name`,`machine_name`,`data_time`),
  KEY `idx_data_time` (`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50100 PARTITION BY RANGE (to_days(data_time))
(PARTITION p20160919 VALUES LESS THAN (736592) ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN (736593) ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN (736594) ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN (736595) ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN (736596) ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN (736597) ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN (736598) ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN (736599) ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN (736600) ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN (736601) ENGINE = InnoDB,
 PARTITION p20160929 VALUES LESS THAN (736602) ENGINE = InnoDB,
 PARTITION p20160930 VALUES LESS THAN (736603) ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN (736604) ENGINE = InnoDB,
 PARTITION p20161002 VALUES LESS THAN (736605) ENGINE = InnoDB,
 PARTITION p20161003 VALUES LESS THAN (736606) ENGINE = InnoDB,
 PARTITION p20161004 VALUES LESS THAN (736607) ENGINE = InnoDB,
 PARTITION p20161005 VALUES LESS THAN (736608) ENGINE = InnoDB,
 PARTITION p20161006 VALUES LESS THAN (736609) ENGINE = InnoDB,
 PARTITION pMax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_arule`
--

DROP TABLE IF EXISTS `counter_data_arule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_arule` (
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(200) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `counter_value` float DEFAULT NULL,
  `insert_timestamp` timestamp NULL DEFAULT NULL,
  KEY `idx_time` (`machine_name`,`data_time`,`object_name`,`counter_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION p20160929 VALUES LESS THAN ('2016-09-30') ENGINE = InnoDB,
 PARTITION p20160930 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN ('2016-10-02') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_baselinecpu`
--

DROP TABLE IF EXISTS `counter_data_baselinecpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_baselinecpu` (
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(200) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `distance` float DEFAULT NULL,
  `avg_value` float DEFAULT NULL,
  `max_value` float DEFAULT NULL,
  `min_value` float DEFAULT NULL,
  `insert_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_time` (`machine_name`,`data_time`,`object_name`,`counter_name`),
  KEY `idx_counter_time` (`counter_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_baselineuc`
--

DROP TABLE IF EXISTS `counter_data_baselineuc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_baselineuc` (
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(200) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `avg_value` float DEFAULT NULL,
  `max_value` float DEFAULT NULL,
  `min_value` float DEFAULT NULL,
  `insert_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_time` (`machine_name`,`data_time`,`object_name`,`counter_name`),
  KEY `idx_counter_time` (`counter_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_brule`
--

DROP TABLE IF EXISTS `counter_data_brule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_brule` (
  `machine_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `instance_name` varchar(200) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  `counter_value` float DEFAULT NULL,
  `insert_timestamp` timestamp NULL DEFAULT NULL,
  KEY `idx_time` (`machine_name`,`data_time`,`object_name`,`counter_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION p20160929 VALUES LESS THAN ('2016-09-30') ENGINE = InnoDB,
 PARTITION p20160930 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN ('2016-10-02') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_diskinfo`
--

DROP TABLE IF EXISTS `counter_data_diskinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_diskinfo` (
  `machine_name` varchar(128) NOT NULL,
  `logical_disk` varchar(128) NOT NULL,
  `total_gb` float DEFAULT NULL,
  `used_gb` float DEFAULT NULL,
  `free_gb` float DEFAULT NULL,
  `used_percent` varchar(20) DEFAULT NULL,
  `data_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`logical_disk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counter_data_net`
--

DROP TABLE IF EXISTS `counter_data_net`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counter_data_net` (
  `item_id` bigint(20) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `ip_service` varchar(16) NOT NULL,
  `nic_name` varchar(128) NOT NULL,
  `counter_value` bigint(20) DEFAULT NULL,
  `data_time` datetime NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`data_time`,`ip_service`,`nic_name`),
  KEY `idx_time` (`machine_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20140813 VALUES LESS THAN ('2014-08-14') ENGINE = InnoDB,
 PARTITION p20140814 VALUES LESS THAN ('2014-08-15') ENGINE = InnoDB,
 PARTITION p20140815 VALUES LESS THAN ('2014-08-16') ENGINE = InnoDB,
 PARTITION p20140816 VALUES LESS THAN ('2014-08-17') ENGINE = InnoDB,
 PARTITION p20140817 VALUES LESS THAN ('2014-08-18') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counternetworktype`
--

DROP TABLE IF EXISTS `counternetworktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counternetworktype` (
  `MachineName` varchar(64) DEFAULT NULL,
  `Caption` varchar(1024) DEFAULT NULL,
  `NicType` varchar(8) DEFAULT NULL,
  `CollectTime` datetime DEFAULT NULL,
  `Speed` bigint(20) DEFAULT NULL,
  KEY `idx_MachineName` (`MachineName`),
  KEY `idx_1` (`NicType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `counternetworktype_process`
--

DROP TABLE IF EXISTS `counternetworktype_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `counternetworktype_process` (
  `MachineName` varchar(64) DEFAULT NULL,
  `Caption` varchar(1024) DEFAULT NULL,
  `NicType` varchar(8) DEFAULT NULL,
  `CollectTime` datetime DEFAULT NULL,
  `Speed` bigint(20) DEFAULT NULL,
  KEY `idx_MachineName` (`MachineName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_crontab_errorlog`
--

DROP TABLE IF EXISTS `data_crontab_errorlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_crontab_errorlog` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `begin_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `cron_name` varchar(255) DEFAULT NULL,
  `object_name` varchar(64) NOT NULL DEFAULT '',
  `machine_name` varchar(64) NOT NULL,
  `error_msg` varchar(1000) DEFAULT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`rid`,`begin_time`),
  KEY `idx_cron_name` (`cron_name`),
  KEY `insert_timestamp` (`insert_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(begin_time)
(PARTITION p20160907 VALUES LESS THAN ('2016-09-08') ENGINE = InnoDB,
 PARTITION p20160908 VALUES LESS THAN ('2016-09-09') ENGINE = InnoDB,
 PARTITION p20160909 VALUES LESS THAN ('2016-09-10') ENGINE = InnoDB,
 PARTITION p20160910 VALUES LESS THAN ('2016-09-11') ENGINE = InnoDB,
 PARTITION p20160911 VALUES LESS THAN ('2016-09-12') ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN ('2016-09-13') ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN ('2016-09-14') ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_crontab_log`
--

DROP TABLE IF EXISTS `data_crontab_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_crontab_log` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `begin_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `end_time` datetime(3) DEFAULT NULL,
  `cron_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(64) NOT NULL DEFAULT '',
  `machine_name` varchar(64) NOT NULL,
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`rid`,`begin_time`),
  KEY `idx_cron_name` (`cron_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(begin_time)
(PARTITION p20160907 VALUES LESS THAN ('2016-09-08') ENGINE = InnoDB,
 PARTITION p20160908 VALUES LESS THAN ('2016-09-09') ENGINE = InnoDB,
 PARTITION p20160909 VALUES LESS THAN ('2016-09-10') ENGINE = InnoDB,
 PARTITION p20160910 VALUES LESS THAN ('2016-09-11') ENGINE = InnoDB,
 PARTITION p20160911 VALUES LESS THAN ('2016-09-12') ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN ('2016-09-13') ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN ('2016-09-14') ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_programjob_errorlog`
--

DROP TABLE IF EXISTS `data_programjob_errorlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_programjob_errorlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(256) DEFAULT NULL,
  `datasource` varchar(256) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `step_name` varchar(128) DEFAULT NULL,
  `errormsg` varchar(1000) DEFAULT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`insert_timestamp`),
  KEY `idx1` (`machine_name`,`insert_timestamp`),
  KEY `idx2` (`datasource`(255),`insert_timestamp`),
  KEY `idx3` (`host_name`,`insert_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(insert_timestamp)
(PARTITION p20160911 VALUES LESS THAN ('2016-09-12') ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN ('2016-09-13') ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN ('2016-09-14') ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_block`
--

DROP TABLE IF EXISTS `db_data_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_block` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `block_count` int(11) DEFAULT NULL,
  `time_count` int(11) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_time`),
  KEY `IDX_time` (`data_time`),
  KEY `IDX_inserttime` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_block_mysqltmp`
--

DROP TABLE IF EXISTS `db_data_block_mysqltmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_block_mysqltmp` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `block_count` int(11) DEFAULT NULL,
  `time_count` int(11) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `IDX_time` (`data_time`),
  KEY `index_1` (`machine_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_failover_log`
--

DROP TABLE IF EXISTS `db_data_failover_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_failover_log` (
  `db_type` varchar(32) NOT NULL DEFAULT '',
  `service_name` varchar(128) NOT NULL DEFAULT '',
  `machine_name_old` varchar(64) NOT NULL DEFAULT '',
  `machine_name_new` varchar(64) NOT NULL DEFAULT '',
  `host_name` varchar(64) DEFAULT NULL,
  `failover_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `insert_timestamp` timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `maintain_status` int(11) DEFAULT '0',
  PRIMARY KEY (`db_type`,`service_name`,`failover_time`),
  KEY `id_failovertime` (`failover_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(failover_time)
(PARTITION p20160601 VALUES LESS THAN ('2016-07-01') ENGINE = InnoDB,
 PARTITION p20160701 VALUES LESS THAN ('2016-08-01') ENGINE = InnoDB,
 PARTITION p20160801 VALUES LESS THAN ('2016-09-01') ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN ('2016-10-01') ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN ('2016-11-01') ENGINE = InnoDB,
 PARTITION p20161101 VALUES LESS THAN ('2016-12-01') ENGINE = InnoDB,
 PARTITION p20161201 VALUES LESS THAN ('2017-01-01') ENGINE = InnoDB,
 PARTITION p20170101 VALUES LESS THAN ('2017-02-01') ENGINE = InnoDB,
 PARTITION p20170201 VALUES LESS THAN ('2017-03-01') ENGINE = InnoDB,
 PARTITION p20170301 VALUES LESS THAN ('2017-04-01') ENGINE = InnoDB,
 PARTITION p20170401 VALUES LESS THAN ('2017-05-01') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_process`
--

DROP TABLE IF EXISTS `db_data_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_process` (
  `db_machine` varchar(128) DEFAULT NULL,
  `db_host_name` varchar(128) DEFAULT NULL,
  `db_machineip` varchar(16) DEFAULT NULL,
  `web_machine` varchar(128) DEFAULT NULL,
  `web_machineip` varchar(16) DEFAULT NULL,
  `process_count` int(11) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  KEY `idx_time` (`db_machine`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_process_alert`
--

DROP TABLE IF EXISTS `db_data_process_alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_process_alert` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(128) DEFAULT NULL,
  `db_type` varchar(24) DEFAULT NULL,
  `db_machine` varchar(128) DEFAULT NULL,
  `db_host_name` varchar(128) DEFAULT NULL,
  `login_name` varchar(128) DEFAULT NULL,
  `client_ip` varchar(128) DEFAULT NULL,
  `client_hostname` varchar(128) DEFAULT NULL,
  `pc_user` varchar(128) DEFAULT NULL,
  `process_count` int(11) DEFAULT NULL,
  `program_name` varchar(128) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20150522 VALUES LESS THAN ('2015-05-23') ENGINE = InnoDB,
 PARTITION p20150523 VALUES LESS THAN ('2015-05-24') ENGINE = InnoDB,
 PARTITION p20150524 VALUES LESS THAN ('2015-05-25') ENGINE = InnoDB,
 PARTITION p20150525 VALUES LESS THAN ('2015-05-26') ENGINE = InnoDB,
 PARTITION p20150526 VALUES LESS THAN ('2015-05-27') ENGINE = InnoDB,
 PARTITION p20150527 VALUES LESS THAN ('2015-05-28') ENGINE = InnoDB,
 PARTITION p20150528 VALUES LESS THAN ('2015-05-29') ENGINE = InnoDB,
 PARTITION p20150529 VALUES LESS THAN ('2015-05-30') ENGINE = InnoDB,
 PARTITION p20150530 VALUES LESS THAN ('2015-05-31') ENGINE = InnoDB,
 PARTITION p20150531 VALUES LESS THAN ('2015-06-01') ENGINE = InnoDB,
 PARTITION p20150601 VALUES LESS THAN ('2015-06-02') ENGINE = InnoDB,
 PARTITION p20150602 VALUES LESS THAN ('2015-06-03') ENGINE = InnoDB,
 PARTITION p20150603 VALUES LESS THAN ('2015-06-04') ENGINE = InnoDB,
 PARTITION p20150604 VALUES LESS THAN ('2015-06-05') ENGINE = InnoDB,
 PARTITION p20150605 VALUES LESS THAN ('2015-06-06') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_servicestatus`
--

DROP TABLE IF EXISTS `db_data_servicestatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_servicestatus` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `db_type` varchar(32) DEFAULT NULL,
  `service_name` varchar(128) DEFAULT NULL,
  `machine_name` varchar(64) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `agent_time` datetime(3) DEFAULT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`,`insert_time`),
  KEY `idx_time1` (`insert_time`),
  KEY `index_2` (`machine_name`,`agent_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(insert_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_transaction`
--

DROP TABLE IF EXISTS `db_data_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_transaction` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `counts` int(11) DEFAULT NULL,
  PRIMARY KEY (`rid`,`data_time`),
  KEY `idx_time` (`data_time`),
  KEY `idx_machine` (`machine_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `db_data_transactiondetail`
--

DROP TABLE IF EXISTS `db_data_transactiondetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_data_transactiondetail` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `spid` int(11) DEFAULT NULL,
  `status` varchar(64) DEFAULT NULL,
  `login_name` varchar(128) DEFAULT NULL,
  `con_hostname` varchar(128) DEFAULT NULL,
  `db_name` varchar(128) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `time_s` int(11) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`rid`,`data_time`),
  KEY `idx_time` (`data_time`),
  KEY `idx_machinetime` (`machine_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_bbchart`
--

DROP TABLE IF EXISTS `dbmonitor_cf_bbchart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_bbchart` (
  `dbtype` varchar(45) NOT NULL,
  `category` varchar(45) NOT NULL,
  `subcategory` varchar(45) NOT NULL,
  `counterid` int(11) NOT NULL,
  PRIMARY KEY (`dbtype`,`category`,`subcategory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_counter_redis`
--

DROP TABLE IF EXISTS `dbmonitor_cf_counter_redis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_counter_redis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbtype` varchar(45) NOT NULL,
  `countertype` int(11) NOT NULL,
  `object_type` varchar(45) DEFAULT NULL,
  `object_name` varchar(45) DEFAULT NULL,
  `counter_name` varchar(45) DEFAULT NULL,
  `displayname` varchar(50) DEFAULT NULL,
  `unit` varchar(10) NOT NULL,
  `redline` decimal(10,0) DEFAULT NULL,
  `yellowline` decimal(10,0) DEFAULT NULL,
  `max` decimal(10,0) DEFAULT NULL,
  `divisor` decimal(20,10) NOT NULL DEFAULT '1.0000000000',
  `redis_key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_counter_redis_20160427`
--

DROP TABLE IF EXISTS `dbmonitor_cf_counter_redis_20160427`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_counter_redis_20160427` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbtype` varchar(45) NOT NULL,
  `countertype` int(11) NOT NULL,
  `object_type` varchar(45) DEFAULT NULL,
  `object_name` varchar(45) DEFAULT NULL,
  `counter_name` varchar(45) DEFAULT NULL,
  `displayname` varchar(50) DEFAULT NULL,
  `unit` varchar(10) NOT NULL,
  `redline` decimal(10,0) DEFAULT NULL,
  `yellowline` decimal(10,0) DEFAULT NULL,
  `max` decimal(10,0) DEFAULT NULL,
  `divisor` decimal(20,10) NOT NULL DEFAULT '1.0000000000',
  `redis_key` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_counters`
--

DROP TABLE IF EXISTS `dbmonitor_cf_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_counters` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `db_type` varchar(24) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `counter_name` varchar(128) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`),
  KEY `idx_counter_name` (`counter_name`),
  KEY `idx_dbtype` (`db_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_custom`
--

DROP TABLE IF EXISTS `dbmonitor_cf_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_custom` (
  `empcode` varchar(50) NOT NULL,
  `warning` bit(1) NOT NULL,
  `db_list` varchar(200) DEFAULT NULL,
  `bu_list` varchar(2048) DEFAULT NULL,
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`empcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_help`
--

DROP TABLE IF EXISTS `dbmonitor_cf_help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_help` (
  `category` varchar(50) NOT NULL,
  `helpdata` longtext NOT NULL,
  `sequence` int(11) NOT NULL DEFAULT '0',
  `lastupdatetime` datetime NOT NULL,
  PRIMARY KEY (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_itemsource`
--

DROP TABLE IF EXISTS `dbmonitor_cf_itemsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_itemsource` (
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `item_group` varchar(48) NOT NULL,
  `data_sql` text NOT NULL,
  `definition` varchar(1024) NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`counter_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_itemsource_20160506`
--

DROP TABLE IF EXISTS `dbmonitor_cf_itemsource_20160506`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_itemsource_20160506` (
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `item_group` varchar(48) NOT NULL,
  `data_sql` text NOT NULL,
  `definition` varchar(1024) NOT NULL,
  `remark` varchar(500) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`counter_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_jobruntime`
--

DROP TABLE IF EXISTS `dbmonitor_cf_jobruntime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_jobruntime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `red_range` double DEFAULT NULL,
  `yellow_range` double DEFAULT NULL,
  `ExpireTime` datetime DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_navmenu`
--

DROP TABLE IF EXISTS `dbmonitor_cf_navmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_navmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `url` varchar(500) NOT NULL,
  `parentid` int(11) NOT NULL,
  `target` varchar(20) NOT NULL,
  `sequence` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_portal`
--

DROP TABLE IF EXISTS `dbmonitor_cf_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_portal` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(50) DEFAULT NULL,
  `metro_type` varchar(50) DEFAULT NULL,
  `site_description` varchar(500) DEFAULT NULL,
  `tile_label` varchar(50) DEFAULT NULL,
  `tile_type` varchar(50) DEFAULT NULL,
  `site_type` varchar(50) DEFAULT NULL,
  `img_name` varchar(500) DEFAULT NULL,
  `detail` varchar(50) DEFAULT NULL,
  `op_color` varchar(50) DEFAULT NULL,
  `site_url` varchar(500) DEFAULT NULL,
  `searchlist` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_usercustom`
--

DROP TABLE IF EXISTS `dbmonitor_cf_usercustom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_usercustom` (
  `empcode` varchar(50) NOT NULL,
  `winmodules` varchar(1000) DEFAULT NULL,
  `linuxmodules` varchar(1000) DEFAULT NULL,
  `mssqlcounters` varchar(1500) DEFAULT NULL,
  `mysqlcounters` varchar(1500) DEFAULT NULL,
  `mongocounters` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`empcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_whitelist`
--

DROP TABLE IF EXISTS `dbmonitor_cf_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `agg` varchar(10) NOT NULL,
  `red_range` double NOT NULL,
  `yellow_range` double NOT NULL,
  `expiretime` datetime DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `maintenancebegin` datetime DEFAULT NULL,
  `maintenanceend` datetime DEFAULT NULL,
  `job_type` varchar(10) DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_whitelist_bak20150929`
--

DROP TABLE IF EXISTS `dbmonitor_cf_whitelist_bak20150929`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_whitelist_bak20150929` (
  `id` int(11) NOT NULL DEFAULT '0',
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `red_range` double DEFAULT NULL,
  `yellow_range` double DEFAULT NULL,
  `ExpireTime` datetime DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MaintenanceBeginTime` datetime DEFAULT NULL,
  `MaintenanceEndTime` datetime DEFAULT NULL,
  `job_type` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_cf_whitelist_old`
--

DROP TABLE IF EXISTS `dbmonitor_cf_whitelist_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_cf_whitelist_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `red_range` double DEFAULT NULL,
  `yellow_range` double DEFAULT NULL,
  `ExpireTime` datetime DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MaintenanceBeginTime` datetime DEFAULT NULL,
  `MaintenanceEndTime` datetime DEFAULT NULL,
  `job_type` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_clogresult`
--

DROP TABLE IF EXISTS `dbmonitor_data_clogresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_clogresult` (
  `machine_name` varchar(128) NOT NULL,
  `data_time` datetime DEFAULT NULL,
  `slowsql_status` int(11) DEFAULT NULL,
  `failure_status` int(11) DEFAULT NULL,
  `timeout_status` int(11) DEFAULT NULL,
  `timecost_9999ms` int(11) DEFAULT NULL,
  `exec_failure` int(11) DEFAULT NULL,
  `error_timeout` int(11) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_clogresult_history`
--

DROP TABLE IF EXISTS `dbmonitor_data_clogresult_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_clogresult_history` (
  `service_name` varchar(64) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `db_type` varchar(32) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `slowsql_status` int(11) DEFAULT NULL,
  `failure_status` int(11) DEFAULT NULL,
  `timeout_status` int(11) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_counterlastvalue`
--

DROP TABLE IF EXISTS `dbmonitor_data_counterlastvalue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_counterlastvalue` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `data_time` datetime DEFAULT NULL,
  `counter_value` float DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`object_name`,`counter_name`,`instance_name`),
  KEY `idx_insertime` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_monitorresult`
--

DROP TABLE IF EXISTS `dbmonitor_data_monitorresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_monitorresult` (
  `service_name` varchar(64) NOT NULL,
  `host_name` varchar(64) NOT NULL,
  `db_type` varchar(32) NOT NULL,
  `machine_name` varchar(128) NOT NULL,
  `agent` int(11) NOT NULL,
  `tran` int(11) NOT NULL,
  `cpu` int(11) NOT NULL,
  `uc` int(11) NOT NULL,
  `block` int(11) NOT NULL,
  `mem` int(11) NOT NULL,
  `disk` int(11) NOT NULL,
  `repl` int(11) NOT NULL,
  `net` int(11) NOT NULL,
  `io` int(11) NOT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`),
  KEY `idx_agent_insert_time_service_name` (`agent`,`update_time`,`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_monitorresult_history`
--

DROP TABLE IF EXISTS `dbmonitor_data_monitorresult_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_monitorresult_history` (
  `service_name` varchar(64) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `db_type` varchar(32) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL,
  `agent` int(11) DEFAULT NULL,
  `tran` int(11) DEFAULT NULL,
  `cpu` int(11) DEFAULT NULL,
  `uc` int(11) DEFAULT NULL,
  `block` int(11) DEFAULT NULL,
  `mem` int(11) DEFAULT NULL,
  `disk` int(11) DEFAULT NULL,
  `repl` int(11) DEFAULT NULL,
  `net` int(11) DEFAULT NULL,
  `io` int(11) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_time`),
  KEY `idx_data_time` (`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_monitorresult_old`
--

DROP TABLE IF EXISTS `dbmonitor_data_monitorresult_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_monitorresult_old` (
  `service_name` varchar(64) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `db_type` varchar(32) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL,
  `agent` int(11) DEFAULT NULL,
  `tran` int(11) DEFAULT NULL,
  `cpu` int(11) DEFAULT NULL,
  `uc` int(11) DEFAULT NULL,
  `block` int(11) DEFAULT NULL,
  `mem` int(11) DEFAULT NULL,
  `disk` int(11) DEFAULT NULL,
  `repl` int(11) DEFAULT NULL,
  `net` int(11) DEFAULT NULL,
  `io` int(11) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`),
  KEY `idx_agent_insert_time_service_name` (`agent`,`insert_time`,`service_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbmonitor_data_monitorresultdetail`
--

DROP TABLE IF EXISTS `dbmonitor_data_monitorresultdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbmonitor_data_monitorresultdetail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `service_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `db_type` varchar(32) NOT NULL DEFAULT '',
  `counter_name` varchar(128) NOT NULL DEFAULT '',
  `instance_name` varchar(128) NOT NULL DEFAULT '',
  `counter_value` float DEFAULT NULL,
  `counter_status` int(11) DEFAULT NULL,
  `data_time` datetime NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`data_time`),
  KEY `idx_machine` (`machine_name`,`data_time`),
  KEY `idx_machine_counter` (`machine_name`,`counter_name`,`data_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_time)
(PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION pmaxvalue VALUES LESS THAN (MAXVALUE) ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbticket_columns`
--

DROP TABLE IF EXISTS `dbticket_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbticket_columns` (
  `dbname` varchar(150) NOT NULL,
  `tablename` varchar(125) NOT NULL,
  `columnname` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dbname`,`tablename`,`columnname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dbticket_tables`
--

DROP TABLE IF EXISTS `dbticket_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbticket_tables` (
  `dbname` varchar(150) NOT NULL,
  `tablename` varchar(125) NOT NULL,
  `table_owner` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `data_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dbname`,`tablename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_ag`
--

DROP TABLE IF EXISTS `dic_mssql_ag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_ag` (
  `host_name` varchar(128) DEFAULT NULL,
  `primary_host_name` varchar(128) DEFAULT NULL,
  `ag_name` varchar(128) DEFAULT NULL,
  `role_desc` varchar(9) DEFAULT NULL,
  `db_name` varchar(128) DEFAULT NULL,
  `endpoint_url` varchar(256) DEFAULT NULL,
  `availability_mode_desc` varchar(60) DEFAULT NULL,
  `failover_mode_desc` varchar(60) DEFAULT NULL,
  `primary_role_allow_connections_desc` varchar(60) DEFAULT NULL,
  `secondary_role_allow_connections_desc` varchar(60) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `IDX1` (`role_desc`,`host_name`),
  KEY `IDX2` (`primary_host_name`),
  KEY `IDX3` (`host_name`),
  KEY `IDX4` (`ag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_configuration`
--

DROP TABLE IF EXISTS `dic_mssql_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_configuration` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `configuration_name` varchar(128) NOT NULL DEFAULT '',
  `mininum` int(11) DEFAULT NULL,
  `maxinum` int(11) DEFAULT NULL,
  `config_value` int(11) DEFAULT NULL,
  `run_value` int(11) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`configuration_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_configuration_history`
--

DROP TABLE IF EXISTS `dic_mssql_configuration_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_configuration_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `configuration_name` varchar(128) NOT NULL DEFAULT '',
  `mininum` int(11) DEFAULT NULL,
  `maxinum` int(11) DEFAULT NULL,
  `config_value` int(11) DEFAULT NULL,
  `run_value` int(11) DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`configuration_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_database_principal`
--

DROP TABLE IF EXISTS `dic_mssql_database_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_database_principal` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `db_id` int(11) NOT NULL DEFAULT '0',
  `database_principal_id` int(11) NOT NULL DEFAULT '0',
  `type_desc` varchar(128) DEFAULT NULL,
  `default_schema_name` varchar(128) DEFAULT NULL,
  `principal_name` varchar(128) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `owning_principal_id` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`db_id`,`database_principal_id`),
  KEY `idx2` (`machine_name`,`db_id`,`principal_name`),
  KEY `idx3` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_database_principal_history`
--

DROP TABLE IF EXISTS `dic_mssql_database_principal_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_database_principal_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `db_id` int(11) NOT NULL DEFAULT '0',
  `database_principal_id` int(11) NOT NULL DEFAULT '0',
  `type_desc` varchar(128) DEFAULT NULL,
  `default_schema_name` varchar(128) DEFAULT NULL,
  `principal_name` varchar(128) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `owning_principal_id` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`db_id`,`database_principal_id`),
  KEY `idx2` (`machine_name`,`data_date`,`db_id`,`principal_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_job`
--

DROP TABLE IF EXISTS `dic_mssql_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_job` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `job_id` varchar(56) NOT NULL DEFAULT '',
  `job_name` varchar(128) DEFAULT NULL,
  `is_enabled` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  `owner_sid` varbinary(85) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`job_id`),
  KEY `idx2` (`machine_name`,`job_name`),
  KEY `idx3` (`job_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_job_schedule`
--

DROP TABLE IF EXISTS `dic_mssql_job_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_job_schedule` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `job_id` varchar(56) NOT NULL DEFAULT '',
  `schedule_id` int(11) NOT NULL,
  `frequency` varchar(1024) DEFAULT NULL,
  `sub_frequency` varchar(1024) DEFAULT NULL,
  `freq_type` int(11) DEFAULT NULL,
  `freq_interval` int(11) DEFAULT NULL,
  `freq_subday_type` int(11) DEFAULT NULL,
  `freq_subday_interval` int(11) DEFAULT NULL,
  `freq_relative_interval` int(11) DEFAULT NULL,
  `freq_recurrence_factor` int(11) DEFAULT NULL,
  `active_start_date` int(11) DEFAULT NULL,
  `active_end_date` int(11) DEFAULT NULL,
  `active_start_time` int(11) DEFAULT NULL,
  `active_end_time` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `enabled` tinyint(4) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`job_id`,`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_job_step`
--

DROP TABLE IF EXISTS `dic_mssql_job_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_job_step` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `job_id` varchar(56) NOT NULL DEFAULT '',
  `step_id` int(11) NOT NULL DEFAULT '0',
  `step_name` varchar(128) DEFAULT NULL,
  `command_type` varchar(128) DEFAULT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `command` varchar(8000) DEFAULT NULL,
  `success_action` varchar(48) DEFAULT NULL,
  `fail_action` varchar(48) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`job_id`,`step_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_dbuser_permission`
--

DROP TABLE IF EXISTS `dic_mssql_login_dbuser_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_dbuser_permission` (
  `machine_name` varchar(128) DEFAULT NULL,
  `db_id` int(11) DEFAULT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `schema_name` varchar(128) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `column_id` int(11) DEFAULT NULL,
  `type_name` varchar(128) DEFAULT NULL,
  `db_user_id` int(11) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `idx1` (`machine_name`,`db_id`,`db_user_id`),
  KEY `idx2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_dbuser_permission_history`
--

DROP TABLE IF EXISTS `dic_mssql_login_dbuser_permission_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_dbuser_permission_history` (
  `machine_name` varchar(128) DEFAULT NULL,
  `db_id` int(11) DEFAULT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `schema_name` varchar(128) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `column_id` int(11) DEFAULT NULL,
  `type_name` varchar(128) DEFAULT NULL,
  `db_user_id` int(11) DEFAULT NULL,
  `data_date` date DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_dbuser_role`
--

DROP TABLE IF EXISTS `dic_mssql_login_dbuser_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_dbuser_role` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `db_id` varchar(128) NOT NULL DEFAULT '',
  `db_user_id` int(11) NOT NULL DEFAULT '0',
  `db_role_id` int(11) NOT NULL DEFAULT '0',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`db_id`,`db_user_id`,`db_role_id`),
  KEY `idx` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_dbuser_role_history`
--

DROP TABLE IF EXISTS `dic_mssql_login_dbuser_role_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_dbuser_role_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `db_id` varchar(128) NOT NULL DEFAULT '',
  `db_user_id` int(11) NOT NULL DEFAULT '0',
  `db_role_id` int(11) NOT NULL DEFAULT '0',
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`db_id`,`db_user_id`,`db_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_serverlogin_permission`
--

DROP TABLE IF EXISTS `dic_mssql_login_serverlogin_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_serverlogin_permission` (
  `machine_name` varchar(128) DEFAULT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `server_principal` varchar(128) DEFAULT NULL,
  `server_login_id` int(11) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `idx1` (`machine_name`,`server_login_id`,`permission_name`),
  KEY `idx2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_serverlogin_permission_history`
--

DROP TABLE IF EXISTS `dic_mssql_login_serverlogin_permission_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_serverlogin_permission_history` (
  `machine_name` varchar(128) DEFAULT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `server_principal` varchar(128) DEFAULT NULL,
  `server_login_id` int(11) DEFAULT NULL,
  `data_date` date DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `idx1` (`machine_name`,`data_date`,`server_login_id`,`permission_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_serverlogin_role`
--

DROP TABLE IF EXISTS `dic_mssql_login_serverlogin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_serverlogin_role` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `server_login_id` int(11) NOT NULL DEFAULT '0',
  `server_role_id` int(11) NOT NULL DEFAULT '0',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`server_login_id`,`server_role_id`),
  KEY `idx` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_login_serverlogin_role_history`
--

DROP TABLE IF EXISTS `dic_mssql_login_serverlogin_role_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_login_serverlogin_role_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `server_login_id` int(11) NOT NULL DEFAULT '0',
  `server_role_id` int(11) NOT NULL DEFAULT '0',
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`server_login_id`,`server_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_replication`
--

DROP TABLE IF EXISTS `dic_mssql_replication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_replication` (
  `machine_name` varchar(128) DEFAULT NULL,
  `publisher_db` varchar(128) DEFAULT NULL,
  `publication` varchar(128) NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `source_owner` varchar(128) DEFAULT NULL,
  `article` varchar(128) DEFAULT NULL,
  `sync_type` int(11) DEFAULT NULL,
  `subscriber_server` varchar(128) DEFAULT NULL,
  `subscriber_dns` varchar(128) DEFAULT NULL,
  `subscriber_machine_name` varchar(128) DEFAULT NULL,
  `subscriber_db` varchar(128) DEFAULT NULL,
  `destination_owner` varchar(128) DEFAULT NULL,
  `destination_object` varchar(128) DEFAULT NULL,
  `filter` varchar(2000) DEFAULT NULL,
  `columnname` varchar(8000) DEFAULT NULL,
  `pre_creation_cmd` varchar(10) DEFAULT NULL,
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `IDX1` (`publisher_db`,`machine_name`,`object_id`),
  KEY `IDX2` (`subscriber_machine_name`,`subscriber_db`,`destination_object`),
  KEY `idx3` (`publication`),
  KEY `idx_1` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_replication_history`
--

DROP TABLE IF EXISTS `dic_mssql_replication_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_replication_history` (
  `machine_name` varchar(128) DEFAULT NULL,
  `publisher_db` varchar(128) DEFAULT NULL,
  `publication` varchar(128) NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `source_owner` varchar(128) DEFAULT NULL,
  `article` varchar(128) DEFAULT NULL,
  `subscriber_server` varchar(128) DEFAULT NULL,
  `subscriber_dns` varchar(128) DEFAULT NULL,
  `subscriber_machine_name` varchar(128) DEFAULT NULL,
  `subscriber_db` varchar(128) DEFAULT NULL,
  `destination_owner` varchar(128) DEFAULT NULL,
  `destination_object` varchar(128) DEFAULT NULL,
  `filter` varchar(2000) DEFAULT NULL,
  `columnname` varchar(8000) DEFAULT NULL,
  `pre_creation_cmd` varchar(10) DEFAULT NULL,
  `data_date` date DEFAULT NULL,
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  KEY `IDX1` (`publisher_db`,`data_date`,`machine_name`,`object_id`),
  KEY `IDX2` (`subscriber_machine_name`,`data_date`,`subscriber_db`,`destination_object`),
  KEY `idx3` (`publication`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_server_principal`
--

DROP TABLE IF EXISTS `dic_mssql_server_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_server_principal` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `server_principal_id` int(11) NOT NULL DEFAULT '0',
  `type_desc` varchar(128) DEFAULT NULL,
  `principal_name` varchar(128) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `is_disabled` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`server_principal_id`),
  KEY `idx2` (`machine_name`,`principal_name`),
  KEY `idx3` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mssql_server_principal_history`
--

DROP TABLE IF EXISTS `dic_mssql_server_principal_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mssql_server_principal_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `server_principal_id` int(11) NOT NULL DEFAULT '0',
  `type_desc` varchar(128) DEFAULT NULL,
  `principal_name` varchar(128) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `is_disabled` int(11) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `modify_date` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`server_principal_id`),
  KEY `idx2` (`machine_name`,`data_date`,`principal_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_columns`
--

DROP TABLE IF EXISTS `dic_mysql_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_columns` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `ordinal_position` bigint(21) DEFAULT NULL,
  `column_default` longtext,
  `is_nullable` varchar(3) DEFAULT NULL,
  `data_type` varchar(64) DEFAULT NULL,
  `character_maximum_length` bigint(21) DEFAULT NULL,
  `character_octet_length` bigint(21) DEFAULT NULL,
  `numeric_precision` bigint(21) DEFAULT NULL,
  `numeric_scale` bigint(21) DEFAULT NULL,
  `datetime_precision` bigint(21) DEFAULT NULL,
  `character_set_name` varchar(32) DEFAULT NULL,
  `collation_name` varchar(32) DEFAULT NULL,
  `column_type` longtext,
  `column_key` varchar(3) DEFAULT NULL,
  `extra` varchar(30) DEFAULT NULL,
  `privileges` varchar(80) DEFAULT NULL,
  `column_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`catalog_name`,`database_name`,`table_name`,`column_name`),
  KEY `IDX` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_columns_history`
--

DROP TABLE IF EXISTS `dic_mysql_columns_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_columns_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `ordinal_position` bigint(21) DEFAULT NULL,
  `column_default` longtext,
  `is_nullable` varchar(3) DEFAULT NULL,
  `data_type` varchar(64) DEFAULT NULL,
  `character_maximum_length` bigint(21) DEFAULT NULL,
  `character_octet_length` bigint(21) DEFAULT NULL,
  `numeric_precision` bigint(21) DEFAULT NULL,
  `numeric_scale` bigint(21) DEFAULT NULL,
  `datetime_precision` bigint(21) DEFAULT NULL,
  `character_set_name` varchar(32) DEFAULT NULL,
  `collation_name` varchar(32) DEFAULT NULL,
  `column_type` longtext,
  `column_key` varchar(3) DEFAULT NULL,
  `extra` varchar(30) DEFAULT NULL,
  `privileges` varchar(80) DEFAULT NULL,
  `column_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`catalog_name`,`database_name`,`table_name`,`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_configuration`
--

DROP TABLE IF EXISTS `dic_mysql_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_configuration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `variable_name` varchar(128) NOT NULL DEFAULT '',
  `value` varchar(512) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_1` (`collection_time`),
  KEY `idx_2` (`machine_name`,`collection_time`),
  KEY `idx_3` (`machine_name`,`variable_name`,`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_database`
--

DROP TABLE IF EXISTS `dic_mysql_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_database` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `default_character_set_name` varchar(32) DEFAULT NULL,
  `default_collation_name` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`catalog_name`,`database_name`),
  KEY `IDX` (`database_name`),
  KEY `IDX2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_database_history`
--

DROP TABLE IF EXISTS `dic_mysql_database_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_database_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `default_character_set_name` varchar(32) DEFAULT NULL,
  `default_collation_name` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`catalog_name`,`database_name`),
  KEY `IDX` (`database_name`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_dbsize`
--

DROP TABLE IF EXISTS `dic_mysql_dbsize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_dbsize` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `database_size(kb)` bigint(20) DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_insert_timestamp` (`insert_timestamp`),
  KEY `idx_database_name_insert_timestamp` (`database_name`,`insert_timestamp`),
  KEY `idx_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_index`
--

DROP TABLE IF EXISTS `dic_mysql_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_index` (
  `machine_name` varchar(128) NOT NULL,
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `non_unique` bigint(1) DEFAULT NULL,
  `index_name` varchar(64) NOT NULL DEFAULT '',
  `index_column` varchar(1000) DEFAULT NULL,
  `collation` varchar(1) DEFAULT NULL,
  `index_type` varchar(16) DEFAULT NULL,
  `comment` varchar(16) DEFAULT NULL,
  `index_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`catalog_name`,`database_name`,`table_name`,`index_name`),
  KEY `IDX` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_index_history`
--

DROP TABLE IF EXISTS `dic_mysql_index_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_index_history` (
  `machine_name` varchar(128) NOT NULL,
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `non_unique` bigint(1) DEFAULT NULL,
  `index_name` varchar(64) NOT NULL DEFAULT '',
  `index_column` varchar(1000) DEFAULT NULL,
  `collation` varchar(1) DEFAULT NULL,
  `index_type` varchar(16) DEFAULT NULL,
  `comment` varchar(16) DEFAULT NULL,
  `index_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`catalog_name`,`database_name`,`table_name`,`index_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_proc`
--

DROP TABLE IF EXISTS `dic_mysql_proc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_proc` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `proc_name` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(64) DEFAULT NULL,
  `specific_name` varchar(64) DEFAULT NULL,
  `language` varchar(64) DEFAULT NULL,
  `sql_data_access` varchar(64) DEFAULT NULL,
  `is_deterministic` varchar(64) DEFAULT NULL,
  `security_type` varchar(64) DEFAULT NULL,
  `param_list` varchar(2000) DEFAULT NULL,
  `returns` varchar(2000) DEFAULT NULL,
  `body` longtext,
  `definer` varchar(77) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `sql_mode` varchar(64) DEFAULT NULL,
  `comment` text,
  `collation_connection` varchar(32) DEFAULT NULL,
  `db_collation` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`database_name`,`proc_name`),
  KEY `IDX` (`proc_name`),
  KEY `IDX2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_proc_history`
--

DROP TABLE IF EXISTS `dic_mysql_proc_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_proc_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `proc_name` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(64) DEFAULT NULL,
  `specific_name` varchar(64) DEFAULT NULL,
  `language` varchar(64) DEFAULT NULL,
  `sql_data_access` varchar(64) DEFAULT NULL,
  `is_deterministic` varchar(64) DEFAULT NULL,
  `security_type` varchar(64) DEFAULT NULL,
  `param_list` varchar(2000) DEFAULT NULL,
  `returns` varchar(2000) DEFAULT NULL,
  `body` longtext,
  `definer` varchar(77) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `sql_mode` varchar(64) DEFAULT NULL,
  `comment` text,
  `collation_connection` varchar(32) DEFAULT NULL,
  `db_collation` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`database_name`,`proc_name`),
  KEY `IDX` (`proc_name`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_tables`
--

DROP TABLE IF EXISTS `dic_mysql_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_tables` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `table_type` varchar(64) DEFAULT NULL,
  `engine` varchar(64) DEFAULT NULL,
  `version` bigint(21) DEFAULT NULL,
  `row_format` varchar(10) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `table_collation` varchar(32) DEFAULT NULL,
  `create_options` varchar(255) DEFAULT NULL,
  `table_comment` varchar(2048) DEFAULT NULL,
  `view_definition` longtext,
  `is_updatable` varchar(3) DEFAULT NULL,
  `definer` varchar(77) DEFAULT NULL,
  `security_type` varchar(7) DEFAULT NULL,
  `character_set_client` varchar(32) DEFAULT NULL,
  `collation_connection` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`catalog_name`,`database_name`,`table_name`),
  KEY `IDX` (`table_name`),
  KEY `IDX2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_tables_history`
--

DROP TABLE IF EXISTS `dic_mysql_tables_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_tables_history` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `table_type` varchar(64) DEFAULT NULL,
  `engine` varchar(64) DEFAULT NULL,
  `version` bigint(21) DEFAULT NULL,
  `row_format` varchar(10) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `table_collation` varchar(32) DEFAULT NULL,
  `create_options` varchar(255) DEFAULT NULL,
  `table_comment` varchar(2048) DEFAULT NULL,
  `view_definition` longtext,
  `is_updatable` varchar(3) DEFAULT NULL,
  `definer` varchar(77) DEFAULT NULL,
  `security_type` varchar(7) DEFAULT NULL,
  `character_set_client` varchar(32) DEFAULT NULL,
  `collation_connection` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`data_date`,`catalog_name`,`database_name`,`table_name`),
  KEY `IDX2` (`table_name`,`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_user_grants`
--

DROP TABLE IF EXISTS `dic_mysql_user_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_user_grants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `grantee` varchar(128) NOT NULL DEFAULT '',
  `show_grants` varchar(8000) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX` (`machine_name`,`grantee`),
  KEY `IDX2` (`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dic_mysql_user_grants_history`
--

DROP TABLE IF EXISTS `dic_mysql_user_grants_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_user_grants_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `grantee` varchar(128) NOT NULL DEFAULT '',
  `show_grants` varchar(8000) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `data_date` date NOT NULL DEFAULT '0000-00-00',
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`data_date`),
  KEY `IDX` (`machine_name`,`grantee`,`data_date`),
  KEY `IDX2` (`data_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50500 PARTITION BY RANGE  COLUMNS(data_date)
(PARTITION p20160914 VALUES LESS THAN ('2016-09-15') ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN ('2016-09-16') ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN ('2016-09-17') ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN ('2016-09-18') ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN ('2016-09-19') ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN ('2016-09-20') ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN ('2016-09-21') ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN ('2016-09-22') ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN ('2016-09-23') ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN ('2016-09-24') ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN ('2016-09-25') ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN ('2016-09-26') ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN ('2016-09-27') ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN ('2016-09-28') ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN ('2016-09-29') ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_columns`
--

DROP TABLE IF EXISTS `dict_mssql_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `db_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `column_id` int(11) NOT NULL,
  `schema_name` varchar(128) DEFAULT NULL,
  `table_name` varchar(128) DEFAULT NULL,
  `column_name` varchar(128) NOT NULL DEFAULT '',
  `is_identity` smallint(6) NOT NULL DEFAULT '0',
  `is_pk` smallint(6) NOT NULL DEFAULT '0',
  `data_type` varchar(128) NOT NULL DEFAULT '',
  `column_length` varchar(50) NOT NULL DEFAULT '',
  `is_nullable` smallint(6) NOT NULL DEFAULT '0',
  `default_value` varchar(8000) NOT NULL DEFAULT '',
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`db_id`,`object_id`,`column_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_database`
--

DROP TABLE IF EXISTS `dict_mssql_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_database` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `db_id` int(11) NOT NULL,
  `db_name` varchar(128) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `db_status` varchar(60) DEFAULT NULL,
  `mirroring_partner_instance` varchar(128) DEFAULT NULL,
  `mirroring_partner_name` varchar(128) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`db_name`),
  KEY `idx2` (`machine_name`,`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_dbnewrole`
--

DROP TABLE IF EXISTS `dict_mssql_dbnewrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_dbnewrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `rolename` varchar(128) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_dbstorage`
--

DROP TABLE IF EXISTS `dict_mssql_dbstorage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_dbstorage` (
  `ci_located` varchar(512) DEFAULT NULL,
  `disk_array` varchar(100) DEFAULT NULL,
  `total_space_gb` int(11) DEFAULT NULL,
  `free_space_gb` int(11) DEFAULT NULL,
  `win_cluster_name` varchar(100) DEFAULT NULL,
  `nm` varchar(64) DEFAULT NULL,
  `shortci` varchar(64) DEFAULT NULL,
  `ci_model` varchar(32) DEFAULT NULL,
  `service_name` varchar(100) DEFAULT NULL,
  `maintain_batch` int(11) DEFAULT NULL,
  `dbserver_edition` varchar(512) DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_dbuserpermission`
--

DROP TABLE IF EXISTS `dict_mssql_dbuserpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_dbuserpermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `schemaname` varchar(128) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `columnname` varchar(128) DEFAULT NULL,
  `loginname` varchar(128) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_dbuserrole`
--

DROP TABLE IF EXISTS `dict_mssql_dbuserrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_dbuserrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `username` varchar(128) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `rolename` varchar(128) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_depends`
--

DROP TABLE IF EXISTS `dict_mssql_depends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_depends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `host_name` varchar(128) NOT NULL,
  `db_id` int(11) NOT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `schema_name` varchar(128) DEFAULT NULL,
  `object_name` varchar(128) DEFAULT NULL,
  `object_type` varchar(45) DEFAULT NULL,
  `object_id` int(11) NOT NULL,
  `referencing_minor_id` int(11) NOT NULL DEFAULT '0',
  `referencing_class` int(11) NOT NULL DEFAULT '0',
  `referencing_class_desc` varchar(128) NOT NULL DEFAULT '',
  `is_schema_bound_reference` int(11) NOT NULL DEFAULT '0',
  `referenced_class` int(11) NOT NULL DEFAULT '0',
  `referenced_class_desc` varchar(128) NOT NULL DEFAULT '',
  `referenced_machine_name` varchar(128) NOT NULL DEFAULT '',
  `referenced_db_name` varchar(128) NOT NULL DEFAULT '',
  `referenced_schema_name` varchar(128) NOT NULL DEFAULT '',
  `referenced_object_name` varchar(128) NOT NULL DEFAULT '',
  `referenced_minor_id` int(11) NOT NULL DEFAULT '0',
  `is_caller_dependent` int(11) NOT NULL DEFAULT '0',
  `is_ambiguous` int(11) NOT NULL DEFAULT '0',
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`db_id`,`object_id`),
  KEY `idx2` (`referenced_machine_name`,`referenced_db_name`,`referenced_object_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_index`
--

DROP TABLE IF EXISTS `dict_mssql_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `db_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `index_id` int(11) NOT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `schema_name` varchar(128) DEFAULT NULL,
  `table_name` varchar(128) DEFAULT NULL,
  `index_name` varchar(128) NOT NULL DEFAULT '',
  `index_column` varchar(1000) NOT NULL DEFAULT '',
  `index_type` smallint(6) NOT NULL DEFAULT '0',
  `index_type_desc` varchar(256) NOT NULL DEFAULT '',
  `is_pk` tinyint(4) NOT NULL DEFAULT '0',
  `is_unique` tinyint(4) NOT NULL DEFAULT '0',
  `is_disabled` tinyint(4) NOT NULL DEFAULT '0',
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`db_id`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_jobinfo`
--

DROP TABLE IF EXISTS `dict_mssql_jobinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_jobinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `job_id` varchar(128) DEFAULT NULL,
  `job_name` varchar(256) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `job_desc` varchar(4000) DEFAULT NULL,
  `job_state` varchar(64) DEFAULT NULL,
  `version_number` int(11) DEFAULT NULL,
  `job_create_time` datetime DEFAULT NULL,
  `job_modify_time` datetime DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_jobschedule`
--

DROP TABLE IF EXISTS `dict_mssql_jobschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_jobschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `job_id` varchar(128) DEFAULT NULL,
  `job_name` varchar(256) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `schedule_name` varchar(1000) DEFAULT NULL,
  `schedule_state` varchar(64) DEFAULT NULL,
  `schedule_create_time` datetime DEFAULT NULL,
  `schedule_modify_time` datetime DEFAULT NULL,
  `version_number` int(11) DEFAULT NULL,
  `scheduledesc` varchar(1000) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_jobstep`
--

DROP TABLE IF EXISTS `dict_mssql_jobstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_jobstep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `job_id` varchar(128) DEFAULT NULL,
  `job_name` varchar(256) DEFAULT NULL,
  `step_id` int(11) DEFAULT NULL,
  `step_name` varchar(1000) DEFAULT NULL,
  `command_type` varchar(64) DEFAULT NULL,
  `database_name` varchar(256) DEFAULT NULL,
  `command` longtext,
  `success_action` varchar(256) DEFAULT NULL,
  `fail_action` varchar(256) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_objects`
--

DROP TABLE IF EXISTS `dict_mssql_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `db_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `schema_name` varchar(128) NOT NULL DEFAULT '',
  `object_name` varchar(128) NOT NULL DEFAULT '',
  `object_type` varchar(2) NOT NULL DEFAULT '',
  `type_desc` varchar(128) NOT NULL DEFAULT '',
  `object_content` longtext,
  `create_date` datetime NOT NULL,
  `modify_date` datetime NOT NULL,
  `collection_time` datetime NOT NULL,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx1` (`machine_name`,`db_id`,`object_name`),
  KEY `idx2` (`machine_name`,`object_type`),
  KEY `idx3` (`machine_name`,`db_id`,`object_type`),
  KEY `idx4` (`object_type`,`object_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_routes`
--

DROP TABLE IF EXISTS `dict_mssql_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) NOT NULL,
  `ci_code` varchar(128) NOT NULL,
  `route_msg` varchar(1024) DEFAULT NULL,
  `net_msg` varchar(1024) DEFAULT NULL,
  `insert_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_serverloginpermissions`
--

DROP TABLE IF EXISTS `dict_mssql_serverloginpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_serverloginpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `class_desc` varchar(128) DEFAULT NULL,
  `state_desc` varchar(128) DEFAULT NULL,
  `permission_name` varchar(128) DEFAULT NULL,
  `server_principal` varchar(128) DEFAULT NULL,
  `loginname` varchar(128) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mssql_serverloginrole`
--

DROP TABLE IF EXISTS `dict_mssql_serverloginrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mssql_serverloginrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL,
  `loginname` varchar(128) DEFAULT NULL,
  `is_disabled` int(11) DEFAULT NULL,
  `sid` varbinary(85) DEFAULT NULL,
  `pwd_varbinary` varchar(256) DEFAULT NULL,
  `rolename` varchar(128) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mysql_columns`
--

DROP TABLE IF EXISTS `dict_mysql_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mysql_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `ordinal_position` bigint(21) DEFAULT NULL,
  `column_default` longtext,
  `is_nullable` varchar(3) DEFAULT NULL,
  `data_type` varchar(64) DEFAULT NULL,
  `character_maximum_length` bigint(21) DEFAULT NULL,
  `character_octet_length` bigint(21) DEFAULT NULL,
  `numeric_precision` bigint(21) DEFAULT NULL,
  `numeric_scale` bigint(21) DEFAULT NULL,
  `datetime_precision` bigint(21) DEFAULT NULL,
  `character_set_name` varchar(32) DEFAULT NULL,
  `collation_name` varchar(32) DEFAULT NULL,
  `column_type` longtext,
  `column_key` varchar(3) DEFAULT NULL,
  `extra` varchar(30) DEFAULT NULL,
  `privileges` varchar(80) DEFAULT NULL,
  `column_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX` (`machine_name`,`catalog_name`,`database_name`,`table_name`,`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mysql_configuration`
--

DROP TABLE IF EXISTS `dict_mysql_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mysql_configuration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `variable_name` varchar(128) NOT NULL DEFAULT '',
  `value` varchar(512) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_1` (`collection_time`),
  KEY `idx_2` (`machine_name`,`collection_time`),
  KEY `idx_3` (`machine_name`,`variable_name`,`collection_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mysql_database`
--

DROP TABLE IF EXISTS `dict_mysql_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mysql_database` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `default_character_set_name` varchar(32) DEFAULT NULL,
  `default_collation_name` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX` (`machine_name`,`catalog_name`,`database_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mysql_index`
--

DROP TABLE IF EXISTS `dict_mysql_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mysql_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `non_unique` bigint(1) DEFAULT NULL,
  `index_name` varchar(64) NOT NULL DEFAULT '',
  `index_column` varchar(1000) DEFAULT NULL,
  `collation` varchar(1) DEFAULT NULL,
  `index_type` varchar(16) DEFAULT NULL,
  `comment` varchar(16) DEFAULT NULL,
  `index_comment` varchar(1024) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX` (`machine_name`,`catalog_name`,`database_name`,`table_name`,`index_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_mysql_tables`
--

DROP TABLE IF EXISTS `dict_mysql_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_mysql_tables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `catalog_name` varchar(128) NOT NULL DEFAULT '',
  `database_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `table_type` varchar(64) DEFAULT NULL,
  `engine` varchar(64) DEFAULT NULL,
  `version` bigint(21) DEFAULT NULL,
  `row_format` varchar(10) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `table_collation` varchar(32) DEFAULT NULL,
  `create_options` varchar(255) DEFAULT NULL,
  `table_comment` varchar(2048) DEFAULT NULL,
  `view_definition` longtext,
  `is_updatable` varchar(3) DEFAULT NULL,
  `definer` varchar(77) DEFAULT NULL,
  `security_type` varchar(7) DEFAULT NULL,
  `character_set_client` varchar(32) DEFAULT NULL,
  `collation_connection` varchar(32) DEFAULT NULL,
  `collection_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX` (`machine_name`,`catalog_name`,`database_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dict_summary`
--

DROP TABLE IF EXISTS `dict_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict_summary` (
  `db_type` varchar(128) DEFAULT NULL,
  `env_type` varchar(128) DEFAULT NULL,
  `machine_name` varchar(128) DEFAULT NULL,
  `host_name` varchar(128) DEFAULT NULL,
  `service_name` varchar(128) DEFAULT NULL,
  `db_name` varchar(128) DEFAULT NULL,
  `collection_time` datetime DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `diff_mysql_configuration`
--

DROP TABLE IF EXISTS `diff_mysql_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diff_mysql_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `variables` varchar(200) DEFAULT NULL,
  `master_host` varchar(64) DEFAULT NULL,
  `slave_host` varchar(64) DEFAULT NULL,
  `master_value` varchar(200) DEFAULT NULL,
  `slave_value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `diff_mysql_index`
--

DROP TABLE IF EXISTS `diff_mysql_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diff_mysql_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `master_host` varchar(50) DEFAULT NULL,
  `slave_host` varchar(50) DEFAULT NULL,
  `database_name` varchar(128) DEFAULT NULL,
  `table_name` varchar(128) DEFAULT NULL,
  `index_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dns_list_xxwen`
--

DROP TABLE IF EXISTS `dns_list_xxwen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dns_list_xxwen` (
  `DNS` varchar(256) DEFAULT NULL,
  `in_ip` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `serverlist`
--

DROP TABLE IF EXISTS `serverlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serverlist` (
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `host_name` varchar(128) NOT NULL DEFAULT '',
  `service_name` varchar(128) NOT NULL DEFAULT '',
  `dns` varchar(256) NOT NULL DEFAULT '',
  `dns_port` varchar(128) NOT NULL DEFAULT '',
  `db_type` varchar(128) NOT NULL DEFAULT '',
  `env_type` varchar(128) NOT NULL DEFAULT '',
  `maintain_type` varchar(128) DEFAULT NULL,
  `available` int(4) NOT NULL DEFAULT '0',
  `monitor_status` int(4) NOT NULL DEFAULT '0',
  `closemonitor_durationmi` int(4) NOT NULL DEFAULT '0',
  `collect_standard` int(4) NOT NULL DEFAULT '0',
  `monitor_repl` int(4) NOT NULL DEFAULT '0',
  `collect_idleagent` int(4) NOT NULL DEFAULT '0',
  `collect_backup` int(4) NOT NULL DEFAULT '0',
  `collect_trace` int(4) NOT NULL DEFAULT '0',
  `monitor_alltrace` int(4) NOT NULL DEFAULT '0',
  `collect_agent` int(4) NOT NULL DEFAULT '0',
  `collect_dmv` int(4) NOT NULL DEFAULT '0',
  `collect_block` int(4) NOT NULL DEFAULT '0',
  `bb_status` int(4) NOT NULL DEFAULT '0',
  `bb_cpu` int(4) NOT NULL DEFAULT '0',
  `bb_uc` int(4) NOT NULL DEFAULT '0',
  `bb_block` int(4) NOT NULL DEFAULT '0',
  `bb_mem` int(4) NOT NULL DEFAULT '0',
  `bb_swap` int(4) NOT NULL DEFAULT '0',
  `bb_disk` int(4) NOT NULL DEFAULT '0',
  `bb_repl` int(4) NOT NULL DEFAULT '0',
  `bb_mirror` int(4) NOT NULL DEFAULT '0',
  `bb_tran` int(4) NOT NULL DEFAULT '0',
  `bb_net` int(4) NOT NULL DEFAULT '0',
  `bb_io` int(4) NOT NULL DEFAULT '0',
  `perf_status` int(4) NOT NULL DEFAULT '0',
  `perf_cpu` int(4) NOT NULL DEFAULT '0',
  `perf_uc` int(4) NOT NULL DEFAULT '0',
  `perf_block` int(4) NOT NULL DEFAULT '0',
  `perf_mem` int(4) NOT NULL DEFAULT '0',
  `perf_swap` int(4) NOT NULL DEFAULT '0',
  `perf_disk` int(4) NOT NULL DEFAULT '0',
  `perf_slowsql` int(4) NOT NULL DEFAULT '0',
  `bb_tsql` int(4) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`,`host_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `sqlperfdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sqlperfdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `sqlperfdb`;

--
-- Table structure for table `disqualification_dmlsql`
--

DROP TABLE IF EXISTS `disqualification_dmlsql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disqualification_dmlsql` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HostName` varchar(64) NOT NULL,
  `SCHEMA_NAME` varchar(64) DEFAULT NULL,
  `DIGEST` varchar(32) DEFAULT NULL,
  `COUNT_STAR` bigint(20) unsigned NOT NULL DEFAULT '0',
  `AVG_TIMER_WAIT` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_EXAMINED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_SENT` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_AFFECTED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `Rate` int(11) DEFAULT NULL,
  `Is_usedindex` char(1) DEFAULT NULL,
  `Data_Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  KEY `idx_1` (`SCHEMA_NAME`,`DIGEST`,`Data_Time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dmlsql_history`
--

DROP TABLE IF EXISTS `dmlsql_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dmlsql_history` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HostName` varchar(64) NOT NULL,
  `SCHEMA_NAME` varchar(64) DEFAULT NULL,
  `DIGEST` varchar(32) DEFAULT NULL,
  `COUNT_STAR` bigint(20) unsigned NOT NULL DEFAULT '0',
  `AVG_TIMER_WAIT` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_LOCK_TIME` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ERRORS` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_WARNINGS` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_AFFECTED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_SENT` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_ROWS_EXAMINED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_CREATED_TMP_DISK_TABLES` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_CREATED_TMP_TABLES` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SELECT_FULL_JOIN` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SELECT_FULL_RANGE_JOIN` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SELECT_RANGE` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SELECT_RANGE_CHECK` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SELECT_SCAN` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SORT_MERGE_PASSES` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SORT_RANGE` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SORT_ROWS` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_SORT_SCAN` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_NO_INDEX_USED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `SUM_NO_GOOD_INDEX_USED` bigint(20) unsigned NOT NULL DEFAULT '0',
  `Data_Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`,`Data_Time`),
  KEY `idx_HostName_SCHEMA_NAME_DIGEST` (`HostName`,`SCHEMA_NAME`,`DIGEST`),
  KEY `idx_Data_Time` (`Data_Time`),
  KEY `idx_1` (`HostName`,`SCHEMA_NAME`,`DIGEST`,`Data_Time`),
  KEY `idx_2` (`SCHEMA_NAME`,`DIGEST`,`Data_Time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50100 PARTITION BY RANGE (to_days(Data_Time))
(PARTITION p20160821 VALUES LESS THAN (736563) ENGINE = InnoDB,
 PARTITION p20160822 VALUES LESS THAN (736564) ENGINE = InnoDB,
 PARTITION p20160823 VALUES LESS THAN (736565) ENGINE = InnoDB,
 PARTITION p20160824 VALUES LESS THAN (736566) ENGINE = InnoDB,
 PARTITION p20160825 VALUES LESS THAN (736567) ENGINE = InnoDB,
 PARTITION p20160826 VALUES LESS THAN (736568) ENGINE = InnoDB,
 PARTITION p20160827 VALUES LESS THAN (736569) ENGINE = InnoDB,
 PARTITION p20160828 VALUES LESS THAN (736570) ENGINE = InnoDB,
 PARTITION p20160829 VALUES LESS THAN (736571) ENGINE = InnoDB,
 PARTITION p20160830 VALUES LESS THAN (736572) ENGINE = InnoDB,
 PARTITION p20160831 VALUES LESS THAN (736573) ENGINE = InnoDB,
 PARTITION p20160901 VALUES LESS THAN (736574) ENGINE = InnoDB,
 PARTITION p20160902 VALUES LESS THAN (736575) ENGINE = InnoDB,
 PARTITION p20160903 VALUES LESS THAN (736576) ENGINE = InnoDB,
 PARTITION p20160904 VALUES LESS THAN (736577) ENGINE = InnoDB,
 PARTITION p20160905 VALUES LESS THAN (736578) ENGINE = InnoDB,
 PARTITION p20160906 VALUES LESS THAN (736579) ENGINE = InnoDB,
 PARTITION p20160907 VALUES LESS THAN (736580) ENGINE = InnoDB,
 PARTITION p20160908 VALUES LESS THAN (736581) ENGINE = InnoDB,
 PARTITION p20160909 VALUES LESS THAN (736582) ENGINE = InnoDB,
 PARTITION p20160910 VALUES LESS THAN (736583) ENGINE = InnoDB,
 PARTITION p20160911 VALUES LESS THAN (736584) ENGINE = InnoDB,
 PARTITION p20160912 VALUES LESS THAN (736585) ENGINE = InnoDB,
 PARTITION p20160913 VALUES LESS THAN (736586) ENGINE = InnoDB,
 PARTITION p20160914 VALUES LESS THAN (736587) ENGINE = InnoDB,
 PARTITION p20160915 VALUES LESS THAN (736588) ENGINE = InnoDB,
 PARTITION p20160916 VALUES LESS THAN (736589) ENGINE = InnoDB,
 PARTITION p20160917 VALUES LESS THAN (736590) ENGINE = InnoDB,
 PARTITION p20160918 VALUES LESS THAN (736591) ENGINE = InnoDB,
 PARTITION p20160919 VALUES LESS THAN (736592) ENGINE = InnoDB,
 PARTITION p20160920 VALUES LESS THAN (736593) ENGINE = InnoDB,
 PARTITION p20160921 VALUES LESS THAN (736594) ENGINE = InnoDB,
 PARTITION p20160922 VALUES LESS THAN (736595) ENGINE = InnoDB,
 PARTITION p20160923 VALUES LESS THAN (736596) ENGINE = InnoDB,
 PARTITION p20160924 VALUES LESS THAN (736597) ENGINE = InnoDB,
 PARTITION p20160925 VALUES LESS THAN (736598) ENGINE = InnoDB,
 PARTITION p20160926 VALUES LESS THAN (736599) ENGINE = InnoDB,
 PARTITION p20160927 VALUES LESS THAN (736600) ENGINE = InnoDB,
 PARTITION p20160928 VALUES LESS THAN (736601) ENGINE = InnoDB,
 PARTITION p20160929 VALUES LESS THAN (736602) ENGINE = InnoDB,
 PARTITION p20160930 VALUES LESS THAN (736603) ENGINE = InnoDB,
 PARTITION p20161001 VALUES LESS THAN (736604) ENGINE = InnoDB,
 PARTITION p20161002 VALUES LESS THAN (736605) ENGINE = InnoDB,
 PARTITION p20161003 VALUES LESS THAN (736606) ENGINE = InnoDB,
 PARTITION p20161004 VALUES LESS THAN (736607) ENGINE = InnoDB,
 PARTITION p20161005 VALUES LESS THAN (736608) ENGINE = InnoDB,
 PARTITION p20161006 VALUES LESS THAN (736609) ENGINE = InnoDB,
 PARTITION p20161007 VALUES LESS THAN (736610) ENGINE = InnoDB,
 PARTITION p20161008 VALUES LESS THAN (736611) ENGINE = InnoDB,
 PARTITION p20161009 VALUES LESS THAN (736612) ENGINE = InnoDB,
 PARTITION p20161010 VALUES LESS THAN (736613) ENGINE = InnoDB,
 PARTITION p20161011 VALUES LESS THAN (736614) ENGINE = InnoDB,
 PARTITION p20161012 VALUES LESS THAN (736615) ENGINE = InnoDB,
 PARTITION p20161013 VALUES LESS THAN (736616) ENGINE = InnoDB,
 PARTITION p20161014 VALUES LESS THAN (736617) ENGINE = InnoDB,
 PARTITION p20161015 VALUES LESS THAN (736618) ENGINE = InnoDB,
 PARTITION p20161016 VALUES LESS THAN (736619) ENGINE = InnoDB,
 PARTITION p20161017 VALUES LESS THAN (736620) ENGINE = InnoDB,
 PARTITION p20161018 VALUES LESS THAN (736621) ENGINE = InnoDB,
 PARTITION p20161019 VALUES LESS THAN (736622) ENGINE = InnoDB,
 PARTITION p20161020 VALUES LESS THAN (736623) ENGINE = InnoDB,
 PARTITION p20161021 VALUES LESS THAN (736624) ENGINE = InnoDB,
 PARTITION p20161022 VALUES LESS THAN (736625) ENGINE = InnoDB,
 PARTITION p20161023 VALUES LESS THAN (736626) ENGINE = InnoDB,
 PARTITION p20161024 VALUES LESS THAN (736627) ENGINE = InnoDB,
 PARTITION p20161025 VALUES LESS THAN (736628) ENGINE = InnoDB,
 PARTITION p20161026 VALUES LESS THAN (736629) ENGINE = InnoDB,
 PARTITION p20161027 VALUES LESS THAN (736630) ENGINE = InnoDB,
 PARTITION p20161028 VALUES LESS THAN (736631) ENGINE = InnoDB,
 PARTITION p20161029 VALUES LESS THAN (736632) ENGINE = InnoDB,
 PARTITION p20161030 VALUES LESS THAN (736633) ENGINE = InnoDB,
 PARTITION p20161031 VALUES LESS THAN (736634) ENGINE = InnoDB,
 PARTITION p20161101 VALUES LESS THAN (736635) ENGINE = InnoDB,
 PARTITION p20161102 VALUES LESS THAN (736636) ENGINE = InnoDB,
 PARTITION p20161103 VALUES LESS THAN (736637) ENGINE = InnoDB,
 PARTITION p20161104 VALUES LESS THAN (736638) ENGINE = InnoDB,
 PARTITION p20161105 VALUES LESS THAN (736639) ENGINE = InnoDB,
 PARTITION p20161106 VALUES LESS THAN (736640) ENGINE = InnoDB,
 PARTITION p20161107 VALUES LESS THAN (736641) ENGINE = InnoDB,
 PARTITION p20161108 VALUES LESS THAN (736642) ENGINE = InnoDB,
 PARTITION p20161109 VALUES LESS THAN (736643) ENGINE = InnoDB,
 PARTITION p20161110 VALUES LESS THAN (736644) ENGINE = InnoDB,
 PARTITION p20161111 VALUES LESS THAN (736645) ENGINE = InnoDB,
 PARTITION p20161112 VALUES LESS THAN (736646) ENGINE = InnoDB,
 PARTITION p20161113 VALUES LESS THAN (736647) ENGINE = InnoDB,
 PARTITION p20161114 VALUES LESS THAN (736648) ENGINE = InnoDB,
 PARTITION p20161115 VALUES LESS THAN (736649) ENGINE = InnoDB,
 PARTITION p20161116 VALUES LESS THAN (736650) ENGINE = InnoDB,
 PARTITION p20161117 VALUES LESS THAN (736651) ENGINE = InnoDB,
 PARTITION p20161118 VALUES LESS THAN (736652) ENGINE = InnoDB,
 PARTITION p20161119 VALUES LESS THAN (736653) ENGINE = InnoDB,
 PARTITION p20161120 VALUES LESS THAN (736654) ENGINE = InnoDB,
 PARTITION p20161121 VALUES LESS THAN (736655) ENGINE = InnoDB,
 PARTITION p20161122 VALUES LESS THAN (736656) ENGINE = InnoDB,
 PARTITION p20161123 VALUES LESS THAN (736657) ENGINE = InnoDB,
 PARTITION p20161124 VALUES LESS THAN (736658) ENGINE = InnoDB,
 PARTITION p20161125 VALUES LESS THAN (736659) ENGINE = InnoDB,
 PARTITION p20161126 VALUES LESS THAN (736660) ENGINE = InnoDB,
 PARTITION p20161127 VALUES LESS THAN (736661) ENGINE = InnoDB,
 PARTITION p20161128 VALUES LESS THAN (736662) ENGINE = InnoDB,
 PARTITION p20161129 VALUES LESS THAN (736663) ENGINE = InnoDB,
 PARTITION p20161130 VALUES LESS THAN (736664) ENGINE = InnoDB,
 PARTITION p20161201 VALUES LESS THAN (736665) ENGINE = InnoDB,
 PARTITION p20161202 VALUES LESS THAN (736666) ENGINE = InnoDB,
 PARTITION p20161203 VALUES LESS THAN (736667) ENGINE = InnoDB,
 PARTITION p20161204 VALUES LESS THAN (736668) ENGINE = InnoDB,
 PARTITION p20161205 VALUES LESS THAN (736669) ENGINE = InnoDB,
 PARTITION p20161206 VALUES LESS THAN (736670) ENGINE = InnoDB,
 PARTITION p20161207 VALUES LESS THAN (736671) ENGINE = InnoDB,
 PARTITION p20161208 VALUES LESS THAN (736672) ENGINE = InnoDB,
 PARTITION p20161209 VALUES LESS THAN (736673) ENGINE = InnoDB,
 PARTITION p20161210 VALUES LESS THAN (736674) ENGINE = InnoDB,
 PARTITION p20161211 VALUES LESS THAN (736675) ENGINE = InnoDB,
 PARTITION p20161212 VALUES LESS THAN (736676) ENGINE = InnoDB,
 PARTITION p20161213 VALUES LESS THAN (736677) ENGINE = InnoDB,
 PARTITION p20161214 VALUES LESS THAN (736678) ENGINE = InnoDB,
 PARTITION p20161215 VALUES LESS THAN (736679) ENGINE = InnoDB,
 PARTITION p20161216 VALUES LESS THAN (736680) ENGINE = InnoDB,
 PARTITION p20161217 VALUES LESS THAN (736681) ENGINE = InnoDB,
 PARTITION p20161218 VALUES LESS THAN (736682) ENGINE = InnoDB,
 PARTITION p20161219 VALUES LESS THAN (736683) ENGINE = InnoDB,
 PARTITION p20161220 VALUES LESS THAN (736684) ENGINE = InnoDB,
 PARTITION p20161221 VALUES LESS THAN (736685) ENGINE = InnoDB,
 PARTITION p20161222 VALUES LESS THAN (736686) ENGINE = InnoDB,
 PARTITION p20161223 VALUES LESS THAN (736687) ENGINE = InnoDB,
 PARTITION p20161224 VALUES LESS THAN (736688) ENGINE = InnoDB,
 PARTITION p20161225 VALUES LESS THAN (736689) ENGINE = InnoDB,
 PARTITION p20161226 VALUES LESS THAN (736690) ENGINE = InnoDB,
 PARTITION p20161227 VALUES LESS THAN (736691) ENGINE = InnoDB,
 PARTITION p20161228 VALUES LESS THAN (736692) ENGINE = InnoDB,
 PARTITION p20161229 VALUES LESS THAN (736693) ENGINE = InnoDB,
 PARTITION p20161230 VALUES LESS THAN (736694) ENGINE = InnoDB,
 PARTITION p20161231 VALUES LESS THAN (736695) ENGINE = InnoDB,
 PARTITION p20170101 VALUES LESS THAN (736696) ENGINE = InnoDB,
 PARTITION p20170102 VALUES LESS THAN (736697) ENGINE = InnoDB,
 PARTITION p20170103 VALUES LESS THAN (736698) ENGINE = InnoDB,
 PARTITION p20170104 VALUES LESS THAN (736699) ENGINE = InnoDB,
 PARTITION p20170105 VALUES LESS THAN (736700) ENGINE = InnoDB,
 PARTITION p20170106 VALUES LESS THAN (736701) ENGINE = InnoDB,
 PARTITION p20170107 VALUES LESS THAN (736702) ENGINE = InnoDB,
 PARTITION p20170108 VALUES LESS THAN (736703) ENGINE = InnoDB,
 PARTITION p20170109 VALUES LESS THAN (736704) ENGINE = InnoDB,
 PARTITION p20170110 VALUES LESS THAN (736705) ENGINE = InnoDB,
 PARTITION p20170111 VALUES LESS THAN (736706) ENGINE = InnoDB,
 PARTITION p20170112 VALUES LESS THAN (736707) ENGINE = InnoDB,
 PARTITION p20170113 VALUES LESS THAN (736708) ENGINE = InnoDB,
 PARTITION p20170114 VALUES LESS THAN (736709) ENGINE = InnoDB,
 PARTITION p20170115 VALUES LESS THAN (736710) ENGINE = InnoDB,
 PARTITION p20170116 VALUES LESS THAN (736711) ENGINE = InnoDB,
 PARTITION p20170117 VALUES LESS THAN (736712) ENGINE = InnoDB,
 PARTITION p20170118 VALUES LESS THAN (736713) ENGINE = InnoDB,
 PARTITION p20170119 VALUES LESS THAN (736714) ENGINE = InnoDB,
 PARTITION p20170120 VALUES LESS THAN (736715) ENGINE = InnoDB,
 PARTITION p20170121 VALUES LESS THAN (736716) ENGINE = InnoDB,
 PARTITION p20170122 VALUES LESS THAN (736717) ENGINE = InnoDB,
 PARTITION p20170123 VALUES LESS THAN (736718) ENGINE = InnoDB,
 PARTITION p20170124 VALUES LESS THAN (736719) ENGINE = InnoDB,
 PARTITION p20170125 VALUES LESS THAN (736720) ENGINE = InnoDB,
 PARTITION p20170126 VALUES LESS THAN (736721) ENGINE = InnoDB,
 PARTITION p20170127 VALUES LESS THAN (736722) ENGINE = InnoDB,
 PARTITION p20170128 VALUES LESS THAN (736723) ENGINE = InnoDB,
 PARTITION p20170129 VALUES LESS THAN (736724) ENGINE = InnoDB,
 PARTITION p20170130 VALUES LESS THAN (736725) ENGINE = InnoDB,
 PARTITION p20170131 VALUES LESS THAN (736726) ENGINE = InnoDB,
 PARTITION p20170201 VALUES LESS THAN (736727) ENGINE = InnoDB,
 PARTITION p20170202 VALUES LESS THAN (736728) ENGINE = InnoDB,
 PARTITION p20170203 VALUES LESS THAN (736729) ENGINE = InnoDB,
 PARTITION p20170204 VALUES LESS THAN (736730) ENGINE = InnoDB,
 PARTITION p20170205 VALUES LESS THAN (736731) ENGINE = InnoDB,
 PARTITION p20170206 VALUES LESS THAN (736732) ENGINE = InnoDB,
 PARTITION p20170207 VALUES LESS THAN (736733) ENGINE = InnoDB,
 PARTITION p20170208 VALUES LESS THAN (736734) ENGINE = InnoDB,
 PARTITION p20170209 VALUES LESS THAN (736735) ENGINE = InnoDB,
 PARTITION p20170210 VALUES LESS THAN (736736) ENGINE = InnoDB,
 PARTITION p20170211 VALUES LESS THAN (736737) ENGINE = InnoDB,
 PARTITION p20170212 VALUES LESS THAN (736738) ENGINE = InnoDB,
 PARTITION p20170213 VALUES LESS THAN (736739) ENGINE = InnoDB,
 PARTITION p20170214 VALUES LESS THAN (736740) ENGINE = InnoDB,
 PARTITION p20170215 VALUES LESS THAN (736741) ENGINE = InnoDB,
 PARTITION p20170216 VALUES LESS THAN (736742) ENGINE = InnoDB,
 PARTITION p20170217 VALUES LESS THAN (736743) ENGINE = InnoDB,
 PARTITION p20170218 VALUES LESS THAN (736744) ENGINE = InnoDB,
 PARTITION p20170219 VALUES LESS THAN (736745) ENGINE = InnoDB,
 PARTITION p20170220 VALUES LESS THAN (736746) ENGINE = InnoDB,
 PARTITION p20170221 VALUES LESS THAN (736747) ENGINE = InnoDB,
 PARTITION p20170222 VALUES LESS THAN (736748) ENGINE = InnoDB,
 PARTITION p20170223 VALUES LESS THAN (736749) ENGINE = InnoDB,
 PARTITION p20170224 VALUES LESS THAN (736750) ENGINE = InnoDB,
 PARTITION p20170225 VALUES LESS THAN (736751) ENGINE = InnoDB,
 PARTITION p20170226 VALUES LESS THAN (736752) ENGINE = InnoDB,
 PARTITION p20170227 VALUES LESS THAN (736753) ENGINE = InnoDB,
 PARTITION p20170228 VALUES LESS THAN (736754) ENGINE = InnoDB,
 PARTITION p20170301 VALUES LESS THAN (736755) ENGINE = InnoDB,
 PARTITION p20170302 VALUES LESS THAN (736756) ENGINE = InnoDB,
 PARTITION p20170303 VALUES LESS THAN (736757) ENGINE = InnoDB,
 PARTITION p20170304 VALUES LESS THAN (736758) ENGINE = InnoDB,
 PARTITION p20170305 VALUES LESS THAN (736759) ENGINE = InnoDB,
 PARTITION p20170306 VALUES LESS THAN (736760) ENGINE = InnoDB,
 PARTITION p20170307 VALUES LESS THAN (736761) ENGINE = InnoDB,
 PARTITION p20170308 VALUES LESS THAN (736762) ENGINE = InnoDB,
 PARTITION p20170309 VALUES LESS THAN (736763) ENGINE = InnoDB,
 PARTITION p20170310 VALUES LESS THAN (736764) ENGINE = InnoDB,
 PARTITION p20170311 VALUES LESS THAN (736765) ENGINE = InnoDB,
 PARTITION p20170312 VALUES LESS THAN (736766) ENGINE = InnoDB,
 PARTITION p20170313 VALUES LESS THAN (736767) ENGINE = InnoDB,
 PARTITION p20170314 VALUES LESS THAN (736768) ENGINE = InnoDB,
 PARTITION p20170315 VALUES LESS THAN (736769) ENGINE = InnoDB,
 PARTITION p20170316 VALUES LESS THAN (736770) ENGINE = InnoDB,
 PARTITION p20170317 VALUES LESS THAN (736771) ENGINE = InnoDB,
 PARTITION p20170318 VALUES LESS THAN (736772) ENGINE = InnoDB,
 PARTITION p20170319 VALUES LESS THAN (736773) ENGINE = InnoDB,
 PARTITION p20170320 VALUES LESS THAN (736774) ENGINE = InnoDB,
 PARTITION p20170321 VALUES LESS THAN (736775) ENGINE = InnoDB,
 PARTITION p20170322 VALUES LESS THAN (736776) ENGINE = InnoDB,
 PARTITION p20170323 VALUES LESS THAN (736777) ENGINE = InnoDB,
 PARTITION p20170324 VALUES LESS THAN (736778) ENGINE = InnoDB,
 PARTITION p20170325 VALUES LESS THAN (736779) ENGINE = InnoDB,
 PARTITION p20170326 VALUES LESS THAN (736780) ENGINE = InnoDB,
 PARTITION p20170327 VALUES LESS THAN (736781) ENGINE = InnoDB,
 PARTITION p20170328 VALUES LESS THAN (736782) ENGINE = InnoDB,
 PARTITION p20170329 VALUES LESS THAN (736783) ENGINE = InnoDB,
 PARTITION p20170330 VALUES LESS THAN (736784) ENGINE = InnoDB,
 PARTITION p20170331 VALUES LESS THAN (736785) ENGINE = InnoDB,
 PARTITION p20170401 VALUES LESS THAN (736786) ENGINE = InnoDB,
 PARTITION p20170402 VALUES LESS THAN (736787) ENGINE = InnoDB,
 PARTITION p20170403 VALUES LESS THAN (736788) ENGINE = InnoDB,
 PARTITION p20170404 VALUES LESS THAN (736789) ENGINE = InnoDB,
 PARTITION p20170405 VALUES LESS THAN (736790) ENGINE = InnoDB,
 PARTITION p20170406 VALUES LESS THAN (736791) ENGINE = InnoDB,
 PARTITION p20170407 VALUES LESS THAN (736792) ENGINE = InnoDB,
 PARTITION p20170408 VALUES LESS THAN (736793) ENGINE = InnoDB,
 PARTITION p20170409 VALUES LESS THAN (736794) ENGINE = InnoDB,
 PARTITION p20170410 VALUES LESS THAN (736795) ENGINE = InnoDB,
 PARTITION p20170411 VALUES LESS THAN (736796) ENGINE = InnoDB,
 PARTITION p20170412 VALUES LESS THAN (736797) ENGINE = InnoDB,
 PARTITION p20170413 VALUES LESS THAN (736798) ENGINE = InnoDB,
 PARTITION p20170414 VALUES LESS THAN (736799) ENGINE = InnoDB,
 PARTITION p20170415 VALUES LESS THAN (736800) ENGINE = InnoDB,
 PARTITION p20170416 VALUES LESS THAN (736801) ENGINE = InnoDB,
 PARTITION p20170417 VALUES LESS THAN (736802) ENGINE = InnoDB,
 PARTITION p20170418 VALUES LESS THAN (736803) ENGINE = InnoDB,
 PARTITION p20170419 VALUES LESS THAN (736804) ENGINE = InnoDB,
 PARTITION p20170420 VALUES LESS THAN (736805) ENGINE = InnoDB,
 PARTITION p20170421 VALUES LESS THAN (736806) ENGINE = InnoDB,
 PARTITION p20170422 VALUES LESS THAN (736807) ENGINE = InnoDB,
 PARTITION p20170423 VALUES LESS THAN (736808) ENGINE = InnoDB,
 PARTITION p20170424 VALUES LESS THAN (736809) ENGINE = InnoDB,
 PARTITION p20170425 VALUES LESS THAN (736810) ENGINE = InnoDB,
 PARTITION p20170426 VALUES LESS THAN (736811) ENGINE = InnoDB,
 PARTITION p20170427 VALUES LESS THAN (736812) ENGINE = InnoDB,
 PARTITION p20170428 VALUES LESS THAN (736813) ENGINE = InnoDB,
 PARTITION p20170429 VALUES LESS THAN (736814) ENGINE = InnoDB,
 PARTITION p20170430 VALUES LESS THAN (736815) ENGINE = InnoDB,
 PARTITION p20170501 VALUES LESS THAN (736816) ENGINE = InnoDB,
 PARTITION p20170502 VALUES LESS THAN (736817) ENGINE = InnoDB,
 PARTITION p20170503 VALUES LESS THAN (736818) ENGINE = InnoDB,
 PARTITION p20170504 VALUES LESS THAN (736819) ENGINE = InnoDB,
 PARTITION p20170505 VALUES LESS THAN (736820) ENGINE = InnoDB,
 PARTITION p20170506 VALUES LESS THAN (736821) ENGINE = InnoDB,
 PARTITION p20170507 VALUES LESS THAN (736822) ENGINE = InnoDB,
 PARTITION p20170508 VALUES LESS THAN (736823) ENGINE = InnoDB,
 PARTITION p20170509 VALUES LESS THAN (736824) ENGINE = InnoDB,
 PARTITION p20170510 VALUES LESS THAN (736825) ENGINE = InnoDB,
 PARTITION p20170511 VALUES LESS THAN (736826) ENGINE = InnoDB,
 PARTITION p20170512 VALUES LESS THAN (736827) ENGINE = InnoDB,
 PARTITION p20170513 VALUES LESS THAN (736828) ENGINE = InnoDB,
 PARTITION p20170514 VALUES LESS THAN (736829) ENGINE = InnoDB,
 PARTITION p20170515 VALUES LESS THAN (736830) ENGINE = InnoDB,
 PARTITION p20170516 VALUES LESS THAN (736831) ENGINE = InnoDB,
 PARTITION p20170517 VALUES LESS THAN (736832) ENGINE = InnoDB,
 PARTITION p20170518 VALUES LESS THAN (736833) ENGINE = InnoDB,
 PARTITION p20170519 VALUES LESS THAN (736834) ENGINE = InnoDB,
 PARTITION p20170520 VALUES LESS THAN (736835) ENGINE = InnoDB,
 PARTITION p20170521 VALUES LESS THAN (736836) ENGINE = InnoDB,
 PARTITION p20170522 VALUES LESS THAN (736837) ENGINE = InnoDB,
 PARTITION p20170523 VALUES LESS THAN (736838) ENGINE = InnoDB,
 PARTITION p20170524 VALUES LESS THAN (736839) ENGINE = InnoDB,
 PARTITION p20170525 VALUES LESS THAN (736840) ENGINE = InnoDB,
 PARTITION p20170526 VALUES LESS THAN (736841) ENGINE = InnoDB,
 PARTITION p20170527 VALUES LESS THAN (736842) ENGINE = InnoDB,
 PARTITION p20170528 VALUES LESS THAN (736843) ENGINE = InnoDB,
 PARTITION p20170529 VALUES LESS THAN (736844) ENGINE = InnoDB,
 PARTITION p20170530 VALUES LESS THAN (736845) ENGINE = InnoDB,
 PARTITION p20170531 VALUES LESS THAN (736846) ENGINE = InnoDB,
 PARTITION p20170601 VALUES LESS THAN (736847) ENGINE = InnoDB,
 PARTITION p20170602 VALUES LESS THAN (736848) ENGINE = InnoDB,
 PARTITION p20170603 VALUES LESS THAN (736849) ENGINE = InnoDB,
 PARTITION p20170604 VALUES LESS THAN (736850) ENGINE = InnoDB,
 PARTITION p20170605 VALUES LESS THAN (736851) ENGINE = InnoDB,
 PARTITION p20170606 VALUES LESS THAN (736852) ENGINE = InnoDB,
 PARTITION p20170607 VALUES LESS THAN (736853) ENGINE = InnoDB,
 PARTITION p20170608 VALUES LESS THAN (736854) ENGINE = InnoDB,
 PARTITION p20170609 VALUES LESS THAN (736855) ENGINE = InnoDB,
 PARTITION p20170610 VALUES LESS THAN (736856) ENGINE = InnoDB,
 PARTITION p20170611 VALUES LESS THAN (736857) ENGINE = InnoDB,
 PARTITION p20170612 VALUES LESS THAN (736858) ENGINE = InnoDB,
 PARTITION p20170613 VALUES LESS THAN (736859) ENGINE = InnoDB,
 PARTITION p20170614 VALUES LESS THAN (736860) ENGINE = InnoDB,
 PARTITION p20170615 VALUES LESS THAN (736861) ENGINE = InnoDB,
 PARTITION p20170616 VALUES LESS THAN (736862) ENGINE = InnoDB,
 PARTITION p20170617 VALUES LESS THAN (736863) ENGINE = InnoDB,
 PARTITION p20170618 VALUES LESS THAN (736864) ENGINE = InnoDB,
 PARTITION p20170619 VALUES LESS THAN (736865) ENGINE = InnoDB,
 PARTITION p20170620 VALUES LESS THAN (736866) ENGINE = InnoDB,
 PARTITION p20170621 VALUES LESS THAN (736867) ENGINE = InnoDB,
 PARTITION p20170622 VALUES LESS THAN (736868) ENGINE = InnoDB,
 PARTITION p20170623 VALUES LESS THAN (736869) ENGINE = InnoDB,
 PARTITION p20170624 VALUES LESS THAN (736870) ENGINE = InnoDB,
 PARTITION p20170625 VALUES LESS THAN (736871) ENGINE = InnoDB,
 PARTITION p20170626 VALUES LESS THAN (736872) ENGINE = InnoDB,
 PARTITION p20170627 VALUES LESS THAN (736873) ENGINE = InnoDB,
 PARTITION p20170628 VALUES LESS THAN (736874) ENGINE = InnoDB,
 PARTITION p20170629 VALUES LESS THAN (736875) ENGINE = InnoDB,
 PARTITION p20170630 VALUES LESS THAN (736876) ENGINE = InnoDB,
 PARTITION p20170701 VALUES LESS THAN (736877) ENGINE = InnoDB,
 PARTITION p20170702 VALUES LESS THAN (736878) ENGINE = InnoDB,
 PARTITION p20170703 VALUES LESS THAN (736879) ENGINE = InnoDB,
 PARTITION p20170704 VALUES LESS THAN (736880) ENGINE = InnoDB,
 PARTITION p20170705 VALUES LESS THAN (736881) ENGINE = InnoDB,
 PARTITION p20170706 VALUES LESS THAN (736882) ENGINE = InnoDB,
 PARTITION p20170707 VALUES LESS THAN (736883) ENGINE = InnoDB,
 PARTITION p20170708 VALUES LESS THAN (736884) ENGINE = InnoDB,
 PARTITION p20170709 VALUES LESS THAN (736885) ENGINE = InnoDB,
 PARTITION p20170710 VALUES LESS THAN (736886) ENGINE = InnoDB,
 PARTITION p20170711 VALUES LESS THAN (736887) ENGINE = InnoDB,
 PARTITION p20170712 VALUES LESS THAN (736888) ENGINE = InnoDB,
 PARTITION p20170713 VALUES LESS THAN (736889) ENGINE = InnoDB,
 PARTITION p20170714 VALUES LESS THAN (736890) ENGINE = InnoDB,
 PARTITION p20170715 VALUES LESS THAN (736891) ENGINE = InnoDB,
 PARTITION p20170716 VALUES LESS THAN (736892) ENGINE = InnoDB,
 PARTITION p20170717 VALUES LESS THAN (736893) ENGINE = InnoDB,
 PARTITION p20170718 VALUES LESS THAN (736894) ENGINE = InnoDB,
 PARTITION p20170719 VALUES LESS THAN (736895) ENGINE = InnoDB,
 PARTITION p20170720 VALUES LESS THAN (736896) ENGINE = InnoDB,
 PARTITION p20170721 VALUES LESS THAN (736897) ENGINE = InnoDB,
 PARTITION p20170722 VALUES LESS THAN (736898) ENGINE = InnoDB,
 PARTITION p20170723 VALUES LESS THAN (736899) ENGINE = InnoDB,
 PARTITION p20170724 VALUES LESS THAN (736900) ENGINE = InnoDB,
 PARTITION p20170725 VALUES LESS THAN (736901) ENGINE = InnoDB,
 PARTITION p20170726 VALUES LESS THAN (736902) ENGINE = InnoDB,
 PARTITION p20170727 VALUES LESS THAN (736903) ENGINE = InnoDB,
 PARTITION p20170728 VALUES LESS THAN (736904) ENGINE = InnoDB,
 PARTITION p20170729 VALUES LESS THAN (736905) ENGINE = InnoDB,
 PARTITION p20170730 VALUES LESS THAN (736906) ENGINE = InnoDB,
 PARTITION p20170731 VALUES LESS THAN (736907) ENGINE = InnoDB,
 PARTITION p20170801 VALUES LESS THAN (736908) ENGINE = InnoDB,
 PARTITION p20170802 VALUES LESS THAN (736909) ENGINE = InnoDB,
 PARTITION p20170803 VALUES LESS THAN (736910) ENGINE = InnoDB,
 PARTITION p20170804 VALUES LESS THAN (736911) ENGINE = InnoDB,
 PARTITION p20170805 VALUES LESS THAN (736912) ENGINE = InnoDB,
 PARTITION p20170806 VALUES LESS THAN (736913) ENGINE = InnoDB,
 PARTITION p20170807 VALUES LESS THAN (736914) ENGINE = InnoDB,
 PARTITION p20170808 VALUES LESS THAN (736915) ENGINE = InnoDB,
 PARTITION p20170809 VALUES LESS THAN (736916) ENGINE = InnoDB,
 PARTITION p20170810 VALUES LESS THAN (736917) ENGINE = InnoDB,
 PARTITION p20170811 VALUES LESS THAN (736918) ENGINE = InnoDB,
 PARTITION p20170812 VALUES LESS THAN (736919) ENGINE = InnoDB,
 PARTITION p20170813 VALUES LESS THAN (736920) ENGINE = InnoDB,
 PARTITION p20170814 VALUES LESS THAN (736921) ENGINE = InnoDB,
 PARTITION p20170815 VALUES LESS THAN (736922) ENGINE = InnoDB,
 PARTITION p20170816 VALUES LESS THAN (736923) ENGINE = InnoDB,
 PARTITION p20170817 VALUES LESS THAN (736924) ENGINE = InnoDB,
 PARTITION p20170818 VALUES LESS THAN (736925) ENGINE = InnoDB,
 PARTITION p20170819 VALUES LESS THAN (736926) ENGINE = InnoDB,
 PARTITION p20170820 VALUES LESS THAN (736927) ENGINE = InnoDB,
 PARTITION p20170821 VALUES LESS THAN (736928) ENGINE = InnoDB,
 PARTITION p20170822 VALUES LESS THAN (736929) ENGINE = InnoDB,
 PARTITION p20170823 VALUES LESS THAN (736930) ENGINE = InnoDB,
 PARTITION p20170824 VALUES LESS THAN (736931) ENGINE = InnoDB,
 PARTITION p20170825 VALUES LESS THAN (736932) ENGINE = InnoDB,
 PARTITION p20170826 VALUES LESS THAN (736933) ENGINE = InnoDB,
 PARTITION p20170827 VALUES LESS THAN (736934) ENGINE = InnoDB,
 PARTITION p20170828 VALUES LESS THAN (736935) ENGINE = InnoDB,
 PARTITION p20170829 VALUES LESS THAN (736936) ENGINE = InnoDB,
 PARTITION p20170830 VALUES LESS THAN (736937) ENGINE = InnoDB,
 PARTITION p20170831 VALUES LESS THAN (736938) ENGINE = InnoDB,
 PARTITION p20170901 VALUES LESS THAN (736939) ENGINE = InnoDB,
 PARTITION p20170902 VALUES LESS THAN (736940) ENGINE = InnoDB,
 PARTITION p20170903 VALUES LESS THAN (736941) ENGINE = InnoDB,
 PARTITION p20170904 VALUES LESS THAN (736942) ENGINE = InnoDB,
 PARTITION p20170905 VALUES LESS THAN (736943) ENGINE = InnoDB,
 PARTITION p20170906 VALUES LESS THAN (736944) ENGINE = InnoDB,
 PARTITION p20170907 VALUES LESS THAN (736945) ENGINE = InnoDB,
 PARTITION p20170908 VALUES LESS THAN (736946) ENGINE = InnoDB,
 PARTITION p20170909 VALUES LESS THAN (736947) ENGINE = InnoDB,
 PARTITION p20170910 VALUES LESS THAN (736948) ENGINE = InnoDB,
 PARTITION p20170911 VALUES LESS THAN (736949) ENGINE = InnoDB,
 PARTITION p20170912 VALUES LESS THAN (736950) ENGINE = InnoDB,
 PARTITION p20170913 VALUES LESS THAN (736951) ENGINE = InnoDB,
 PARTITION p20170914 VALUES LESS THAN (736952) ENGINE = InnoDB,
 PARTITION p20170915 VALUES LESS THAN (736953) ENGINE = InnoDB,
 PARTITION p20170916 VALUES LESS THAN (736954) ENGINE = InnoDB,
 PARTITION p20170917 VALUES LESS THAN (736955) ENGINE = InnoDB,
 PARTITION p20170918 VALUES LESS THAN (736956) ENGINE = InnoDB,
 PARTITION p20170919 VALUES LESS THAN (736957) ENGINE = InnoDB,
 PARTITION p20170920 VALUES LESS THAN (736958) ENGINE = InnoDB,
 PARTITION p20170921 VALUES LESS THAN (736959) ENGINE = InnoDB,
 PARTITION p20170922 VALUES LESS THAN (736960) ENGINE = InnoDB,
 PARTITION p20170923 VALUES LESS THAN (736961) ENGINE = InnoDB,
 PARTITION p20170924 VALUES LESS THAN (736962) ENGINE = InnoDB,
 PARTITION p20170925 VALUES LESS THAN (736963) ENGINE = InnoDB,
 PARTITION p20170926 VALUES LESS THAN (736964) ENGINE = InnoDB,
 PARTITION p20170927 VALUES LESS THAN (736965) ENGINE = InnoDB,
 PARTITION p20170928 VALUES LESS THAN (736966) ENGINE = InnoDB,
 PARTITION p20170929 VALUES LESS THAN (736967) ENGINE = InnoDB,
 PARTITION p20170930 VALUES LESS THAN (736968) ENGINE = InnoDB,
 PARTITION p20171001 VALUES LESS THAN (736969) ENGINE = InnoDB,
 PARTITION p20171002 VALUES LESS THAN (736970) ENGINE = InnoDB,
 PARTITION p20171003 VALUES LESS THAN (736971) ENGINE = InnoDB,
 PARTITION p20171004 VALUES LESS THAN (736972) ENGINE = InnoDB,
 PARTITION p20171005 VALUES LESS THAN (736973) ENGINE = InnoDB,
 PARTITION p20171006 VALUES LESS THAN (736974) ENGINE = InnoDB,
 PARTITION p20171007 VALUES LESS THAN (736975) ENGINE = InnoDB,
 PARTITION p20171008 VALUES LESS THAN (736976) ENGINE = InnoDB,
 PARTITION p20171009 VALUES LESS THAN (736977) ENGINE = InnoDB,
 PARTITION p20171010 VALUES LESS THAN (736978) ENGINE = InnoDB,
 PARTITION p20171011 VALUES LESS THAN (736979) ENGINE = InnoDB,
 PARTITION p20171012 VALUES LESS THAN (736980) ENGINE = InnoDB,
 PARTITION p20171013 VALUES LESS THAN (736981) ENGINE = InnoDB,
 PARTITION p20171014 VALUES LESS THAN (736982) ENGINE = InnoDB,
 PARTITION p20171015 VALUES LESS THAN (736983) ENGINE = InnoDB,
 PARTITION p20171016 VALUES LESS THAN (736984) ENGINE = InnoDB,
 PARTITION p20171017 VALUES LESS THAN (736985) ENGINE = InnoDB,
 PARTITION p20171018 VALUES LESS THAN (736986) ENGINE = InnoDB,
 PARTITION p20171019 VALUES LESS THAN (736987) ENGINE = InnoDB,
 PARTITION p20171020 VALUES LESS THAN (736988) ENGINE = InnoDB,
 PARTITION p20171021 VALUES LESS THAN (736989) ENGINE = InnoDB,
 PARTITION p20171022 VALUES LESS THAN (736990) ENGINE = InnoDB,
 PARTITION p20171023 VALUES LESS THAN (736991) ENGINE = InnoDB,
 PARTITION p20171024 VALUES LESS THAN (736992) ENGINE = InnoDB,
 PARTITION p20171025 VALUES LESS THAN (736993) ENGINE = InnoDB,
 PARTITION p20171026 VALUES LESS THAN (736994) ENGINE = InnoDB,
 PARTITION p20171027 VALUES LESS THAN (736995) ENGINE = InnoDB,
 PARTITION p20171028 VALUES LESS THAN (736996) ENGINE = InnoDB,
 PARTITION p20171029 VALUES LESS THAN (736997) ENGINE = InnoDB,
 PARTITION p20171030 VALUES LESS THAN (736998) ENGINE = InnoDB,
 PARTITION p20171031 VALUES LESS THAN (736999) ENGINE = InnoDB,
 PARTITION p20171101 VALUES LESS THAN (737000) ENGINE = InnoDB,
 PARTITION p20171102 VALUES LESS THAN (737001) ENGINE = InnoDB,
 PARTITION p20171103 VALUES LESS THAN (737002) ENGINE = InnoDB,
 PARTITION p20171104 VALUES LESS THAN (737003) ENGINE = InnoDB,
 PARTITION p20171105 VALUES LESS THAN (737004) ENGINE = InnoDB,
 PARTITION p20171106 VALUES LESS THAN (737005) ENGINE = InnoDB,
 PARTITION p20171107 VALUES LESS THAN (737006) ENGINE = InnoDB,
 PARTITION p20171108 VALUES LESS THAN (737007) ENGINE = InnoDB,
 PARTITION p20171109 VALUES LESS THAN (737008) ENGINE = InnoDB,
 PARTITION p20171110 VALUES LESS THAN (737009) ENGINE = InnoDB,
 PARTITION p20171111 VALUES LESS THAN (737010) ENGINE = InnoDB,
 PARTITION p20171112 VALUES LESS THAN (737011) ENGINE = InnoDB,
 PARTITION p20171113 VALUES LESS THAN (737012) ENGINE = InnoDB,
 PARTITION p20171114 VALUES LESS THAN (737013) ENGINE = InnoDB,
 PARTITION p20171115 VALUES LESS THAN (737014) ENGINE = InnoDB,
 PARTITION p20171116 VALUES LESS THAN (737015) ENGINE = InnoDB,
 PARTITION p20171117 VALUES LESS THAN (737016) ENGINE = InnoDB,
 PARTITION p20171118 VALUES LESS THAN (737017) ENGINE = InnoDB,
 PARTITION p20171119 VALUES LESS THAN (737018) ENGINE = InnoDB,
 PARTITION p20171120 VALUES LESS THAN (737019) ENGINE = InnoDB,
 PARTITION p20171121 VALUES LESS THAN (737020) ENGINE = InnoDB,
 PARTITION p20171122 VALUES LESS THAN (737021) ENGINE = InnoDB,
 PARTITION p20171123 VALUES LESS THAN (737022) ENGINE = InnoDB,
 PARTITION p20171124 VALUES LESS THAN (737023) ENGINE = InnoDB,
 PARTITION p20171125 VALUES LESS THAN (737024) ENGINE = InnoDB,
 PARTITION p20171126 VALUES LESS THAN (737025) ENGINE = InnoDB,
 PARTITION p20171127 VALUES LESS THAN (737026) ENGINE = InnoDB,
 PARTITION p20171128 VALUES LESS THAN (737027) ENGINE = InnoDB,
 PARTITION p20171129 VALUES LESS THAN (737028) ENGINE = InnoDB,
 PARTITION p20171130 VALUES LESS THAN (737029) ENGINE = InnoDB,
 PARTITION p20171201 VALUES LESS THAN (737030) ENGINE = InnoDB,
 PARTITION p20171202 VALUES LESS THAN (737031) ENGINE = InnoDB,
 PARTITION p20171203 VALUES LESS THAN (737032) ENGINE = InnoDB,
 PARTITION p20171204 VALUES LESS THAN (737033) ENGINE = InnoDB,
 PARTITION p20171205 VALUES LESS THAN (737034) ENGINE = InnoDB,
 PARTITION p20171206 VALUES LESS THAN (737035) ENGINE = InnoDB,
 PARTITION p20171207 VALUES LESS THAN (737036) ENGINE = InnoDB,
 PARTITION p20171208 VALUES LESS THAN (737037) ENGINE = InnoDB,
 PARTITION p20171209 VALUES LESS THAN (737038) ENGINE = InnoDB,
 PARTITION p20171210 VALUES LESS THAN (737039) ENGINE = InnoDB,
 PARTITION p20171211 VALUES LESS THAN (737040) ENGINE = InnoDB,
 PARTITION p20171212 VALUES LESS THAN (737041) ENGINE = InnoDB,
 PARTITION p20171213 VALUES LESS THAN (737042) ENGINE = InnoDB,
 PARTITION p20171214 VALUES LESS THAN (737043) ENGINE = InnoDB,
 PARTITION p20171215 VALUES LESS THAN (737044) ENGINE = InnoDB,
 PARTITION p20171216 VALUES LESS THAN (737045) ENGINE = InnoDB,
 PARTITION p20171217 VALUES LESS THAN (737046) ENGINE = InnoDB,
 PARTITION p20171218 VALUES LESS THAN (737047) ENGINE = InnoDB,
 PARTITION p20171219 VALUES LESS THAN (737048) ENGINE = InnoDB,
 PARTITION p20171220 VALUES LESS THAN (737049) ENGINE = InnoDB,
 PARTITION p20171221 VALUES LESS THAN (737050) ENGINE = InnoDB,
 PARTITION p20171222 VALUES LESS THAN (737051) ENGINE = InnoDB,
 PARTITION p20171223 VALUES LESS THAN (737052) ENGINE = InnoDB,
 PARTITION p20171224 VALUES LESS THAN (737053) ENGINE = InnoDB,
 PARTITION p20171225 VALUES LESS THAN (737054) ENGINE = InnoDB,
 PARTITION p20171226 VALUES LESS THAN (737055) ENGINE = InnoDB,
 PARTITION p20171227 VALUES LESS THAN (737056) ENGINE = InnoDB,
 PARTITION p20171228 VALUES LESS THAN (737057) ENGINE = InnoDB,
 PARTITION p20171229 VALUES LESS THAN (737058) ENGINE = InnoDB,
 PARTITION p20171230 VALUES LESS THAN (737059) ENGINE = InnoDB,
 PARTITION p20171231 VALUES LESS THAN (737060) ENGINE = InnoDB,
 PARTITION pMax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dmlsql_sample`
--

DROP TABLE IF EXISTS `dmlsql_sample`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dmlsql_sample` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HostName` varchar(64) NOT NULL,
  `SCHEMA_NAME` varchar(64) NOT NULL,
  `DIGEST` varchar(32) NOT NULL,
  `SQL_Type` char(10) NOT NULL DEFAULT '',
  `DIGEST_TEXT` longtext,
  `SqlText` longtext,
  `DataChange_LastTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `idx_unique` (`HostName`,`SCHEMA_NAME`,`DIGEST`),
  KEY `idx_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `idx_SQL_Type` (`SQL_Type`),
  KEY `idx_1` (`SCHEMA_NAME`,`DIGEST`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `external_storagelist`
--

DROP TABLE IF EXISTS `external_storagelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `external_storagelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `glusterfs_located` varchar(20) DEFAULT NULL,
  `glusterfs_dns` varchar(64) DEFAULT NULL,
  `glusterfs_cmd` varchar(200) DEFAULT NULL,
  `glusterfs_Extra` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ignore_mysql_cpu`
--

DROP TABLE IF EXISTS `ignore_mysql_cpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ignore_mysql_cpu` (
  `machine_name` varchar(50) DEFAULT NULL,
  `ignore_reason` varchar(200) DEFAULT NULL,
  `operator` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ignored_disqualification_dmlsql`
--

DROP TABLE IF EXISTS `ignored_disqualification_dmlsql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ignored_disqualification_dmlsql` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `SCHEMA_NAME` varchar(128) DEFAULT NULL,
  `DIGEST` varchar(128) DEFAULT NULL,
  `operator` varchar(50) NOT NULL DEFAULT '',
  `reason` varchar(200) NOT NULL DEFAULT '',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ignored_slowloguser`
--

DROP TABLE IF EXISTS `ignored_slowloguser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ignored_slowloguser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `index_release`
--

DROP TABLE IF EXISTS `index_release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_release` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `dbsqlscript` varchar(1000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isCreate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `machine_mounterrorlist`
--

DROP TABLE IF EXISTS `machine_mounterrorlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machine_mounterrorlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(64) DEFAULT NULL,
  `errorinfo` varchar(200) DEFAULT NULL,
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `machine_mountlist`
--

DROP TABLE IF EXISTS `machine_mountlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `machine_mountlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(60) DEFAULT NULL,
  `glusterfs_dns` varchar(125) DEFAULT NULL,
  `extra_info` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_allaccounts`
--

DROP TABLE IF EXISTS `mysql_allaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_allaccounts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(64) DEFAULT NULL,
  `machine_name` varchar(64) DEFAULT NULL,
  `env_type` varchar(20) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `host` varchar(30) DEFAULT NULL,
  `total_connections` bigint(20) DEFAULT NULL,
  `insert_date` date DEFAULT NULL,
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '时间戳',
  PRIMARY KEY (`id`),
  KEY `idx_insert_date` (`insert_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_allaccounts_everyday`
--

DROP TABLE IF EXISTS `mysql_allaccounts_everyday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_allaccounts_everyday` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(64) DEFAULT NULL,
  `machine_name` varchar(64) DEFAULT NULL,
  `env_type` varchar(20) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `host` varchar(30) DEFAULT NULL,
  `total_connections` bigint(20) DEFAULT NULL,
  `insert_date` date DEFAULT NULL,
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '时间戳',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_autobackfilelist`
--

DROP TABLE IF EXISTS `mysql_autobackfilelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_autobackfilelist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(50) DEFAULT NULL,
  `Backupset` varchar(20) DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `Filesize` bigint(20) DEFAULT NULL,
  `Backup_start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Backup_end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Ftp_Start_Time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Ftp_end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `netip` varchar(200) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_insert_time` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_autoincrement_history`
--

DROP TABLE IF EXISTS `mysql_autoincrement_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_autoincrement_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `columnname` varchar(128) DEFAULT NULL,
  `max_value` bigint(20) DEFAULT NULL,
  `insert_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_1` (`machine_name`,`dbname`,`tablename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_disaster_recovery`
--

DROP TABLE IF EXISTS `mysql_disaster_recovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_disaster_recovery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_host` varchar(64) DEFAULT NULL,
  `slave_host` varchar(64) DEFAULT NULL,
  `service_name` varchar(64) DEFAULT NULL,
  `service_ip` varchar(20) DEFAULT NULL,
  `service_port` int(11) DEFAULT NULL,
  `server_status` char(10) DEFAULT NULL,
  `slave_status` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_fulldisk`
--

DROP TABLE IF EXISTS `mysql_fulldisk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_fulldisk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `report_times` int(11) DEFAULT NULL,
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_importance_machine`
--

DROP TABLE IF EXISTS `mysql_importance_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_importance_machine` (
  `machine_name` varchar(50) DEFAULT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_importance_machine_temp`
--

DROP TABLE IF EXISTS `mysql_importance_machine_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_importance_machine_temp` (
  `machine_name` varchar(50) DEFAULT NULL,
  `dbname` varchar(128) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_index_contact`
--

DROP TABLE IF EXISTS `mysql_index_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_index_contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `table_rows` int(11) DEFAULT NULL,
  `indexname` varchar(128) DEFAULT NULL,
  `colunname` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_index_delete`
--

DROP TABLE IF EXISTS `mysql_index_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_index_delete` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `OBJECT_SCHEMA` varchar(120) DEFAULT NULL,
  `OBJECT_NAME` varchar(120) DEFAULT NULL,
  `INDEX_NAME` varchar(120) DEFAULT NULL,
  `row_count` bigint(20) DEFAULT NULL,
  `index_column` varchar(500) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_index_delete1`
--

DROP TABLE IF EXISTS `mysql_index_delete1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_index_delete1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `OBJECT_SCHEMA` varchar(120) DEFAULT NULL,
  `OBJECT_NAME` varchar(120) DEFAULT NULL,
  `INDEX_NAME` varchar(120) DEFAULT NULL,
  `row_count` bigint(20) DEFAULT NULL,
  `COUNT_STAR` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_index_usage`
--

DROP TABLE IF EXISTS `mysql_index_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_index_usage` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `HostName` varchar(50) NOT NULL DEFAULT '',
  `OBJECT_SCHEMA` varchar(80) NOT NULL DEFAULT '',
  `OBJECT_NAME` varchar(80) NOT NULL DEFAULT '',
  `INDEX_NAME` varchar(80) NOT NULL DEFAULT '',
  `COUNT_STAR` int(11) NOT NULL,
  `COUNT_READ` int(11) NOT NULL,
  `COUNT_WRITE` int(11) NOT NULL,
  `COUNT_FETCH` int(11) NOT NULL,
  `COUNT_INSERT` int(11) NOT NULL,
  `COUNT_UPDATE` int(11) NOT NULL,
  `COUNT_DELETE` int(11) NOT NULL,
  `Data_Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_1` (`OBJECT_SCHEMA`,`OBJECT_NAME`,`INDEX_NAME`),
  KEY `idx_2` (`COUNT_STAR`),
  KEY `idx_Data_Time` (`Data_Time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_index_usage_whitelists`
--

DROP TABLE IF EXISTS `mysql_index_usage_whitelists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_index_usage_whitelists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `indexname` varchar(128) DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_paritition_maxvaluereport`
--

DROP TABLE IF EXISTS `mysql_paritition_maxvaluereport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_paritition_maxvaluereport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(64) DEFAULT NULL,
  `tablename` varchar(64) DEFAULT NULL,
  `PARTITION_NAME` varchar(64) DEFAULT NULL,
  `TABLE_ROWS` bigint(20) DEFAULT NULL,
  `PARTITION_DESCRIPTION` varchar(32) DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_traceinfo`
--

DROP TABLE IF EXISTS `mysql_traceinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_traceinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerName` varchar(256) DEFAULT NULL,
  `LoginName` varchar(256) DEFAULT NULL,
  `LoginHost` varchar(256) DEFAULT NULL,
  `LoginIP` varchar(256) DEFAULT NULL,
  `Type` varchar(32) DEFAULT NULL,
  `Command_Class` varchar(32) DEFAULT NULL,
  `SqlText` text,
  `Code` varchar(32) DEFAULT NULL,
  `datatime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `DNS` varchar(50) DEFAULT NULL,
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`datatime`),
  KEY `Type` (`Type`),
  KEY `idx_servername` (`ServerName`(255)),
  KEY `idx_datatime` (`datatime`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50100 PARTITION BY RANGE (to_days(datatime))
(PARTITION p20150812 VALUES LESS THAN (736188) ENGINE = InnoDB,
 PARTITION p20150813 VALUES LESS THAN (736189) ENGINE = InnoDB,
 PARTITION p20150814 VALUES LESS THAN (736190) ENGINE = InnoDB,
 PARTITION p20150815 VALUES LESS THAN (736191) ENGINE = InnoDB,
 PARTITION p20150816 VALUES LESS THAN (736192) ENGINE = InnoDB,
 PARTITION p20150817 VALUES LESS THAN (736193) ENGINE = InnoDB,
 PARTITION p20150818 VALUES LESS THAN (736194) ENGINE = InnoDB,
 PARTITION p20150819 VALUES LESS THAN (736195) ENGINE = InnoDB,
 PARTITION p20150820 VALUES LESS THAN (736196) ENGINE = InnoDB,
 PARTITION p20150821 VALUES LESS THAN (736197) ENGINE = InnoDB,
 PARTITION p20150822 VALUES LESS THAN (736198) ENGINE = InnoDB,
 PARTITION p20150823 VALUES LESS THAN (736199) ENGINE = InnoDB,
 PARTITION p20150824 VALUES LESS THAN (736200) ENGINE = InnoDB,
 PARTITION p20150825 VALUES LESS THAN (736201) ENGINE = InnoDB,
 PARTITION p20150826 VALUES LESS THAN (736202) ENGINE = InnoDB,
 PARTITION p20150827 VALUES LESS THAN (736203) ENGINE = InnoDB,
 PARTITION p20150828 VALUES LESS THAN (736204) ENGINE = InnoDB,
 PARTITION p20150829 VALUES LESS THAN (736205) ENGINE = InnoDB,
 PARTITION p20150830 VALUES LESS THAN (736206) ENGINE = InnoDB,
 PARTITION p20150831 VALUES LESS THAN (736207) ENGINE = InnoDB,
 PARTITION pMax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mysql_userlist`
--

DROP TABLE IF EXISTS `mysql_userlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_userlist` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(64) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `dbname` varchar(64) DEFAULT NULL,
  `client_name` varchar(64) DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `counts` int(11) DEFAULT NULL,
  `get_time` datetime DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_get_time` (`get_time`),
  KEY `idx_1` (`hostname`,`user`,`dbname`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ready_createindexlist`
--

DROP TABLE IF EXISTS `ready_createindexlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ready_createindexlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `indexname` varchar(128) DEFAULT NULL,
  `index_column` varchar(500) NOT NULL DEFAULT '',
  `operator` varchar(128) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `isCreate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ready_dropindexlist`
--

DROP TABLE IF EXISTS `ready_dropindexlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ready_dropindexlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `tablename` varchar(128) DEFAULT NULL,
  `indexname` varchar(128) DEFAULT NULL,
  `operator` varchar(128) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_smoking_log`
--

DROP TABLE IF EXISTS `server_smoking_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_smoking_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `smoking_type` varchar(20) DEFAULT NULL,
  `recovered_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_smoking_processrecords`
--

DROP TABLE IF EXISTS `server_smoking_processrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_smoking_processrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `smoking_type` varchar(20) DEFAULT NULL,
  `begin_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recovered` char(5) NOT NULL DEFAULT 'N',
  `recovered_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_1` (`machine_name`,`smoking_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_autocheckdetail`
--

DROP TABLE IF EXISTS `slowlog_autocheckdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_autocheckdetail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) NOT NULL COMMENT '对应表 autoCheckResult.id',
  `result` text NOT NULL COMMENT '详细审核内容',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pid` (`pid`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_autocheckhost`
--

DROP TABLE IF EXISTS `slowlog_autocheckhost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_autocheckhost` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(128) DEFAULT NULL COMMENT '主机名',
  `loginname` varchar(64) DEFAULT NULL COMMENT 'mysql 登录用户',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hostname` (`hostname`,`loginname`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`),
  KEY `idx_loginanme` (`loginname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_autocheckresult`
--

DROP TABLE IF EXISTS `slowlog_autocheckresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_autocheckresult` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(128) DEFAULT NULL COMMENT '主机名',
  `loginname` varchar(20) DEFAULT NULL COMMENT 'mysql 登录用户',
  `hashcode` varchar(64) NOT NULL DEFAULT '' COMMENT '抽象化sql的hash 值',
  `sourcesql` longtext COMMENT '实际的 sql',
  `prd_exectime` varchar(64) DEFAULT NULL COMMENT '生产环境平均执行时间( 秒 )',
  `review_exectime` varchar(64) DEFAULT '0.0000' COMMENT 'review环境平均执行时间( 秒 )',
  `avgFreq` varchar(64) NOT NULL DEFAULT '0.0000' COMMENT '平均执行次数/天',
  `topFreq` varchar(64) NOT NULL DEFAULT '0.0000' COMMENT '高峰时段平均执行次数/天',
  `result` text NOT NULL COMMENT '审核结果: pass / fail',
  `explan` longtext COMMENT '执行计划',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hostname_loginname_hashcode` (`hostname`,`loginname`,`hashcode`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`),
  KEY `idx_loginname_datachange_lasttime` (`loginname`,`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_history`
--

DROP TABLE IF EXISTS `slowlog_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(20) DEFAULT NULL COMMENT '主机名',
  `loginname` varchar(20) DEFAULT NULL COMMENT 'mysql 登录用户',
  `loginip` varchar(64) DEFAULT NULL COMMENT 'mysql 登录的源IP',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `begin_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `query_time_avg` float DEFAULT NULL COMMENT '平均执行时间',
  `query_time_total` float DEFAULT NULL COMMENT '总查询时间',
  `locktime_avg` float DEFAULT NULL COMMENT '平均锁时间',
  `counts` int(11) DEFAULT NULL COMMENT '执行次数',
  `avgRows` float DEFAULT NULL COMMENT '平均返回行数',
  `hashcode` varchar(64) NOT NULL DEFAULT '' COMMENT '抽象化sql的hash 值',
  PRIMARY KEY (`id`),
  KEY `idx_hashcode` (`hashcode`),
  KEY `idx_hostname_loginname_hashcode` (`hostname`,`loginname`,`hashcode`,`begin_time`),
  KEY `idx_begin_time` (`begin_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2867897 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_mailconf`
--

DROP TABLE IF EXISTS `slowlog_mailconf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_mailconf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(64) NOT NULL DEFAULT '' COMMENT '数据库名称',
  `maillist` varchar(10000) NOT NULL DEFAULT '' COMMENT '要发送的 email 地址',
  `topN` int(11) NOT NULL DEFAULT '10' COMMENT '前 N 条 slowlog 发送',
  `exeTime` int(11) NOT NULL DEFAULT '100' COMMENT '平均每天总的执行时间超过 N 的发送邮件',
  `isSend` int(11) NOT NULL DEFAULT '1' COMMENT '是否要发送: 1 : 发送,  0: 不发送',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dbname` (`dbname`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `slowlog_sql`
--

DROP TABLE IF EXISTS `slowlog_sql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slowlog_sql` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(20) DEFAULT NULL COMMENT '主机名',
  `loginname` varchar(20) DEFAULT NULL COMMENT 'mysql 登录用户',
  `loginip` varchar(128) DEFAULT NULL COMMENT 'mysql 登录的源IP',
  `hashcode` varchar(64) NOT NULL DEFAULT '' COMMENT '抽象出的sql的 hash值',
  `database_name` varchar(100) DEFAULT NULL,
  `sqltext` longtext COMMENT '抽象化的 sql',
  `sourcesql` longtext COMMENT '实际执行的 sql',
  `sqlchange_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'sourcesql 上次更新时间',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `send_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hostname_loginname_hashcode` (`hostname`,`loginname`,`hashcode`),
  KEY `idx_hashcode` (`hashcode`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`),
  KEY `idx_loginanme` (`loginname`)
) ENGINE=InnoDB AUTO_INCREMENT=1013549 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smoking_mysql_block_killinfo`
--

DROP TABLE IF EXISTS `smoking_mysql_block_killinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smoking_mysql_block_killinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `killid` int(11) DEFAULT NULL,
  `user` varchar(20) DEFAULT NULL,
  `host` varchar(30) DEFAULT NULL,
  `db` varchar(50) DEFAULT NULL,
  `info` varchar(2000) DEFAULT NULL,
  `kill_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smoking_mysql_cpu`
--

DROP TABLE IF EXISTS `smoking_mysql_cpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smoking_mysql_cpu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `dns` varchar(200) DEFAULT NULL,
  `ObjectName` varchar(50) DEFAULT NULL,
  `CounterValue` float DEFAULT NULL,
  `proc_info` longtext,
  `engine_info` longtext,
  `top_info` varchar(200) DEFAULT NULL,
  `insert_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `smoking_mysql_repl_errorinfo`
--

DROP TABLE IF EXISTS `smoking_mysql_repl_errorinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smoking_mysql_repl_errorinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `errornumber` int(11) DEFAULT NULL,
  `errorinfo` varchar(5000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `syj_tmp_mysqlbakiplist`
--

DROP TABLE IF EXISTS `syj_tmp_mysqlbakiplist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `syj_tmp_mysqlbakiplist` (
  `machine_name` varchar(30) DEFAULT NULL,
  `ipbak` varchar(30) DEFAULT NULL,
  `ipbak_getway` varchar(30) DEFAULT NULL,
  `gluster` varchar(50) DEFAULT NULL,
  `gluster_ipduan` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_mysql_index_usage`
--

DROP TABLE IF EXISTS `tmp_mysql_index_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_mysql_index_usage` (
  `OBJECT_SCHEMA` varchar(128) DEFAULT NULL,
  `OBJECT_NAME` varchar(128) DEFAULT NULL,
  `INDEX_NAME` varchar(128) DEFAULT NULL,
  `COUNT_STAR` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tmp_mysqlbakiplist`
--

DROP TABLE IF EXISTS `tmp_mysqlbakiplist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp_mysqlbakiplist` (
  `machine_name` varchar(30) DEFAULT NULL,
  `ipbak` varchar(30) DEFAULT NULL,
  `ipbak_getway` varchar(30) DEFAULT NULL,
  `gluster` varchar(50) DEFAULT NULL,
  `gluster_ipduan` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `un_upgrade_serverlist`
--

DROP TABLE IF EXISTS `un_upgrade_serverlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `un_upgrade_serverlist` (
  `hostname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `sqlmaintaindb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sqlmaintaindb` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `sqlmaintaindb`;

--
-- Table structure for table `_temp_dballinone`
--

DROP TABLE IF EXISTS `_temp_dballinone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_temp_dballinone` (
  `login_name` varchar(128) DEFAULT NULL,
  `db_name` varchar(128) DEFAULT NULL,
  `web_machine` varchar(128) DEFAULT NULL,
  `client_net_address` varchar(56) DEFAULT NULL,
  `program_name` varchar(128) DEFAULT NULL,
  `data_time` datetime DEFAULT NULL,
  KEY `idx_time` (`login_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ix_dbmap`
--

DROP TABLE IF EXISTS `ix_dbmap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ix_dbmap` (
  `db_name` varchar(128) DEFAULT NULL,
  `pub_dns` varchar(200) DEFAULT NULL,
  `test_dns` varchar(200) DEFAULT NULL,
  `pub_machine` varchar(128) DEFAULT NULL,
  `test_machine` varchar(128) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `Is_A10` bit(1) DEFAULT NULL,
  KEY `db_name` (`db_name`),
  KEY `ix_update_time` (`update_time`),
  KEY `ix_A10` (`Is_A10`),
  KEY `ix_test_dns` (`test_dns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ix_dbmap_bak`
--

DROP TABLE IF EXISTS `ix_dbmap_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ix_dbmap_bak` (
  `db_name` varchar(128) DEFAULT NULL,
  `pub_dns` varchar(200) DEFAULT NULL,
  `test_dns` varchar(200) DEFAULT NULL,
  `pub_machine` varchar(128) DEFAULT NULL,
  `test_machine` varchar(128) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `Is_A10` bit(1) DEFAULT NULL,
  KEY `db_name` (`db_name`),
  KEY `ix_update_time` (`update_time`),
  KEY `ix_A10` (`Is_A10`),
  KEY `ix_test_dns` (`test_dns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ix_dbmap_bak_20150714`
--

DROP TABLE IF EXISTS `ix_dbmap_bak_20150714`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ix_dbmap_bak_20150714` (
  `db_name` varchar(128) DEFAULT NULL,
  `pub_dns` varchar(200) DEFAULT NULL,
  `test_dns` varchar(200) DEFAULT NULL,
  `pub_machine` varchar(128) DEFAULT NULL,
  `test_machine` varchar(128) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `Is_A10` bit(1) DEFAULT NULL,
  KEY `db_name` (`db_name`),
  KEY `ix_update_time` (`update_time`),
  KEY `ix_A10` (`Is_A10`),
  KEY `ix_test_dns` (`test_dns`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ix_log`
--

DROP TABLE IF EXISTS `ix_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ix_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `conn` varchar(500) DEFAULT NULL,
  `cmd` varchar(5000) DEFAULT NULL,
  `ex` varchar(5000) DEFAULT NULL,
  `sta` varchar(50) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `insert_time` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `releaseuploaddb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `releaseuploaddb` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `releaseuploaddb`;

--
-- Table structure for table `_del_test`
--

DROP TABLE IF EXISTS `_del_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_del_test` (
  `a` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auditlog`
--

DROP TABLE IF EXISTS `auditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditlog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL DEFAULT '0',
  `TarsId` int(11) NOT NULL DEFAULT '0',
  `DBName` varchar(100) NOT NULL DEFAULT '' COMMENT '数据库名',
  `TableName` varchar(200) NOT NULL DEFAULT '' COMMENT '表名',
  `Status` int(11) NOT NULL DEFAULT '0' COMMENT 'DBA审核状态',
  `Message` text COMMENT '备注信息',
  `Creator` varchar(100) NOT NULL DEFAULT '' COMMENT '表单创建人',
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `backupsql`
--

DROP TABLE IF EXISTS `backupsql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backupsql` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TarsId` int(11) NOT NULL,
  `TaskId` int(11) NOT NULL,
  `ServerName` varchar(128) NOT NULL,
  `DBName` varchar(50) NOT NULL,
  `SqlScript` varchar(1024) DEFAULT NULL,
  `CreateTime` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `buildlog`
--

DROP TABLE IF EXISTS `buildlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildlog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL DEFAULT '0',
  `TarsId` int(11) NOT NULL DEFAULT '0',
  `DBName` varchar(100) NOT NULL DEFAULT '' COMMENT '数据库名',
  `TableName` varchar(200) NOT NULL DEFAULT '' COMMENT '表名',
  `Message` text COMMENT '详细信息',
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `Action` varchar(50) NOT NULL DEFAULT '' COMMENT '状态(success,error,info)',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datareg_replcfgaddarticle`
--

DROP TABLE IF EXISTS `datareg_replcfgaddarticle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datareg_replcfgaddarticle` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL,
  `Step` int(11) NOT NULL COMMENT '复制分发层级标识',
  `Environment` varchar(20) NOT NULL COMMENT '环境名称',
  `PublisherServer` varchar(256) NOT NULL COMMENT '发布Server',
  `PublisherDB` varchar(256) NOT NULL COMMENT '发布数据库',
  `Publication` varchar(256) NOT NULL COMMENT '发布项目名称',
  `IsPublicationNew` char(1) NOT NULL DEFAULT 'F' COMMENT '是否是新的发布项目，默认F (已有发布项目)',
  `Article` varchar(256) NOT NULL COMMENT '发布表',
  `PreCmd` varchar(40) NOT NULL COMMENT '发布属性',
  `Subscriberoperation` char(1) NOT NULL DEFAULT 'T' COMMENT '订阅操作，默认T',
  `FinishStatus` char(1) NOT NULL DEFAULT 'F' COMMENT '是否发布，默认F，发布成功后置T',
  `Details` varchar(255) DEFAULT NULL COMMENT '最后1次发布日志',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datareg_replcfgaddsubscription`
--

DROP TABLE IF EXISTS `datareg_replcfgaddsubscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datareg_replcfgaddsubscription` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL,
  `Step` int(4) NOT NULL COMMENT '复制分发层级标识',
  `Environment` varchar(20) NOT NULL COMMENT '环境名称',
  `PublisherServer` varchar(256) NOT NULL COMMENT '发布Server',
  `PublisherDB` varchar(256) NOT NULL COMMENT '发布数据库',
  `Publication` varchar(256) NOT NULL COMMENT '发布项目名称',
  `SubscriberServer` varchar(256) NOT NULL COMMENT '订阅Server',
  `SubscriberDB` varchar(256) NOT NULL COMMENT '订阅数据库',
  `SubscriberOperation` char(1) NOT NULL DEFAULT 'T' COMMENT '订阅操作，默认T',
  `FinishStatus` char(1) NOT NULL DEFAULT 'F' COMMENT '是否发布，默认F，发布成功后置T',
  `Details` varchar(255) DEFAULT NULL COMMENT '最后1次发布日志',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datareg_repltablecolumnforcompare`
--

DROP TABLE IF EXISTS `datareg_repltablecolumnforcompare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datareg_repltablecolumnforcompare` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ServerName` varchar(256) NOT NULL COMMENT '数据库服务器别名',
  `DBName` varchar(256) NOT NULL COMMENT '数据库名称',
  `ObjectName` varchar(256) NOT NULL COMMENT '表名',
  `ColumnName` varchar(256) NOT NULL COMMENT '字段名',
  `ColumnType` varchar(256) NOT NULL COMMENT '字段类型',
  `MaxLength` int(4) NOT NULL COMMENT '最大长度',
  `Precision` int(4) NOT NULL COMMENT '精度',
  `Scale` int(4) NOT NULL COMMENT '刻度',
  `Nullable` int(4) NOT NULL COMMENT '是否允许为空',
  `ColumnId` int(4) DEFAULT NULL COMMENT '列ID',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `datareg_repltablecolumnforcompare_tmp`
--

DROP TABLE IF EXISTS `datareg_repltablecolumnforcompare_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datareg_repltablecolumnforcompare_tmp` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `SourceServer` varchar(256) DEFAULT NULL COMMENT '发布源数据库服务器别名',
  `SourceDB` varchar(256) DEFAULT NULL COMMENT '发布源数据库名称',
  `DestinationServer` varchar(256) DEFAULT NULL COMMENT '订阅数据库服务器别名',
  `DestinationDB` varchar(256) DEFAULT NULL COMMENT '订阅数据库名称',
  `SourceTable` varchar(256) DEFAULT NULL COMMENT '发布表',
  `ColumnName` varchar(256) DEFAULT NULL COMMENT '字段名称',
  `SourceDef` varchar(256) DEFAULT NULL COMMENT '发布源差异',
  `DestinationDef` varchar(256) DEFAULT NULL COMMENT '订阅差异',
  `SourceColumnID` int(4) DEFAULT NULL COMMENT '发布源字段ColumnID',
  `DestColumnID` int(4) DEFAULT NULL COMMENT '订阅字段ColumnID',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `freezedate`
--

DROP TABLE IF EXISTS `freezedate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `freezedate` (
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gov_archdbobjectapplytorelapp`
--

DROP TABLE IF EXISTS `gov_archdbobjectapplytorelapp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gov_archdbobjectapplytorelapp` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TarsId` int(11) NOT NULL COMMENT '发布单号',
  `TaskId` int(11) NOT NULL COMMENT '注册单号',
  `Environment` varchar(20) NOT NULL COMMENT '环境名称',
  `Result` varchar(255) DEFAULT '' COMMENT '部署结果（如注册单发布失败，显示出报错原因）',
  `IsAvailable` int(4) NOT NULL DEFAULT '0' COMMENT '发布状态（0--待发布，1--发布成功，2—发布失败，11—发布成功且已发送邮件通知，21—发送失败且已发送邮件通知）。',
  `SystemName` varchar(10) DEFAULT NULL COMMENT '发起发布指令的人或系统名',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gov_archdbobjectapplytorelapp_log`
--

DROP TABLE IF EXISTS `gov_archdbobjectapplytorelapp_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gov_archdbobjectapplytorelapp_log` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TarsId` int(11) NOT NULL,
  `TaskId` int(11) NOT NULL,
  `Environment` varchar(20) NOT NULL COMMENT '环境名称',
  `InsertTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `Details` varchar(255) NOT NULL DEFAULT '' COMMENT '详细描述',
  `Is_Read` bit(1) NOT NULL DEFAULT b'0' COMMENT 'Croller默认读Is_Read=0，如果读过则置1',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operationtype`
--

DROP TABLE IF EXISTS `operationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operationtype` (
  `TypeId` int(11) NOT NULL AUTO_INCREMENT COMMENT '操作类型ID',
  `TypeName` varchar(100) NOT NULL DEFAULT '' COMMENT '操作类型名称',
  `DBType` varchar(100) NOT NULL DEFAULT '' COMMENT 'mysql sqlserver',
  PRIMARY KEY (`TypeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `publishlog`
--

DROP TABLE IF EXISTS `publishlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishlog` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskId` int(11) NOT NULL DEFAULT '0',
  `TarsId` int(11) NOT NULL DEFAULT '0',
  `DBName` varchar(100) NOT NULL DEFAULT '' COMMENT '数据库名',
  `TableName` varchar(200) NOT NULL DEFAULT '' COMMENT '表名',
  `EnvName` varchar(50) NOT NULL DEFAULT '' COMMENT '发布环境',
  `Message` text COMMENT '详细信息',
  `Publisher` varchar(100) NOT NULL DEFAULT '' COMMENT '操作者',
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `action` varchar(100) DEFAULT 'info',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queues`
--

DROP TABLE IF EXISTS `queues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queues` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `TaskIds` int(11) NOT NULL DEFAULT '0' COMMENT '需要进行操作的单号集',
  `Operation` varchar(50) NOT NULL DEFAULT '' COMMENT '操作(编译、发布,人工审核)',
  `Status` int(11) NOT NULL DEFAULT '0' COMMENT '队列状态 1:未开始，2:进行中,3:成功，4:失败 ',
  `DBType` varchar(100) NOT NULL DEFAULT '' COMMENT 'mysql sqlserver',
  `EnvName` varchar(50) NOT NULL DEFAULT '' COMMENT '发布环境',
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `release_dbconfig`
--

DROP TABLE IF EXISTS `release_dbconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_dbconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(256) NOT NULL,
  `port` int(11) NOT NULL,
  `db_name` varchar(256) NOT NULL,
  `Upload_DBName` varchar(256) DEFAULT NULL,
  `db_type` varchar(20) NOT NULL,
  `env_type` varchar(20) NOT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `croller` int(11) NOT NULL DEFAULT '1' COMMENT '默认1代表从croller发布',
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '默认1：有效',
  `cd` int(11) NOT NULL DEFAULT '1' COMMENT '默认1代表cd能发布',
  `last_updator` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `server_name` (`server_name`(50),`Upload_DBName`(50),`db_type`,`env_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `release_dbconfig_tmp`
--

DROP TABLE IF EXISTS `release_dbconfig_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_dbconfig_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(256) NOT NULL,
  `port` int(11) NOT NULL,
  `db_name` varchar(256) NOT NULL,
  `Upload_DBName` varchar(256) DEFAULT NULL,
  `db_type` varchar(20) NOT NULL,
  `env_type` varchar(20) NOT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `croller` int(11) NOT NULL DEFAULT '1' COMMENT '默认1代表从croller发布',
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '默认1：有效',
  `cd` int(11) NOT NULL DEFAULT '1' COMMENT '默认1代表cd能发布',
  `last_updator` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `server_name` (`server_name`(50),`Upload_DBName`(50),`db_type`,`env_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `renametablelog`
--

DROP TABLE IF EXISTS `renametablelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `renametablelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `DNS` varchar(100) DEFAULT NULL COMMENT '服务器域名',
  `port` int(11) DEFAULT NULL COMMENT '端口',
  `database_name` varchar(50) DEFAULT NULL COMMENT 'db名称',
  `old_tablename` varchar(50) DEFAULT NULL COMMENT 'rename之前的表名',
  `new_tablename` varchar(50) DEFAULT NULL COMMENT 'rename之后的表名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `TaskId` int(11) NOT NULL AUTO_INCREMENT COMMENT '生成的TaskId',
  `TarsId` int(11) NOT NULL DEFAULT '0' COMMENT 'Tars传过来的ID',
  `OpearTypeId` int(11) NOT NULL DEFAULT '0' COMMENT '操作类型(新建表、字段等)',
  `DBName` varchar(100) NOT NULL DEFAULT '' COMMENT '数据库名',
  `TableName` varchar(200) NOT NULL DEFAULT '' COMMENT '表名',
  `FieldName` varchar(200) NOT NULL DEFAULT '' COMMENT '字段名',
  `IndexName` varchar(200) NOT NULL DEFAULT '' COMMENT '索引名',
  `ReplDBName` varchar(200) NOT NULL DEFAULT '' COMMENT '订阅DB',
  `SqlScript` mediumtext COMMENT 'sql脚本',
  `TaskStep` int(11) NOT NULL DEFAULT '0' COMMENT '任务阶段',
  `TaskStatus` int(11) NOT NULL DEFAULT '0' COMMENT '阶段状态',
  `TaskStatusDesc` varchar(200) NOT NULL DEFAULT '' COMMENT '阶段状态描述',
  `PlanReleaseTime` int(11) NOT NULL DEFAULT '17' COMMENT '计划发布时间:0-24小时之间的数，发布时间需要晚于此数字',
  `DataChangeTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后更新时间',
  `CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '插入时间',
  `Creator` varchar(100) NOT NULL DEFAULT '' COMMENT '表单创建人',
  `LastUpdator` varchar(100) NOT NULL DEFAULT '' COMMENT '最后操作者',
  `DBType` varchar(100) NOT NULL DEFAULT '' COMMENT 'mysql sqlserver',
  PRIMARY KEY (`TaskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-02 14:31:55
