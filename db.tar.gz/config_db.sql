-- MySQL dump 10.13  Distrib 5.6.27, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: mysqluploaddb
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='de94d50e-fb59-11e7-bf35-000c29903c5f:1-5380';

--
-- Table structure for table `addcolumn_dbarelease`
--

DROP TABLE IF EXISTS `addcolumn_dbarelease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addcolumn_dbarelease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `dbsqlscript` varchar(1000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isCreate` int(11) NOT NULL DEFAULT '0',
  `is_manual` tinyint(4) DEFAULT '0' COMMENT '是否转手工',
  `appid` int(11) NOT NULL COMMENT '发布单号',
  PRIMARY KEY (`id`),
  KEY `idx_insert_time` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addcolumn_dbarelease`
--

LOCK TABLES `addcolumn_dbarelease` WRITE;
/*!40000 ALTER TABLE `addcolumn_dbarelease` DISABLE KEYS */;
/*!40000 ALTER TABLE `addcolumn_dbarelease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applydns`
--

DROP TABLE IF EXISTS `applydns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applydns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operation` varchar(64) NOT NULL DEFAULT '',
  `nodename` varchar(128) NOT NULL DEFAULT '',
  `zone` varchar(128) NOT NULL DEFAULT '',
  `rrtype` varchar(128) NOT NULL DEFAULT '',
  `target` varchar(128) NOT NULL DEFAULT '',
  `newrrtype` varchar(128) NOT NULL DEFAULT '',
  `newtarget` varchar(128) NOT NULL DEFAULT '',
  `status` varchar(64) NOT NULL DEFAULT '失败',
  `apply_user` varchar(64) NOT NULL DEFAULT '',
  `modify_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applydns`
--

LOCK TABLES `applydns` WRITE;
/*!40000 ALTER TABLE `applydns` DISABLE KEYS */;
/*!40000 ALTER TABLE `applydns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `is_userdef` tinyint(4) NOT NULL DEFAULT '0',
  `description` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `group_id_refs_id_3cea63fe` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `permission_id_refs_id_a7792de1` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_728de91f` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (143,'admin','admin','admin','88888888@vip.com','pbkdf2_sha256$10000$M9qcl8KO5kKo$c8gEebpEFcCw9QbMxmIjpaC51bx8mCZDcYeaFuT+NFo=',1,1,1,'2018-02-02 03:23:28','2017-12-26 07:24:34'),(146,'ad','ad','ad','','pbkdf2_sha256$10000$YKJ4R3mSVihe$KH+lupPTwlBw2E1IP5iiXVVyhmmwdNNtFhP11qwHB1Q=',1,1,0,'2017-12-26 08:18:16','2017-12-26 08:18:16'),(148,'test01','test01','test01','aa','pbkdf2_sha256$10000$L4o3vqOVWOGD$h5JU+I1PnyL1Sr8a2clMzWR02TOrfUx3D0PSuB8VYnE=',1,1,0,'2018-02-02 03:22:33','2017-12-26 10:22:51');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`),
  CONSTRAINT `group_id_refs_id_f0ee9890` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `user_id_refs_id_831107f1` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`),
  CONSTRAINT `permission_id_refs_id_67e79cb` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `user_id_refs_id_f2045483` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_mysql_mhainfo`
--

DROP TABLE IF EXISTS `cf_mysql_mhainfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mysql_mhainfo` (
  `cluster_name` varchar(128) NOT NULL,
  `mhamanager_id` int(11) NOT NULL DEFAULT '0',
  `mhacron_status` int(11) NOT NULL DEFAULT '0' COMMENT '1:open 0:close 2:fail',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cluster_name`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_mysql_mhainfo`
--

LOCK TABLES `cf_mysql_mhainfo` WRITE;
/*!40000 ALTER TABLE `cf_mysql_mhainfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_mysql_mhainfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cf_mysql_mhastatus`
--

DROP TABLE IF EXISTS `cf_mysql_mhastatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cf_mysql_mhastatus` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(128) NOT NULL,
  `mhamanager_status` int(11) NOT NULL DEFAULT '0' COMMENT '1:running 0:not running',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mhahostname` varchar(30) NOT NULL,
  PRIMARY KEY (`id`,`datachange_lasttime`),
  KEY `idx_datachange_lasttime` (`datachange_lasttime`),
  KEY `idx_cluster_name_datachange_lasttime` (`cluster_name`,`datachange_lasttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cf_mysql_mhastatus`
--

LOCK TABLES `cf_mysql_mhastatus` WRITE;
/*!40000 ALTER TABLE `cf_mysql_mhastatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `cf_mysql_mhastatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checklistmodel1`
--

DROP TABLE IF EXISTS `checklistmodel1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checklistmodel1` (
  `id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `executeStatement` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checklistmodel1`
--

LOCK TABLES `checklistmodel1` WRITE;
/*!40000 ALTER TABLE `checklistmodel1` DISABLE KEYS */;
/*!40000 ALTER TABLE `checklistmodel1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clogerr_history`
--

DROP TABLE IF EXISTS `clogerr_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clogerr_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` bigint(20) DEFAULT NULL,
  `now_except_count` int(11) DEFAULT NULL,
  `createdata_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cname` varchar(100) DEFAULT NULL,
  `owner` varchar(100) DEFAULT NULL,
  `ownerEmail` varchar(200) DEFAULT NULL,
  `url` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clogerr_history`
--

LOCK TABLES `clogerr_history` WRITE;
/*!40000 ALTER TABLE `clogerr_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `clogerr_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clogerr_policy`
--

DROP TABLE IF EXISTS `clogerr_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clogerr_policy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` bigint(20) NOT NULL,
  `alter_base_count` int(11) DEFAULT NULL,
  `alter_increment_count` int(11) DEFAULT NULL,
  `till_effective_time` datetime NOT NULL,
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_appid` (`appid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clogerr_policy`
--

LOCK TABLES `clogerr_policy` WRITE;
/*!40000 ALTER TABLE `clogerr_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `clogerr_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clusterstatus`
--

DROP TABLE IF EXISTS `clusterstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clusterstatus` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clusername` varchar(50) DEFAULT NULL,
  `cluseraddress` varchar(50) DEFAULT NULL,
  `cluster_status` varchar(20) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_date_time` (`date_time`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clusterstatus`
--

LOCK TABLES `clusterstatus` WRITE;
/*!40000 ALTER TABLE `clusterstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `clusterstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_basetab`
--

DROP TABLE IF EXISTS `cron_basetab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron_basetab` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exec_statement` varchar(100) NOT NULL,
  `type` varchar(10) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_basetab`
--

LOCK TABLES `cron_basetab` WRITE;
/*!40000 ALTER TABLE `cron_basetab` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_basetab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cron_whitelist`
--

DROP TABLE IF EXISTS `cron_whitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cron_whitelist` (
  `machine_name` varchar(20) NOT NULL,
  PRIMARY KEY (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_whitelist`
--

LOCK TABLES `cron_whitelist` WRITE;
/*!40000 ALTER TABLE `cron_whitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_whitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cronlist`
--

DROP TABLE IF EXISTS `cronlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cronlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cron_name` varchar(255) DEFAULT NULL,
  `scope` varchar(50) DEFAULT NULL,
  `warningstime` int(11) DEFAULT NULL,
  `exceptant` varchar(255) NOT NULL DEFAULT '',
  `insert_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cronlist`
--

LOCK TABLES `cronlist` WRITE;
/*!40000 ALTER TABLE `cronlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cronlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cronrulelist`
--

DROP TABLE IF EXISTS `cronrulelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cronrulelist` (
  `cronsubject` varchar(50) DEFAULT NULL,
  `cronname` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cronrulelist`
--

LOCK TABLES `cronrulelist` WRITE;
/*!40000 ALTER TABLE `cronrulelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cronrulelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crontab_doevent_list`
--

DROP TABLE IF EXISTS `crontab_doevent_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crontab_doevent_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `todolistid` int(11) DEFAULT '0',
  `waittime` int(11) DEFAULT '0',
  `cmd` varchar(200) DEFAULT '',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` int(11) DEFAULT '0' COMMENT '0表示未开始，1表示已经被调用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crontab_doevent_list`
--

LOCK TABLES `crontab_doevent_list` WRITE;
/*!40000 ALTER TABLE `crontab_doevent_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `crontab_doevent_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_applyinfo`
--

DROP TABLE IF EXISTS `db_applyinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_applyinfo` (
  `AppID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `AppliedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `AppliedBy` varchar(30) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Description` varchar(200) NOT NULL DEFAULT '',
  `DBUser` varchar(16) NOT NULL,
  `ReadUser` varchar(16) NOT NULL DEFAULT '',
  `EstimatedSize` varchar(30) NOT NULL,
  `EstimatedOnlineDate` varchar(30) NOT NULL,
  `Requirement` varchar(500) DEFAULT NULL,
  `ownerphone` varchar(20) DEFAULT '',
  `importance` varchar(20) DEFAULT '',
  `source` varchar(40) DEFAULT 'mysqltools',
  `dbticket_num` varchar(30) DEFAULT '',
  `dr_requrement` varchar(100) DEFAULT '',
  PRIMARY KEY (`AppID`),
  KEY `idx_dbname_Status` (`DBName`,`Status`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_applyinfo`
--

LOCK TABLES `db_applyinfo` WRITE;
/*!40000 ALTER TABLE `db_applyinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_applyinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_applyinfo_check_log`
--

DROP TABLE IF EXISTS `db_applyinfo_check_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_applyinfo_check_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `DBName` varchar(64) NOT NULL,
  `Reviewer` varchar(20) NOT NULL,
  `LogTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `DBName` (`DBName`),
  KEY `appid` (`AppID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_applyinfo_check_log`
--

LOCK TABLES `db_applyinfo_check_log` WRITE;
/*!40000 ALTER TABLE `db_applyinfo_check_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_applyinfo_check_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_baseinfo`
--

DROP TABLE IF EXISTS `db_baseinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_baseinfo` (
  `DBName` varchar(64) NOT NULL,
  `Description` varchar(100) NOT NULL DEFAULT '',
  `Owner` varchar(100) NOT NULL DEFAULT '',
  `Department` varchar(30) NOT NULL,
  `importance` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_baseinfo`
--

LOCK TABLES `db_baseinfo` WRITE;
/*!40000 ALTER TABLE `db_baseinfo` DISABLE KEYS */;
INSERT INTO `db_baseinfo` VALUES ('test_partition','test_partition','','','0'),('conn','conn','','','0'),('heiheihei','heiheihei','','','0');
/*!40000 ALTER TABLE `db_baseinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_baseinfo_20171215`
--

DROP TABLE IF EXISTS `db_baseinfo_20171215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_baseinfo_20171215` (
  `DBName` varchar(64) NOT NULL,
  `Description` varchar(100) NOT NULL DEFAULT '',
  `Owner` varchar(100) NOT NULL DEFAULT '',
  `Department` varchar(30) NOT NULL,
  `importance` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`DBName`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_baseinfo_20171215`
--

LOCK TABLES `db_baseinfo_20171215` WRITE;
/*!40000 ALTER TABLE `db_baseinfo_20171215` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_baseinfo_20171215` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_conninfo`
--

DROP TABLE IF EXISTS `db_conninfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_conninfo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Envt` varchar(60) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `DBUser` varchar(16) NOT NULL,
  `Password` blob NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`),
  KEY `idx_dbname_envt` (`DBName`,`Envt`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_conninfo`
--

LOCK TABLES `db_conninfo` WRITE;
/*!40000 ALTER TABLE `db_conninfo` DISABLE KEYS */;
INSERT INTO `db_conninfo` VALUES (39,'test_partition','生产','192.168.175.130',3306,'default_user',''),(40,'conn','生产','192.168.175.130',3306,'default_user',''),(41,'heiheihei','生产','192.168.175.130',3306,'default_user','');
/*!40000 ALTER TABLE `db_conninfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_conninfo_20171215`
--

DROP TABLE IF EXISTS `db_conninfo_20171215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_conninfo_20171215` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Envt` varchar(60) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `DBUser` varchar(16) NOT NULL,
  `Password` blob NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`),
  KEY `idx_dbname_envt` (`DBName`,`Envt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_conninfo_20171215`
--

LOCK TABLES `db_conninfo_20171215` WRITE;
/*!40000 ALTER TABLE `db_conninfo_20171215` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_conninfo_20171215` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_conninfo_requests`
--

DROP TABLE IF EXISTS `db_conninfo_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_conninfo_requests` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `DBName` varchar(64) NOT NULL,
  `Envt` varchar(60) NOT NULL,
  `isWR` varchar(20) NOT NULL,
  `CallbackUrl` varchar(300) NOT NULL,
  `LogTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `DBName` (`DBName`),
  KEY `appid` (`AppID`),
  KEY `idx_tmp1` (`isWR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_conninfo_requests`
--

LOCK TABLES `db_conninfo_requests` WRITE;
/*!40000 ALTER TABLE `db_conninfo_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_conninfo_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_conninfo_tmp`
--

DROP TABLE IF EXISTS `db_conninfo_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_conninfo_tmp` (
  `DBName` varchar(64) NOT NULL,
  `Envt` varchar(60) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `DBUser` varchar(16) NOT NULL,
  `Password` varchar(50) DEFAULT NULL,
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_conninfo_tmp`
--

LOCK TABLES `db_conninfo_tmp` WRITE;
/*!40000 ALTER TABLE `db_conninfo_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_conninfo_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_conninfo_tynew`
--

DROP TABLE IF EXISTS `db_conninfo_tynew`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_conninfo_tynew` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Envt` varchar(60) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `DBUser` varchar(16) NOT NULL,
  `Password` blob NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_conninfo_tynew`
--

LOCK TABLES `db_conninfo_tynew` WRITE;
/*!40000 ALTER TABLE `db_conninfo_tynew` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_conninfo_tynew` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_deploy_log`
--

DROP TABLE IF EXISTS `db_deploy_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_deploy_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `DBName` varchar(64) NOT NULL,
  `Deployer` varchar(20) NOT NULL,
  `Envt` varchar(60) DEFAULT NULL,
  `LogTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `DBName` (`DBName`),
  KEY `appid` (`AppID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_deploy_log`
--

LOCK TABLES `db_deploy_log` WRITE;
/*!40000 ALTER TABLE `db_deploy_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_deploy_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_titan_requests`
--

DROP TABLE IF EXISTS `db_titan_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_titan_requests` (
  `requestid` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(100) DEFAULT NULL,
  `domain` varchar(500) DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '0',
  `dbuser` varchar(128) NOT NULL,
  `envt` varchar(10) NOT NULL,
  `isread` int(11) NOT NULL DEFAULT '0',
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0:未处理 1:处理中 2:成功 3:失败',
  PRIMARY KEY (`requestid`),
  KEY `idx_dbname` (`dbname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_titan_requests`
--

LOCK TABLES `db_titan_requests` WRITE;
/*!40000 ALTER TABLE `db_titan_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_titan_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_titan_requests_log`
--

DROP TABLE IF EXISTS `db_titan_requests_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_titan_requests_log` (
  `logid` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) NOT NULL,
  `dbuser` varchar(128) NOT NULL,
  `envt` varchar(10) NOT NULL,
  `return_content` varchar(500) DEFAULT NULL,
  `datachange_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status_code` int(11) DEFAULT NULL,
  `keyname` varchar(100) DEFAULT NULL,
  `domain` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`logid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_titan_requests_log`
--

LOCK TABLES `db_titan_requests_log` WRITE;
/*!40000 ALTER TABLE `db_titan_requests_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_titan_requests_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbatool_script_list`
--

DROP TABLE IF EXISTS `dbatool_script_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbatool_script_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `script_name` varchar(100) NOT NULL COMMENT 'name',
  `script_locate_host` varchar(100) NOT NULL COMMENT 'script dir',
  `script_dir` varchar(200) NOT NULL COMMENT 'script dir locate',
  `script_description` varchar(200) DEFAULT NULL COMMENT 'description',
  `script_type` varchar(10) DEFAULT NULL COMMENT 'python or bash or perl or xxxxxx',
  `owner` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_script_name` (`script_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbatool_script_list`
--

LOCK TABLES `dbatool_script_list` WRITE;
/*!40000 ALTER TABLE `dbatool_script_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbatool_script_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbserverlist`
--

DROP TABLE IF EXISTS `dbserverlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbserverlist` (
  `DBType` varchar(20) NOT NULL DEFAULT '',
  `Environment` varchar(10) NOT NULL DEFAULT '',
  `AppName` varchar(100) NOT NULL DEFAULT '',
  `mastervip` varchar(20) NOT NULL,
  `HostName` varchar(64) NOT NULL DEFAULT '',
  `IP` varchar(15) NOT NULL DEFAULT '',
  `BackupIP` varchar(15) NOT NULL DEFAULT '',
  `DNS` varchar(4000) NOT NULL DEFAULT '',
  `Port` int(11) NOT NULL DEFAULT '0',
  `CI_Code` varchar(64) NOT NULL DEFAULT '',
  `CheckServer` char(1) NOT NULL DEFAULT '',
  `ServerStatus` varchar(50) NOT NULL DEFAULT '',
  `CheckSlave` char(1) NOT NULL DEFAULT '',
  `SlaveStatus` varchar(50) NOT NULL DEFAULT '',
  `DelayFilterStart` time NOT NULL DEFAULT '00:00:00',
  `DelayFilterEnd` time NOT NULL DEFAULT '00:00:00',
  `CheckPerf` char(1) NOT NULL DEFAULT '',
  `PerfStatus` varchar(50) NOT NULL DEFAULT '',
  `CheckSlowProc` char(1) NOT NULL DEFAULT 'T',
  `SlowProcTime` int(11) NOT NULL DEFAULT '10',
  `SlowProcSendTo` varchar(1000) NOT NULL DEFAULT '',
  `AnalyzeSlowLog` char(1) NOT NULL DEFAULT 'T',
  PRIMARY KEY (`DBType`,`HostName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbserverlist`
--

LOCK TABLES `dbserverlist` WRITE;
/*!40000 ALTER TABLE `dbserverlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbserverlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbservers_dev_test`
--

DROP TABLE IF EXISTS `dbservers_dev_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbservers_dev_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Environment` varchar(10) NOT NULL DEFAULT '',
  `DNS` varchar(4000) NOT NULL DEFAULT '',
  `Port` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbservers_dev_test`
--

LOCK TABLES `dbservers_dev_test` WRITE;
/*!40000 ALTER TABLE `dbservers_dev_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbservers_dev_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbticket_interact_log`
--

DROP TABLE IF EXISTS `dbticket_interact_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbticket_interact_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `DBName` varchar(64) NOT NULL,
  `DBTicketInteractLog` varchar(500) NOT NULL,
  `LogTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `DBName` (`DBName`),
  KEY `appid` (`AppID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbticket_interact_log`
--

LOCK TABLES `dbticket_interact_log` WRITE;
/*!40000 ALTER TABLE `dbticket_interact_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbticket_interact_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ddl_block_checklist`
--

DROP TABLE IF EXISTS `ddl_block_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ddl_block_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(64) DEFAULT NULL,
  `dns` varchar(255) DEFAULT NULL,
  `dns_port` int(11) NOT NULL DEFAULT '55944',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ddl_type` varchar(64) NOT NULL DEFAULT 'add index',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ddl_block_checklist`
--

LOCK TABLES `ddl_block_checklist` WRITE;
/*!40000 ALTER TABLE `ddl_block_checklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `ddl_block_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `del_dbserverlist`
--

DROP TABLE IF EXISTS `del_dbserverlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `del_dbserverlist` (
  `DBType` varchar(20) NOT NULL DEFAULT '',
  `Environment` varchar(10) NOT NULL DEFAULT '',
  `AppName` varchar(100) NOT NULL DEFAULT '',
  `mastervip` varchar(20) NOT NULL,
  `HostName` varchar(64) NOT NULL DEFAULT '',
  `IP` varchar(15) NOT NULL DEFAULT '',
  `BackupIP` varchar(15) NOT NULL DEFAULT '',
  `DNS` varchar(4000) NOT NULL DEFAULT '',
  `Port` int(11) NOT NULL DEFAULT '0',
  `CI_Code` varchar(64) NOT NULL DEFAULT '',
  `CheckServer` char(1) NOT NULL DEFAULT '',
  `ServerStatus` varchar(50) NOT NULL DEFAULT '',
  `CheckSlave` char(1) NOT NULL DEFAULT '',
  `SlaveStatus` varchar(50) NOT NULL DEFAULT '',
  `DelayFilterStart` time NOT NULL DEFAULT '00:00:00',
  `DelayFilterEnd` time NOT NULL DEFAULT '00:00:00',
  `CheckPerf` char(1) NOT NULL DEFAULT '',
  `PerfStatus` varchar(50) NOT NULL DEFAULT '',
  `CheckSlowProc` char(1) NOT NULL DEFAULT 'T',
  `SlowProcTime` int(11) NOT NULL DEFAULT '10',
  `SlowProcSendTo` varchar(1000) NOT NULL DEFAULT '',
  `AnalyzeSlowLog` char(1) NOT NULL DEFAULT 'T',
  PRIMARY KEY (`DBType`,`HostName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `del_dbserverlist`
--

LOCK TABLES `del_dbserverlist` WRITE;
/*!40000 ALTER TABLE `del_dbserverlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `del_dbserverlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dev_test_userinfo`
--

DROP TABLE IF EXISTS `dev_test_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dev_test_userinfo` (
  `user` varchar(16) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `orginfo` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dev_test_userinfo`
--

LOCK TABLES `dev_test_userinfo` WRITE;
/*!40000 ALTER TABLE `dev_test_userinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `dev_test_userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dic_mysql_database`
--

DROP TABLE IF EXISTS `dic_mysql_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_database` (
  `machine_name` varchar(50) NOT NULL,
  `dball` text,
  PRIMARY KEY (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dic_mysql_database`
--

LOCK TABLES `dic_mysql_database` WRITE;
/*!40000 ALTER TABLE `dic_mysql_database` DISABLE KEYS */;
/*!40000 ALTER TABLE `dic_mysql_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dic_mysql_dbsize_growth_rate`
--

DROP TABLE IF EXISTS `dic_mysql_dbsize_growth_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_dbsize_growth_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) NOT NULL,
  `database_name` varchar(128) NOT NULL,
  `database_size(kb)` bigint(20) DEFAULT NULL,
  `database_size_growth_rate` bigint(20) NOT NULL COMMENT '相对于七天前的增长率',
  `data_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_insert_timestamp` (`insert_timestamp`),
  KEY `idx_database_name_insert_timestamp` (`database_name`,`insert_timestamp`),
  KEY `idx_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='只保留最近一天容量及增长率的数据，下次插入前需先清空表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dic_mysql_dbsize_growth_rate`
--

LOCK TABLES `dic_mysql_dbsize_growth_rate` WRITE;
/*!40000 ALTER TABLE `dic_mysql_dbsize_growth_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `dic_mysql_dbsize_growth_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dic_mysql_dns`
--

DROP TABLE IF EXISTS `dic_mysql_dns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dic_mysql_dns` (
  `machine_name` varchar(50) NOT NULL,
  `dnsall` text,
  PRIMARY KEY (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dic_mysql_dns`
--

LOCK TABLES `dic_mysql_dns` WRITE;
/*!40000 ALTER TABLE `dic_mysql_dns` DISABLE KEYS */;
/*!40000 ALTER TABLE `dic_mysql_dns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_6340c63c` (`user_id`),
  KEY `django_admin_log_37ef4eb4` (`content_type_id`),
  CONSTRAINT `content_type_id_refs_id_93d2d1f8` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `user_id_refs_id_c0d12874` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_cas_pgtiou`
--

DROP TABLE IF EXISTS `django_cas_pgtiou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_cas_pgtiou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pgtIou` varchar(255) NOT NULL,
  `tgt` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pgtIou` (`pgtIou`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_cas_pgtiou`
--

LOCK TABLES `django_cas_pgtiou` WRITE;
/*!40000 ALTER TABLE `django_cas_pgtiou` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_cas_pgtiou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_cas_session_service_ticket`
--

DROP TABLE IF EXISTS `django_cas_session_service_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_cas_session_service_ticket` (
  `service_ticket` varchar(255) NOT NULL,
  `session_key` varchar(40) NOT NULL,
  PRIMARY KEY (`service_ticket`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_cas_session_service_ticket`
--

LOCK TABLES `django_cas_session_service_ticket` WRITE;
/*!40000 ALTER TABLE `django_cas_session_service_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_cas_session_service_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_cas_tgt`
--

DROP TABLE IF EXISTS `django_cas_tgt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_cas_tgt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `tgt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_cas_tgt`
--

LOCK TABLES `django_cas_tgt` WRITE;
/*!40000 ALTER TABLE `django_cas_tgt` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_cas_tgt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_c25c2c28` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('10pphga2006yha7l2wzafubo2exqndcc','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-10 15:59:06'),('3w9b6u9qhsi4kd9vyxeh51l0b5dsvna4','MTBlMmNmNmMwNDljMmNmZTRhOTYzNzA5NWVhYTY2NjY2OWQwNDI4MDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKApQAdS4=','2017-12-26 18:22:59'),('58kdr8y3nxk4aiefwnnrhhkpn79wxlbb','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-04 09:44:17'),('9g5sbelkerodp2a0t7na2fm99jwdvxuh','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-30 16:50:05'),('a5udmfnzz9qvn3xfll3buhuclvmx05jd','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-29 14:13:23'),('gtxi7jdbwtynr40qtu729a7505ma4p9z','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2017-12-28 13:53:33'),('i9t3wyatt0glle6hoph3s3slt9b139kb','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-23 09:48:09'),('iszpyqniet2qdng5xtid0cxj652o1o31','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-08 15:37:39'),('l1hi143c78i27aslzleifa8omfy4uqf2','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-12 09:48:53'),('m6cz7bs68jsfn6rog0nas3vqqjcd4j1q','MTBlMmNmNmMwNDljMmNmZTRhOTYzNzA5NWVhYTY2NjY2OWQwNDI4MDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKApQAdS4=','2018-01-03 14:26:16'),('mqfwnpr9v9cdebqhg2x7uqi8ost729t6','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-11 22:21:38'),('p824li5e5vj9lgj88zgs025lm9ue6poo','MTkwNDhkZTNlOWYyOGI2OWYzMjMyODVmZmZiMzQxZTY2NDdiMWIwZTqAAn1xAS4=','2018-01-09 14:04:15'),('qnq395tn03wnlaywwtlcauxop3z3g554','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-17 13:53:33'),('qw9gth8bqjsj77cgz7lynjw51fti8dnn','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-18 09:18:41'),('rmb36p0vbim1wlt9v3uubjskmfy3jb0u','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-31 18:52:14'),('rxt0pd60qf24hdpb1bw55etahpm047if','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-23 14:15:42'),('ryc2sxst11r1w4fllkn4wiiy294b6cja','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-17 16:14:16'),('sr8czkd37xebu4z4zaqviktei2wmvwc7','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2017-12-27 09:29:16'),('u88h7q2j0gnozgs5qhvklhz80ii39sza','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-04 14:27:08'),('ukn76td0s9kc0elco0vovuxfe8dkaff9','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-02-01 10:56:47'),('vh1xf8y8ifmtd8dczf93rguw01ly3tdh','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-23 14:15:48'),('wlv9oy4p0rqncdkqjz46dq4gju1wr4op','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-22 16:23:50'),('y9p5zkij4nvlasck8w6t82xc428a1byx','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-03 18:16:09'),('yuzmt1kb1vkeopqwh7u6jo439sz7ylcp','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-02-02 11:23:28'),('yyz83radl366xcrdmp4sddit2f61f3ii','M2NhZjNhMjI1ODZkNTM0MmU1MmFmOGE3MTZlZWEyMjY4ZmEwY2VmNDqAAn1xAShVEl9hdXRoX3VzZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHEDVQ1fYXV0aF91c2VyX2lkcQSKAo8AdS4=','2018-01-31 10:55:29');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_ddl_dotolist`
--

DROP TABLE IF EXISTS `doevent_ddl_dotolist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_ddl_dotolist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ApplyDetailID` int(11) DEFAULT '0',
  `AppID` int(11) DEFAULT '0',
  `dbname` varchar(100) NOT NULL DEFAULT 'test',
  `host` varchar(100) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT '0',
  `EnvID` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0:wait to do;1:doing;2:success;3:failed',
  `begin_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `change_lasttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `machinename` varchar(100) DEFAULT '',
  `io_result` varchar(20) DEFAULT '',
  `cpu_result` varchar(20) DEFAULT '',
  `datevolumn` varchar(20) DEFAULT '',
  `TABLE_ROWS` varchar(20) DEFAULT '',
  `isread` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_ddl_dotolist`
--

LOCK TABLES `doevent_ddl_dotolist` WRITE;
/*!40000 ALTER TABLE `doevent_ddl_dotolist` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_ddl_dotolist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_ddl_log`
--

DROP TABLE IF EXISTS `doevent_ddl_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_ddl_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `log_content` varchar(2000) DEFAULT '',
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` varchar(100) DEFAULT 'content',
  `from_where` varchar(100) DEFAULT 'old_ddl',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_ddl_log`
--

LOCK TABLES `doevent_ddl_log` WRITE;
/*!40000 ALTER TABLE `doevent_ddl_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_ddl_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_ddl_pre`
--

DROP TABLE IF EXISTS `doevent_ddl_pre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_ddl_pre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `dbname` varchar(100) DEFAULT NULL,
  `host` varchar(150) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `sql_text` varchar(3000) DEFAULT NULL,
  `status` int(11) DEFAULT '0' COMMENT '0-未开始，1-正在执行，2-已经结束',
  `is_success_done` int(11) DEFAULT '0',
  `from_where` int(11) DEFAULT '0' COMMENT '0--来自pt,1--来自直接SQL执行脚本',
  `do_peroson` varchar(300) DEFAULT 'API',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_taskid_dbname_host_sqltext` (`task_id`,`dbname`,`host`,`sql_text`(100)),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_ddl_pre`
--

LOCK TABLES `doevent_ddl_pre` WRITE;
/*!40000 ALTER TABLE `doevent_ddl_pre` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_ddl_pre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_ddl_task`
--

DROP TABLE IF EXISTS `doevent_ddl_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_ddl_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(200) DEFAULT '',
  `use_env` varchar(50) DEFAULT '',
  `sql_text` varchar(5000) DEFAULT '',
  `create_person` varchar(50) DEFAULT 'not_select',
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` varchar(30) DEFAULT '',
  `status` varchar(20) DEFAULT '已提交，未审核',
  `do_person` varchar(50) DEFAULT '',
  `tables` varchar(2000) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_ddl_task`
--

LOCK TABLES `doevent_ddl_task` WRITE;
/*!40000 ALTER TABLE `doevent_ddl_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_ddl_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_dll_log`
--

DROP TABLE IF EXISTS `doevent_dll_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_dll_log` (
  `task_id` int(11) DEFAULT NULL COMMENT '记录doevent_ddl_pre中任务的id',
  `content` varchar(500) DEFAULT NULL,
  `inserttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_dll_log`
--

LOCK TABLES `doevent_dll_log` WRITE;
/*!40000 ALTER TABLE `doevent_dll_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_dll_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_event`
--

DROP TABLE IF EXISTS `doevent_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(300) DEFAULT NULL,
  `content` text,
  `create_person` varchar(100) DEFAULT NULL,
  `handle_person` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `types` varchar(50) DEFAULT NULL,
  `content_hash` varchar(50) DEFAULT '0',
  `subject_hash` varchar(40) DEFAULT '0',
  `time2finish` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_event`
--

LOCK TABLES `doevent_event` WRITE;
/*!40000 ALTER TABLE `doevent_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_event_history`
--

DROP TABLE IF EXISTS `doevent_event_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_event_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(300) DEFAULT NULL,
  `content` text,
  `create_person` varchar(100) DEFAULT NULL,
  `handle_person` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createtime` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `types` varchar(50) DEFAULT NULL,
  `content_hash` varchar(50) DEFAULT '0',
  `subject_hash` varchar(40) DEFAULT '0',
  `time2finish` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`createtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50100 PARTITION BY RANGE (to_days(createtime))
(PARTITION p20150801 VALUES LESS THAN (736207) ENGINE = InnoDB,
 PARTITION p20150901 VALUES LESS THAN (736237) ENGINE = InnoDB,
 PARTITION p20151001 VALUES LESS THAN (736268) ENGINE = InnoDB,
 PARTITION p20151101 VALUES LESS THAN (736298) ENGINE = InnoDB,
 PARTITION p20151201 VALUES LESS THAN (736329) ENGINE = InnoDB,
 PARTITION p20160101 VALUES LESS THAN (736360) ENGINE = InnoDB,
 PARTITION p20160201 VALUES LESS THAN (736389) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_event_history`
--

LOCK TABLES `doevent_event_history` WRITE;
/*!40000 ALTER TABLE `doevent_event_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_event_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_event_project`
--

DROP TABLE IF EXISTS `doevent_event_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_event_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(300) DEFAULT NULL,
  `content` text,
  `create_person` varchar(100) DEFAULT NULL,
  `handle_person` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `types` varchar(50) DEFAULT NULL,
  `content_hash` varchar(50) DEFAULT '0',
  `subject_hash` varchar(40) DEFAULT '0',
  `time2finish` date DEFAULT NULL,
  `onging_process` int(11) DEFAULT '0' COMMENT 'xx%',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_event_project`
--

LOCK TABLES `doevent_event_project` WRITE;
/*!40000 ALTER TABLE `doevent_event_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_event_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_event_project_log`
--

DROP TABLE IF EXISTS `doevent_event_project_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_event_project_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `coneten` varchar(2000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_event_project_log`
--

LOCK TABLES `doevent_event_project_log` WRITE;
/*!40000 ALTER TABLE `doevent_event_project_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_event_project_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_handle_person`
--

DROP TABLE IF EXISTS `doevent_handle_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_handle_person` (
  `name` varchar(100) DEFAULT NULL,
  `name_id` varchar(100) NOT NULL,
  `is_available` int(11) DEFAULT '0',
  `task_number` int(11) DEFAULT '0',
  `data_change` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_handle_person`
--

LOCK TABLES `doevent_handle_person` WRITE;
/*!40000 ALTER TABLE `doevent_handle_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_handle_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_log`
--

DROP TABLE IF EXISTS `doevent_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(400) DEFAULT NULL,
  `person` varchar(50) DEFAULT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_log`
--

LOCK TABLES `doevent_log` WRITE;
/*!40000 ALTER TABLE `doevent_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doevent_type_item`
--

DROP TABLE IF EXISTS `doevent_type_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doevent_type_item` (
  `id` int(11) NOT NULL,
  `item_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doevent_type_item`
--

LOCK TABLES `doevent_type_item` WRITE;
/*!40000 ALTER TABLE `doevent_type_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `doevent_type_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_hostname_pool_list`
--

DROP TABLE IF EXISTS `dr_hostname_pool_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_hostname_pool_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `dr_hostname` varchar(50) NOT NULL COMMENT 'DR节点服务器名',
  `location` varchar(20) NOT NULL DEFAULT '' COMMENT '地域，合法的值为：福泉、金桥、欧阳',
  `switch` tinyint(4) NOT NULL DEFAULT '1' COMMENT '开关状态，0:关闭; 1:开启',
  `security` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否是特殊网段，0:否; 1:是',
  `datachange_lasttime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_dr_hostname` (`dr_hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='DR节点缓存的虚IP列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_hostname_pool_list`
--

LOCK TABLES `dr_hostname_pool_list` WRITE;
/*!40000 ALTER TABLE `dr_hostname_pool_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_hostname_pool_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_install_history`
--

DROP TABLE IF EXISTS `dr_install_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_install_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `cluster_name` varchar(50) NOT NULL DEFAULT '' COMMENT '集群名',
  `dr_hostname` varchar(50) NOT NULL DEFAULT '' COMMENT 'dr节点的hostname',
  `vip` varchar(20) NOT NULL COMMENT '该集群对应的VIP',
  `datachange_lasttime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_install_history`
--

LOCK TABLES `dr_install_history` WRITE;
/*!40000 ALTER TABLE `dr_install_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_install_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_install_progress`
--

DROP TABLE IF EXISTS `dr_install_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_install_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `cluster_name` varchar(50) NOT NULL DEFAULT '' COMMENT '集群名',
  `dr_hostname` varchar(50) NOT NULL DEFAULT '' COMMENT 'dr节点的hostname',
  `vip` varchar(20) NOT NULL COMMENT '该集群对应的VIP',
  `already_installed_step` tinyint(4) NOT NULL DEFAULT '0' COMMENT '已经安装成功的步骤',
  `switch` tinyint(4) NOT NULL DEFAULT '1' COMMENT '开关，1:开启，0:关闭',
  `priority` tinyint(4) NOT NULL DEFAULT '10' COMMENT '优先级，1优先级最高，10最小',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '此次安装的整个状态，有三个合法的值：1:processing; 2:failure 3:success',
  `datachange_lasttime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_cluster_name` (`cluster_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_install_progress`
--

LOCK TABLES `dr_install_progress` WRITE;
/*!40000 ALTER TABLE `dr_install_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_install_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_install_task`
--

DROP TABLE IF EXISTS `dr_install_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_install_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `cluster_name` varchar(50) NOT NULL DEFAULT '' COMMENT '集群名',
  `dr_hostname` varchar(50) NOT NULL DEFAULT '' COMMENT 'dr节点的hostname',
  `switch` tinyint(4) NOT NULL DEFAULT '1' COMMENT '开关，1:开启，0:关闭',
  `priority` tinyint(4) DEFAULT '10' COMMENT '优先级，1优先级最高，10最小',
  `datachange_lasttime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_cluster_name` (`cluster_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_install_task`
--

LOCK TABLES `dr_install_task` WRITE;
/*!40000 ALTER TABLE `dr_install_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_install_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_mha_log`
--

DROP TABLE IF EXISTS `dr_mha_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_mha_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_mha_log`
--

LOCK TABLES `dr_mha_log` WRITE;
/*!40000 ALTER TABLE `dr_mha_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_mha_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dr_vip_pool_list`
--

DROP TABLE IF EXISTS `dr_vip_pool_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dr_vip_pool_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `dr_hostname` varchar(50) NOT NULL COMMENT 'DR节点服务器名',
  `vip` varchar(20) NOT NULL COMMENT '该DR节点缓存的虚IP',
  `switch` tinyint(4) NOT NULL DEFAULT '1' COMMENT '开关状态，0:关闭; 1:开启',
  `datachange_lasttime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uniq_vip` (`vip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='DR节点缓存的虚IP列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dr_vip_pool_list`
--

LOCK TABLES `dr_vip_pool_list` WRITE;
/*!40000 ALTER TABLE `dr_vip_pool_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `dr_vip_pool_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drmonitorswitchlog`
--

DROP TABLE IF EXISTS `drmonitorswitchlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drmonitorswitchlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drswitch_type` varchar(25) DEFAULT NULL,
  `servername` varchar(25) DEFAULT NULL,
  `drswitch_status` char(5) DEFAULT NULL,
  `operator` varchar(20) DEFAULT NULL,
  `Operation_reason` varchar(256) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drmonitorswitchlog`
--

LOCK TABLES `drmonitorswitchlog` WRITE;
/*!40000 ALTER TABLE `drmonitorswitchlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `drmonitorswitchlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `environment_orderid`
--

DROP TABLE IF EXISTS `environment_orderid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `environment_orderid` (
  `Environment` varchar(64) DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `environment_orderid`
--

LOCK TABLES `environment_orderid` WRITE;
/*!40000 ALTER TABLE `environment_orderid` DISABLE KEYS */;
/*!40000 ALTER TABLE `environment_orderid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fulldr_clusterinfo`
--

DROP TABLE IF EXISTS `fulldr_clusterinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fulldr_clusterinfo` (
  `cluster_name` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fulldr_clusterinfo`
--

LOCK TABLES `fulldr_clusterinfo` WRITE;
/*!40000 ALTER TABLE `fulldr_clusterinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fulldr_clusterinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_dbarelease`
--

DROP TABLE IF EXISTS `index_dbarelease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_dbarelease` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbname` varchar(50) DEFAULT NULL,
  `dbsqlscript` varchar(1000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isCreate` int(11) NOT NULL DEFAULT '0',
  `retry_count` tinyint(4) DEFAULT '0',
  `appid` int(11) NOT NULL COMMENT '发布单号',
  PRIMARY KEY (`id`),
  KEY `idx_insert_time` (`insert_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_dbarelease`
--

LOCK TABLES `index_dbarelease` WRITE;
/*!40000 ALTER TABLE `index_dbarelease` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_dbarelease` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_dbarelease_errorlog`
--

DROP TABLE IF EXISTS `index_dbarelease_errorlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_dbarelease_errorlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applyid` bigint(20) DEFAULT NULL,
  `dns` varchar(255) NOT NULL,
  `dbname` varchar(125) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL,
  `env_type` varchar(30) DEFAULT NULL,
  `createindexsql` varchar(1000) DEFAULT NULL,
  `errorinfo` varchar(1000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_dbarelease_errorlog`
--

LOCK TABLES `index_dbarelease_errorlog` WRITE;
/*!40000 ALTER TABLE `index_dbarelease_errorlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_dbarelease_errorlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_dbarelease_log`
--

DROP TABLE IF EXISTS `index_dbarelease_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_dbarelease_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applyid` bigint(20) DEFAULT NULL,
  `dns` varchar(255) NOT NULL,
  `dbname` varchar(125) DEFAULT NULL,
  `machine_name` varchar(128) NOT NULL,
  `env_type` varchar(30) DEFAULT NULL,
  `createindexsql` varchar(1000) DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_dbarelease_log`
--

LOCK TABLES `index_dbarelease_log` WRITE;
/*!40000 ALTER TABLE `index_dbarelease_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_dbarelease_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_machine`
--

DROP TABLE IF EXISTS `install_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_machine` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_father_no` varchar(50) NOT NULL COMMENT 'remedy请求单的父单号',
  `ticket_child_no` varchar(50) NOT NULL COMMENT 'remedy请求单的子单号',
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `ip_business` varchar(45) NOT NULL DEFAULT '',
  `machine_type` varchar(20) NOT NULL COMMENT '物理机或者虚拟机',
  `config_type` varchar(20) NOT NULL COMMENT '配置6、配置11等等',
  `ip_backup` varchar(20) NOT NULL DEFAULT '' COMMENT '备份网段IP地址',
  `install_status` varchar(10) NOT NULL DEFAULT '' COMMENT 'mysql的安装状态：未安装-正在进行-安装成功',
  `install_begin_step` varchar(1) NOT NULL DEFAULT '' COMMENT '记录mysql成功安装到第几步：1，2，3，4',
  `install_success_time` datetime DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_id`),
  UNIQUE KEY `idx_machine_name` (`machine_name`),
  UNIQUE KEY `idx_ip_business` (`ip_business`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_machine`
--

LOCK TABLES `install_machine` WRITE;
/*!40000 ALTER TABLE `install_machine` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_machine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_machine_history`
--

DROP TABLE IF EXISTS `install_machine_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_machine_history` (
  `machine_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_father_no` varchar(50) NOT NULL COMMENT 'remedy请求单的父单号',
  `ticket_child_no` varchar(50) NOT NULL COMMENT 'remedy请求单的子单号',
  `machine_name` varchar(128) NOT NULL DEFAULT '',
  `ip_business` varchar(45) NOT NULL DEFAULT '',
  `machine_type` varchar(20) NOT NULL COMMENT '物理机或者虚拟机',
  `config_type` varchar(20) NOT NULL COMMENT '配置6、配置11等等',
  `backup_ip` varchar(20) NOT NULL COMMENT '备份网段IP地址',
  `install_status` varchar(10) NOT NULL DEFAULT '' COMMENT 'mysql的安装状态：未安装-正在进行-安装成功',
  `mysql_install_step` varchar(1) NOT NULL DEFAULT '' COMMENT '记录mysql成功安装到第几步：0，1，2，3，4',
  `install_success_time` datetime DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_machine_history`
--

LOCK TABLES `install_machine_history` WRITE;
/*!40000 ALTER TABLE `install_machine_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_machine_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_mysql_cluster`
--

DROP TABLE IF EXISTS `install_mysql_cluster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_mysql_cluster` (
  `cluster_name` varchar(128) NOT NULL DEFAULT '',
  `cluster_vip` varchar(20) NOT NULL DEFAULT '',
  `machine_name` varchar(20) NOT NULL DEFAULT '',
  `ip_business` varchar(45) NOT NULL DEFAULT '',
  `role` varchar(10) NOT NULL DEFAULT '',
  `repl_install_status` varchar(10) NOT NULL DEFAULT '' COMMENT '主从复制配置状态',
  `repl_success_time` datetime DEFAULT NULL,
  `cluster_install_status` varchar(10) NOT NULL DEFAULT '' COMMENT '集群配置状态',
  `cluster_success_time` datetime DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`),
  UNIQUE KEY `idx_ip_business` (`ip_business`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_cluster_vip` (`cluster_vip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_mysql_cluster`
--

LOCK TABLES `install_mysql_cluster` WRITE;
/*!40000 ALTER TABLE `install_mysql_cluster` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_mysql_cluster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_mysql_cluster_history`
--

DROP TABLE IF EXISTS `install_mysql_cluster_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_mysql_cluster_history` (
  `cluster_name` varchar(128) NOT NULL DEFAULT '',
  `cluster_vip` varchar(20) NOT NULL DEFAULT '',
  `machine_name` varchar(20) NOT NULL DEFAULT '',
  `ip_business` varchar(45) NOT NULL DEFAULT '',
  `role` varchar(10) NOT NULL DEFAULT '',
  `repl_install_status` varchar(10) NOT NULL DEFAULT '' COMMENT '主从复制配置状态',
  `repl_success_time` datetime DEFAULT NULL,
  `cluster_install_status` varchar(10) NOT NULL DEFAULT '' COMMENT '集群配置状态',
  `cluster_success_time` datetime DEFAULT NULL,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`machine_name`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_cluster_vip` (`cluster_vip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_mysql_cluster_history`
--

LOCK TABLES `install_mysql_cluster_history` WRITE;
/*!40000 ALTER TABLE `install_mysql_cluster_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_mysql_cluster_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `install_mysql_status`
--

DROP TABLE IF EXISTS `install_mysql_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `install_mysql_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(50) DEFAULT NULL,
  `addpubkey` timestamp NULL DEFAULT NULL,
  `servercheck` timestamp NULL DEFAULT NULL,
  `addpartition` timestamp NULL DEFAULT NULL,
  `confbeforesetup` timestamp NULL DEFAULT NULL,
  `mysqlsetup` timestamp NULL DEFAULT NULL,
  `confaftersetup` timestamp NULL DEFAULT NULL,
  `softsetup` timestamp NULL DEFAULT NULL,
  `autosetupconf` timestamp NULL DEFAULT NULL,
  `finishrestart` timestamp NULL DEFAULT NULL,
  `isfail` int(11) DEFAULT NULL COMMENT '1-failure; 2-success',
  `endtime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `install_mysql_status`
--

LOCK TABLES `install_mysql_status` WRITE;
/*!40000 ALTER TABLE `install_mysql_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `install_mysql_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mhamanagerlist`
--

DROP TABLE IF EXISTS `mhamanagerlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mhamanagerlist` (
  `hostname` varchar(30) NOT NULL,
  `dns` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL,
  `monitor_status` char(1) DEFAULT 'T',
  `mhamanager_id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(10) NOT NULL DEFAULT '' COMMENT '管理节点位置',
  `same_idc_needed` int(11) DEFAULT '0',
  `is_display` int(11) DEFAULT '1' COMMENT '是否在集群管理页面显示',
  `basenode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mhamanager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mhamanagerlist`
--

LOCK TABLES `mhamanagerlist` WRITE;
/*!40000 ALTER TABLE `mhamanagerlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `mhamanagerlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mongodb_serverstatus`
--

DROP TABLE IF EXISTS `mongodb_serverstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mongodb_serverstatus` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mongodb_serverstatus`
--

LOCK TABLES `mongodb_serverstatus` WRITE;
/*!40000 ALTER TABLE `mongodb_serverstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `mongodb_serverstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mongodb_serverstatus_swap`
--

DROP TABLE IF EXISTS `mongodb_serverstatus_swap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mongodb_serverstatus_swap` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mongodb_serverstatus_swap`
--

LOCK TABLES `mongodb_serverstatus_swap` WRITE;
/*!40000 ALTER TABLE `mongodb_serverstatus_swap` DISABLE KEYS */;
/*!40000 ALTER TABLE `mongodb_serverstatus_swap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mongodb_serverstatus_test`
--

DROP TABLE IF EXISTS `mongodb_serverstatus_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mongodb_serverstatus_test` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`hostname`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mongodb_serverstatus_test`
--

LOCK TABLES `mongodb_serverstatus_test` WRITE;
/*!40000 ALTER TABLE `mongodb_serverstatus_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `mongodb_serverstatus_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mongodb_serverstatus_test_swap`
--

DROP TABLE IF EXISTS `mongodb_serverstatus_test_swap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mongodb_serverstatus_test_swap` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`hostname`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mongodb_serverstatus_test_swap`
--

LOCK TABLES `mongodb_serverstatus_test_swap` WRITE;
/*!40000 ALTER TABLE `mongodb_serverstatus_test_swap` DISABLE KEYS */;
/*!40000 ALTER TABLE `mongodb_serverstatus_test_swap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_action`
--

DROP TABLE IF EXISTS `mysql_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_action` (
  `actionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL DEFAULT '' COMMENT '操作描述',
  PRIMARY KEY (`actionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_action`
--

LOCK TABLES `mysql_action` WRITE;
/*!40000 ALTER TABLE `mysql_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_action_log`
--

DROP TABLE IF EXISTS `mysql_action_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_action_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `actionid` int(11) NOT NULL,
  `web_user` varchar(50) NOT NULL DEFAULT '',
  `interface` varchar(200) NOT NULL DEFAULT '',
  `content` varchar(5000) NOT NULL DEFAULT '',
  `datachange_createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `host` varchar(20) NOT NULL DEFAULT '',
  `extendcontent` varchar(2000) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_action_log`
--

LOCK TABLES `mysql_action_log` WRITE;
/*!40000 ALTER TABLE `mysql_action_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_action_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_add_special`
--

DROP TABLE IF EXISTS `mysql_add_special`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_add_special` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asked_name` varchar(64) NOT NULL,
  `asked_num` varchar(64) NOT NULL,
  `approver_name` varchar(64) NOT NULL,
  `approver_num` varchar(64) NOT NULL,
  `special_select_dblist` varchar(2000) NOT NULL,
  `modify_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approver_email` varchar(68) NOT NULL,
  `approve_status` int(11) NOT NULL DEFAULT '0',
  `user` varchar(64) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `host` varchar(128) NOT NULL,
  `port` int(11) NOT NULL,
  `asked_email` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_add_special`
--

LOCK TABLES `mysql_add_special` WRITE;
/*!40000 ALTER TABLE `mysql_add_special` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_add_special` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_api_log`
--

DROP TABLE IF EXISTS `mysql_api_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_api_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `interface` varchar(200) NOT NULL DEFAULT '',
  `content` varchar(2000) NOT NULL DEFAULT '',
  `datachange_createtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `host` varchar(20) NOT NULL DEFAULT '',
  `extendcontent` varchar(2000) DEFAULT '',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_api_log`
--

LOCK TABLES `mysql_api_log` WRITE;
/*!40000 ALTER TABLE `mysql_api_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_api_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_data_tablespace_growth_rate`
--

DROP TABLE IF EXISTS `mysql_data_tablespace_growth_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_data_tablespace_growth_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) NOT NULL,
  `database_name` varchar(128) NOT NULL,
  `table_name` varchar(128) NOT NULL,
  `data_clear` tinyint(4) NOT NULL COMMENT '是否配置数据清理',
  `data_clear_days` varchar(20) DEFAULT NULL COMMENT '清理保留天数',
  `row_count` bigint(20) NOT NULL,
  `row_count_growth_rate` bigint(20) NOT NULL COMMENT '表行数相对于七天前的增长率',
  `reserved_kb` bigint(20) NOT NULL,
  `reserved_kb_growth_rate` bigint(20) NOT NULL COMMENT '表大小相对于七天前的增长率',
  `data_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `insert_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='仅保留最近一天的容量和增长率等数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_data_tablespace_growth_rate`
--

LOCK TABLES `mysql_data_tablespace_growth_rate` WRITE;
/*!40000 ALTER TABLE `mysql_data_tablespace_growth_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_data_tablespace_growth_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_disaster_bakpools`
--

DROP TABLE IF EXISTS `mysql_disaster_bakpools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_disaster_bakpools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `machine_local` varchar(56) DEFAULT NULL,
  `clustercounts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_machine_name` (`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_disaster_bakpools`
--

LOCK TABLES `mysql_disaster_bakpools` WRITE;
/*!40000 ALTER TABLE `mysql_disaster_bakpools` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_disaster_bakpools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_disaster_recovery`
--

DROP TABLE IF EXISTS `mysql_disaster_recovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_disaster_recovery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_host` varchar(64) DEFAULT NULL,
  `service_name` varchar(64) DEFAULT NULL,
  `service_ip` varchar(20) DEFAULT NULL,
  `service_port` int(11) DEFAULT NULL,
  `server_status` char(10) DEFAULT NULL,
  `slave_status` char(10) DEFAULT NULL,
  `masterhost_monitorswitch` char(1) DEFAULT 'T',
  `dr_monitorswitch` char(1) DEFAULT 'T',
  `DataChange_LastTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_disaster_recovery`
--

LOCK TABLES `mysql_disaster_recovery` WRITE;
/*!40000 ALTER TABLE `mysql_disaster_recovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_disaster_recovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_serverstatus`
--

DROP TABLE IF EXISTS `mysql_serverstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_serverstatus` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `Approle` varchar(20) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `mysqlversion` varchar(20) NOT NULL DEFAULT '',
  `located` varchar(30) DEFAULT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DBType`,`hostname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_serverstatus`
--

LOCK TABLES `mysql_serverstatus` WRITE;
/*!40000 ALTER TABLE `mysql_serverstatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_serverstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_serverstatus_swap`
--

DROP TABLE IF EXISTS `mysql_serverstatus_swap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_serverstatus_swap` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `Approle` varchar(20) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `mysqlversion` varchar(20) NOT NULL DEFAULT '',
  `located` varchar(30) DEFAULT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DBType`,`hostname`),
  KEY `idx_AppName` (`AppName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_serverstatus_swap`
--

LOCK TABLES `mysql_serverstatus_swap` WRITE;
/*!40000 ALTER TABLE `mysql_serverstatus_swap` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_serverstatus_swap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_serverstatus_test`
--

DROP TABLE IF EXISTS `mysql_serverstatus_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_serverstatus_test` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `Approle` varchar(20) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DBType`,`hostname`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_serverstatus_test`
--

LOCK TABLES `mysql_serverstatus_test` WRITE;
/*!40000 ALTER TABLE `mysql_serverstatus_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_serverstatus_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysql_serverstatus_test_swap`
--

DROP TABLE IF EXISTS `mysql_serverstatus_test_swap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysql_serverstatus_test_swap` (
  `DBType` varchar(20) NOT NULL,
  `Environment` varchar(20) NOT NULL,
  `AppName` varchar(100) NOT NULL,
  `Approle` varchar(20) NOT NULL,
  `hostname` varchar(64) NOT NULL,
  `ServerStatus` varchar(50) NOT NULL,
  `SlaveStatus` varchar(50) NOT NULL,
  `Inserttime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DBType`,`hostname`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysql_serverstatus_test_swap`
--

LOCK TABLES `mysql_serverstatus_test_swap` WRITE;
/*!40000 ALTER TABLE `mysql_serverstatus_test_swap` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysql_serverstatus_test_swap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mysqlevent`
--

DROP TABLE IF EXISTS `mysqlevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mysqlevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dbName` varchar(30) DEFAULT NULL,
  `tableName` varchar(30) DEFAULT NULL,
  `environment` varchar(50) DEFAULT NULL,
  `eventType` int(11) DEFAULT NULL,
  `sql_name` varchar(2000) DEFAULT NULL,
  `handle_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mysqlevent`
--

LOCK TABLES `mysqlevent` WRITE;
/*!40000 ALTER TABLE `mysqlevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `mysqlevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodr_clusterinfowhitelist`
--

DROP TABLE IF EXISTS `nodr_clusterinfowhitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodr_clusterinfowhitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(125) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodr_clusterinfowhitelist`
--

LOCK TABLES `nodr_clusterinfowhitelist` WRITE;
/*!40000 ALTER TABLE `nodr_clusterinfowhitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `nodr_clusterinfowhitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_ddl_sql`
--

DROP TABLE IF EXISTS `online_ddl_sql`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_ddl_sql` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) DEFAULT NULL,
  `host` varchar(50) DEFAULT NULL,
  `db` varchar(20) DEFAULT NULL,
  `tableName` varchar(50) DEFAULT NULL,
  `pt_sql` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_ddl_sql`
--

LOCK TABLES `online_ddl_sql` WRITE;
/*!40000 ALTER TABLE `online_ddl_sql` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_ddl_sql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_dbconfig`
--

DROP TABLE IF EXISTS `release_dbconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_dbconfig` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `Upload_DBName` varchar(64) NOT NULL,
  `Active` enum('0','1') NOT NULL,
  `EnvID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_dbconfig`
--

LOCK TABLES `release_dbconfig` WRITE;
/*!40000 ALTER TABLE `release_dbconfig` DISABLE KEYS */;
INSERT INTO `release_dbconfig` VALUES (39,'test_partition','192.168.175.130',3306,'test_partition','1',4),(40,'conn','192.168.175.130',3306,'conn','1',4),(41,'heiheihei','192.168.175.130',3306,'heiheihei','1',4);
/*!40000 ALTER TABLE `release_dbconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_dbconfig_20171215`
--

DROP TABLE IF EXISTS `release_dbconfig_20171215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_dbconfig_20171215` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `Upload_DBName` varchar(64) NOT NULL,
  `Active` enum('0','1') NOT NULL,
  `EnvID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_dbconfig_20171215`
--

LOCK TABLES `release_dbconfig_20171215` WRITE;
/*!40000 ALTER TABLE `release_dbconfig_20171215` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_dbconfig_20171215` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_environmentcfg`
--

DROP TABLE IF EXISTS `release_environmentcfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_environmentcfg` (
  `ID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Release_Level` varchar(30) NOT NULL,
  `LevelID` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_environmentcfg`
--

LOCK TABLES `release_environmentcfg` WRITE;
/*!40000 ALTER TABLE `release_environmentcfg` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_environmentcfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_froze`
--

DROP TABLE IF EXISTS `release_froze`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_froze` (
  `isfroze` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_froze`
--

LOCK TABLES `release_froze` WRITE;
/*!40000 ALTER TABLE `release_froze` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_froze` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_uploadapply`
--

DROP TABLE IF EXISTS `release_uploadapply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_uploadapply` (
  `AppID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `Status` varchar(50) NOT NULL DEFAULT '',
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(30) NOT NULL,
  `LastModifiedDate` datetime DEFAULT NULL,
  `LastModifiedBy` varchar(30) DEFAULT NULL,
  `SubmittedDate` datetime DEFAULT NULL,
  `SubmittedBy` varchar(30) DEFAULT NULL,
  `LastUploadError` text,
  `UploadTestDate` datetime DEFAULT NULL,
  `UploadTestBy` varchar(30) DEFAULT NULL,
  `UploadUATDate` datetime DEFAULT NULL,
  `UploadUATBy` varchar(30) DEFAULT NULL,
  `UploadProductDate` datetime DEFAULT NULL,
  `UploadProductBy` varchar(30) DEFAULT NULL,
  `approvedby` varchar(100) DEFAULT '' COMMENT 'PD  suggest the approved person',
  `testpass` int(11) DEFAULT '1' COMMENT '1:上传发布测试通过，0:上传发布测试不通过',
  `taskid` int(11) DEFAULT NULL,
  PRIMARY KEY (`AppID`),
  UNIQUE KEY `idx_taskid` (`taskid`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_uploadapply`
--

LOCK TABLES `release_uploadapply` WRITE;
/*!40000 ALTER TABLE `release_uploadapply` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_uploadapply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_uploadapplydetail`
--

DROP TABLE IF EXISTS `release_uploadapplydetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_uploadapplydetail` (
  `ApplyDetailID` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `ObjName` varchar(128) DEFAULT NULL,
  `DBSqlScript` text,
  `DBSqlOperation` varchar(20) DEFAULT NULL,
  `ColName` varchar(128) DEFAULT NULL,
  `ColType` varchar(20) DEFAULT NULL,
  `IdxName` varchar(512) DEFAULT NULL,
  `IdxType` varchar(20) DEFAULT NULL,
  `task_type` int(11) DEFAULT '1' COMMENT '2:表示已经生成具体的执行环境,0:默认不选,1:等待DBA操作',
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `process` varchar(100) DEFAULT '未开始',
  PRIMARY KEY (`ApplyDetailID`),
  KEY `idx_appid` (`AppID`),
  KEY `idx_task_type_ApplyDetailID` (`task_type`,`ApplyDetailID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_uploadapplydetail`
--

LOCK TABLES `release_uploadapplydetail` WRITE;
/*!40000 ALTER TABLE `release_uploadapplydetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_uploadapplydetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `release_uploadapplylog`
--

DROP TABLE IF EXISTS `release_uploadapplylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_uploadapplylog` (
  `LogID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AppID` int(11) NOT NULL,
  `EnvID` int(11) NOT NULL,
  `UploadHost` varchar(200) NOT NULL DEFAULT '',
  `LogDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UploadBy` varchar(30) NOT NULL DEFAULT '',
  `Result` varchar(2000) NOT NULL DEFAULT '',
  PRIMARY KEY (`LogID`),
  KEY `idx_appid` (`AppID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `release_uploadapplylog`
--

LOCK TABLES `release_uploadapplylog` WRITE;
/*!40000 ALTER TABLE `release_uploadapplylog` DISABLE KEYS */;
/*!40000 ALTER TABLE `release_uploadapplylog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_datadr`
--

DROP TABLE IF EXISTS `restore_datadr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restore_datadr` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cluster_name` varchar(100) NOT NULL COMMENT '集群名称',
  `dr_hostname` varchar(20) NOT NULL COMMENT '数据容灾服务器的主机名',
  `dr_vip` varchar(20) NOT NULL COMMENT '数据容灾实例的虚ip',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '当前集群的状态，0表示还未开始，1表示进行中，2表示已修复',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cluster_name` (`cluster_name`),
  UNIQUE KEY `idx_dr_vip` (`dr_vip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_datadr`
--

LOCK TABLES `restore_datadr` WRITE;
/*!40000 ALTER TABLE `restore_datadr` DISABLE KEYS */;
/*!40000 ALTER TABLE `restore_datadr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_read_or_full_capacity_dr_log`
--

DROP TABLE IF EXISTS `restore_read_or_full_capacity_dr_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restore_read_or_full_capacity_dr_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recovery_ip` varchar(50) NOT NULL,
  `step` varchar(50) NOT NULL,
  `log_content` varchar(2000) DEFAULT '',
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_read_or_full_capacity_dr_log`
--

LOCK TABLES `restore_read_or_full_capacity_dr_log` WRITE;
/*!40000 ALTER TABLE `restore_read_or_full_capacity_dr_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `restore_read_or_full_capacity_dr_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_config`
--

DROP TABLE IF EXISTS `review_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(50) DEFAULT NULL COMMENT '机房名称',
  `host` varchar(45) NOT NULL COMMENT '主机域名',
  `machine_name` varchar(50) DEFAULT NULL COMMENT '机器名称',
  `port` mediumint(9) NOT NULL COMMENT '主机端口',
  `backup_type` enum('lvm','xtrabackup') NOT NULL,
  `cnf_database` varchar(20) NOT NULL COMMENT '存放还原配置表的库',
  `cnf_table` varchar(45) NOT NULL COMMENT '存放还原配置的表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用于MySQL Review的主机和相关库表的配置信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_config`
--

LOCK TABLES `review_config` WRITE;
/*!40000 ALTER TABLE `review_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_config_test`
--

DROP TABLE IF EXISTS `review_config_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_config_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(50) DEFAULT NULL COMMENT '机房名称',
  `host` varchar(45) NOT NULL COMMENT '主机域名',
  `machine_name` varchar(50) DEFAULT NULL COMMENT '机器名称',
  `port` mediumint(9) NOT NULL COMMENT '主机端口',
  `backup_type` enum('lvm','xtrabackup') NOT NULL,
  `cnf_database` varchar(20) NOT NULL COMMENT '存放还原配置表的库',
  `cnf_table` varchar(45) NOT NULL COMMENT '存放还原配置的表',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用于MySQL Review的主机和相关库表的配置信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_config_test`
--

LOCK TABLES `review_config_test` WRITE;
/*!40000 ALTER TABLE `review_config_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_config_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salt_verify_hostname`
--

DROP TABLE IF EXISTS `salt_verify_hostname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salt_verify_hostname` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_id` int(11) DEFAULT NULL,
  `web_ip` varchar(50) DEFAULT NULL,
  `shortci` varchar(100) DEFAULT NULL,
  `targetip` varchar(100) DEFAULT '',
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `jid` varchar(50) DEFAULT '',
  `reuslt` varchar(200) DEFAULT '',
  `status` varchar(20) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salt_verify_hostname`
--

LOCK TABLES `salt_verify_hostname` WRITE;
/*!40000 ALTER TABLE `salt_verify_hostname` DISABLE KEYS */;
/*!40000 ALTER TABLE `salt_verify_hostname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salt_verify_request`
--

DROP TABLE IF EXISTS `salt_verify_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salt_verify_request` (
  `batch_id` int(11) DEFAULT NULL,
  `service_name` varchar(128) DEFAULT NULL,
  `target_ip` varchar(30) DEFAULT NULL,
  `target_port` int(11) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salt_verify_request`
--

LOCK TABLES `salt_verify_request` WRITE;
/*!40000 ALTER TABLE `salt_verify_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `salt_verify_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salt_verify_result`
--

DROP TABLE IF EXISTS `salt_verify_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salt_verify_result` (
  `batch_id` int(11) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT 'none',
  `shortci` varchar(255) DEFAULT 'none',
  `target_ip` varchar(255) DEFAULT NULL,
  `target_port` int(11) DEFAULT NULL,
  `result` varchar(1000) DEFAULT NULL,
  `insert_time` datetime DEFAULT NULL,
  `shortci_os` varchar(128) DEFAULT 'none',
  `web_ip` varchar(128) DEFAULT NULL,
  `isdone` int(1) NOT NULL DEFAULT '0',
  KEY `idx_batchid` (`batch_id`),
  KEY `idx_batchid_ci` (`batch_id`,`shortci`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salt_verify_result`
--

LOCK TABLES `salt_verify_result` WRITE;
/*!40000 ALTER TABLE `salt_verify_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `salt_verify_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `senmsg_rule`
--

DROP TABLE IF EXISTS `senmsg_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `senmsg_rule` (
  `hostname` varchar(128) DEFAULT NULL,
  `objectname` varchar(255) DEFAULT NULL,
  `inserttime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `senmsg_rule`
--

LOCK TABLES `senmsg_rule` WRITE;
/*!40000 ALTER TABLE `senmsg_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `senmsg_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_config_type_info`
--

DROP TABLE IF EXISTS `server_config_type_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_config_type_info` (
  `config_type` varchar(20) NOT NULL COMMENT '配置6、配置11等等',
  `cpu_num` varchar(10) NOT NULL COMMENT 'CPU核数',
  `memory` varchar(10) NOT NULL COMMENT '内存大小,单位G',
  `disk_compacity` varchar(10) NOT NULL COMMENT '数据盘容量,单位G',
  `network_card_num` varchar(10) NOT NULL COMMENT '网卡数量',
  PRIMARY KEY (`config_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_config_type_info`
--

LOCK TABLES `server_config_type_info` WRITE;
/*!40000 ALTER TABLE `server_config_type_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_config_type_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slavednsswitch_whitename`
--

DROP TABLE IF EXISTS `slavednsswitch_whitename`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slavednsswitch_whitename` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(50) DEFAULT NULL,
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cluster_name` (`cluster_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slavednsswitch_whitename`
--

LOCK TABLES `slavednsswitch_whitename` WRITE;
/*!40000 ALTER TABLE `slavednsswitch_whitename` DISABLE KEYS */;
/*!40000 ALTER TABLE `slavednsswitch_whitename` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlreview_apply`
--

DROP TABLE IF EXISTS `sqlreview_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlreview_apply` (
  `apply_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '申请单号',
  `db_id` int(10) unsigned NOT NULL COMMENT '数据库ID',
  `db_name` varchar(64) NOT NULL COMMENT '数据库名',
  `apply_by` varchar(30) NOT NULL COMMENT '申请者',
  `apply_date` datetime NOT NULL COMMENT '申请时间',
  `modify_date` datetime NOT NULL COMMENT '最后修改时间',
  `check_date` datetime NOT NULL COMMENT '审核完成时间',
  `status` enum('待审核','审核通过','审核未通过') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`apply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='SQL审核申请表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlreview_apply`
--

LOCK TABLES `sqlreview_apply` WRITE;
/*!40000 ALTER TABLE `sqlreview_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqlreview_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlreview_apply_detail`
--

DROP TABLE IF EXISTS `sqlreview_apply_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlreview_apply_detail` (
  `detail_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '明细号',
  `apply_id` int(10) unsigned NOT NULL COMMENT '申请单号',
  `sql` text NOT NULL COMMENT 'sql语句',
  `frequency` enum('1','2','3','4','5','6') NOT NULL DEFAULT '1' COMMENT '语句执行频次',
  `apply_date` datetime NOT NULL COMMENT '申请时间',
  `modify_date` datetime NOT NULL COMMENT '最后修改时间',
  `check_date` datetime NOT NULL COMMENT '审核时间',
  `status` enum('待审核','审核通过','审核未通过') NOT NULL DEFAULT '待审核' COMMENT '审核状态',
  `specification_result` text NOT NULL COMMENT '规范审核结果',
  `timeout` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT 'SQL语句运行是否超时',
  `sql_error_or_warning` text NOT NULL COMMENT 'SQL语句语法错误或包含的警告',
  `time` decimal(4,2) NOT NULL DEFAULT '0.00' COMMENT 'SQL语句实际运行时间',
  `rows` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '实际影响行数',
  `execute_plan` text NOT NULL COMMENT 'SQL语句执行计划',
  `not_using_index` text NOT NULL COMMENT '未使用索引的情况',
  `excessive_scan_rows` text NOT NULL COMMENT '过多的扫描行数',
  `filesort_or_using_temporary` text NOT NULL COMMENT '使用文件排序或临时表的情况',
  `extra` varchar(250) NOT NULL DEFAULT '' COMMENT '额外信息',
  PRIMARY KEY (`detail_id`),
  KEY `apply_id` (`apply_id`),
  CONSTRAINT `apply_id` FOREIGN KEY (`apply_id`) REFERENCES `sqlreview_apply` (`apply_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='SQL审核明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlreview_apply_detail`
--

LOCK TABLES `sqlreview_apply_detail` WRITE;
/*!40000 ALTER TABLE `sqlreview_apply_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqlreview_apply_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlreview_freq_rule`
--

DROP TABLE IF EXISTS `sqlreview_freq_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlreview_freq_rule` (
  `id` tinyint(3) unsigned NOT NULL COMMENT 'ID',
  `frequency` varchar(25) NOT NULL COMMENT '语句执行频率',
  `join` tinyint(3) unsigned NOT NULL COMMENT '允许的JOIN数目',
  `time` varchar(5) NOT NULL COMMENT '允许的运行时长',
  `rows` int(10) unsigned NOT NULL COMMENT '预估扫描行数',
  `filesort_temporary` enum('Y','N') NOT NULL COMMENT '是否允许filesort或using temporary',
  PRIMARY KEY (`id`),
  UNIQUE KEY `frequency_UNIQUE` (`frequency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='SQL审核中SQL语句执行频率及对应的审核规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlreview_freq_rule`
--

LOCK TABLES `sqlreview_freq_rule` WRITE;
/*!40000 ALTER TABLE `sqlreview_freq_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqlreview_freq_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlreview_white_list`
--

DROP TABLE IF EXISTS `sqlreview_white_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlreview_white_list` (
  `dbname` varchar(64) NOT NULL COMMENT '数据库名',
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`dbname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlreview_white_list`
--

LOCK TABLES `sqlreview_white_list` WRITE;
/*!40000 ALTER TABLE `sqlreview_white_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqlreview_white_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_db_conninfo`
--

DROP TABLE IF EXISTS `sqltools_db_conninfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_db_conninfo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dbid` int(11) DEFAULT NULL,
  `DBName` varchar(64) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `dbuser` varchar(32) DEFAULT NULL,
  `type` varchar(32) DEFAULT 'R' COMMENT '类型: R: 只读; W:  写入',
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_db_conninfo`
--

LOCK TABLES `sqltools_db_conninfo` WRITE;
/*!40000 ALTER TABLE `sqltools_db_conninfo` DISABLE KEYS */;
INSERT INTO `sqltools_db_conninfo` VALUES (68,39,'test_partition','192.168.175.130',3306,'default_user','W'),(69,39,'test_partition','192.168.175.130',3306,'default_user','R'),(70,40,'conn','192.168.175.130',3306,'default_user','W'),(71,40,'conn','192.168.175.130',3306,'default_user','R'),(72,41,'heiheihei','192.168.175.130',3306,'default_user','W'),(73,41,'heiheihei','192.168.175.130',3306,'default_user','R');
/*!40000 ALTER TABLE `sqltools_db_conninfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_db_conninfo_20171215`
--

DROP TABLE IF EXISTS `sqltools_db_conninfo_20171215`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_db_conninfo_20171215` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dbid` int(11) DEFAULT NULL,
  `DBName` varchar(64) NOT NULL,
  `Host` varchar(200) NOT NULL,
  `Port` int(11) NOT NULL,
  `dbuser` varchar(32) DEFAULT NULL,
  `type` varchar(32) DEFAULT 'R' COMMENT '类型: R: 只读; W:  写入',
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`DBName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_db_conninfo_20171215`
--

LOCK TABLES `sqltools_db_conninfo_20171215` WRITE;
/*!40000 ALTER TABLE `sqltools_db_conninfo_20171215` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqltools_db_conninfo_20171215` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_selectsql_list`
--

DROP TABLE IF EXISTS `sqltools_selectsql_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_selectsql_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `username` varchar(100) NOT NULL,
  `sql` longtext COMMENT '提交的 sql',
  `status` int(11) DEFAULT '0' COMMENT '状态:0 待审批； 1: 审批通过; 2： 审批未通过; 3: 执行中; 4: 执行完成；5：执行失败',
  `retmsg` text COMMENT '执行返回信息',
  `backinfo` text COMMENT '备份信息',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`ID`),
  KEY `idx_username` (`username`),
  KEY `idx_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `idx_DataChange_CreateTime` (`DataChange_CreateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_selectsql_list`
--

LOCK TABLES `sqltools_selectsql_list` WRITE;
/*!40000 ALTER TABLE `sqltools_selectsql_list` DISABLE KEYS */;
INSERT INTO `sqltools_selectsql_list` VALUES (1,'test_partition','admin','select * from a;',1,'',NULL,'2018-01-22 16:40:00','2018-01-23 07:30:53'),(2,'conn','admin','select * from name;',1,'',NULL,'2018-01-29 14:21:10','2018-01-29 06:21:18'),(3,'test_partition','admin','select * from test;',1,'',NULL,'2018-01-29 14:27:37','2018-01-29 07:12:36'),(4,'conn','admin','select * from name;',4,'',NULL,'2018-01-29 15:40:37','2018-01-31 11:10:11'),(5,'test_partition','admin','select * from a;',1,'',NULL,'2018-01-29 17:37:11','2018-01-29 09:37:18'),(6,'test_partition','admin','select * from das;',1,'',NULL,'2018-01-30 16:53:45','2018-01-30 08:53:52'),(7,'test_partition','admin','select * from b;\r\nselect * from c;',1,'',NULL,'2018-01-30 16:55:03','2018-01-30 08:55:11'),(8,'conn','admin','select * from b;\r\nselect * from c;',1,'',NULL,'2018-01-30 16:56:24','2018-01-30 09:13:58'),(9,'test_partition','admin','select * from b;',1,'',NULL,'2018-01-30 17:13:20','2018-01-30 09:14:08'),(10,'test_partition','admin','select * from das;',4,'',NULL,'2018-01-30 18:17:36','2018-02-01 02:57:02'),(11,'conn','admin','select * from name;',4,'',NULL,'2018-01-30 18:21:35','2018-01-31 11:09:44'),(12,'heiheihei','admin','select * from yhops_user;',4,'',NULL,'2018-01-31 10:59:50','2018-01-31 11:03:10'),(13,'test_partition','admin','select * from aads;',4,'',NULL,'2018-01-31 13:58:49','2018-02-01 02:56:54'),(14,'conn','admin','select * from a;',4,'',NULL,'2018-01-31 17:50:47','2018-01-31 11:09:54'),(15,'39','test01','select * from name;',1,'',NULL,'2018-02-02 09:59:47','2018-02-02 03:23:42');
/*!40000 ALTER TABLE `sqltools_selectsql_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_top_fields`
--

DROP TABLE IF EXISTS `sqltools_top_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_top_fields` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dbid` int(11) DEFAULT NULL,
  `DBName` varchar(64) NOT NULL,
  `tablename` varchar(200) NOT NULL,
  `fieldname` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_top_fields`
--

LOCK TABLES `sqltools_top_fields` WRITE;
/*!40000 ALTER TABLE `sqltools_top_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqltools_top_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_updatesql_list`
--

DROP TABLE IF EXISTS `sqltools_updatesql_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_updatesql_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DBName` varchar(64) NOT NULL,
  `username` varchar(100) NOT NULL,
  `sql` longtext COMMENT '提交的 sql',
  `status` int(11) DEFAULT '0' COMMENT '状态:0 待审批； 1: 审批通过; 2： 审批未通过; 3: 执行中; 4: 执行完成；5：执行失败',
  `retmsg` text COMMENT '执行返回信息',
  `backinfo` text COMMENT '备份信息',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`ID`),
  KEY `idx_username` (`username`),
  KEY `idx_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `idx_DataChange_CreateTime` (`DataChange_CreateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=1529 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_updatesql_list`
--

LOCK TABLES `sqltools_updatesql_list` WRITE;
/*!40000 ALTER TABLE `sqltools_updatesql_list` DISABLE KEYS */;
INSERT INTO `sqltools_updatesql_list` VALUES (1518,'dbtest4','admin','delete from cont where id=11;',5,'sql: delete from cont where id=11 -- 执行失败： Backup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)\nBackup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)\n','sql: use dbtest4 -- None#\'1514338285_2410015_0\'\n','2017-12-27 09:31:06','2017-12-27 01:31:25'),(1519,'dbtest4','admin','delete from cont where id=12;',4,'sql:  -- 执行成功\n','sql: use dbtest4 -- None#\'1514341558_2411226_0\'\nsql: delete from cont where id=12 -- 10_19_159_173_3306_dbtest4#\'1514341558_2411226_1\'\n','2017-12-27 10:25:43','2017-12-27 02:25:58'),(1520,'yonghuimicro','admin','insert into a(id) values(10);',4,'sql:  -- 执行成功\n','sql: use yonghuimicro -- None#\'1514975584_299255_0\'\nsql: insert into a(id) values(10) -- 10_19_44_166_3306_yonghuimicro#\'1514975584_299255_1\'\n','2018-01-03 18:32:45','2018-01-03 10:33:04'),(1521,'yonghuimicro','admin','insert into a(id) values(100);',4,'sql:  -- 执行成功\n','sql: use yonghuimicro -- None#\'1514976395_299290_0\'\nsql: insert into a(id) values(100) -- 10_19_44_166_3306_yonghuimicro#\'1514976395_299290_1\'\n','2018-01-03 18:46:20','2018-01-03 10:46:35'),(1522,'yonghuimicro','admin','insert into a(id) values(111);',4,'sql:  -- 执行成功\n','sql: use yonghuimicro -- None#\'1515034896_299414_0\'\nsql: insert into a(id) values(111) -- 10_19_44_166_3306_yonghuimicro#\'1515034896_299414_1\'\n','2018-01-04 11:01:23','2018-01-04 03:01:36'),(1523,'yonghuimicro','admin','insert into a(id) values(1122);',4,'sql:  -- 执行成功\n','sql: use yonghuimicro -- None#\'1515047325_299439_0\'\nsql: insert into a(id) values(1122) -- 10_19_44_166_3306_yonghuimicro#\'1515047325_299439_1\'\n','2018-01-04 14:28:10','2018-01-04 06:28:45'),(1524,'dbtest4','admin','select * from cont where id=11;',5,'sql: delete from cont where id=11 -- 执行失败： Backup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)\nBackup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)\n','sql: use dbtest4 -- None#\'1514338285_2410015_0\'\n','2017-12-27 09:31:06','2017-12-27 01:31:25'),(1525,'test_partition','admin','insert into b(id) values(2);',4,'sql:  -- 执行成功\n','sql: use test_partition -- None#\'1515740880_187_0\'\nsql: insert into b(id) values(2) -- 10_19_44_166_3306_test_partition#\'1515740880_187_1\'\n','2018-01-12 15:07:24','2018-01-12 07:08:00'),(1526,'test_partition','admin','update a set name=\'aa\' where id=3;',0,'',NULL,'2018-01-18 11:33:59','2018-01-18 03:33:59'),(1527,'test_partition','admin','select * from b;',0,'',NULL,'2018-01-22 16:36:45','2018-01-22 08:36:45'),(1528,'conn','admin','update name set name=10 where id=2;',1,'',NULL,'2018-01-29 14:29:29','2018-01-29 06:29:38');
/*!40000 ALTER TABLE `sqltools_updatesql_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_updatesql_list_20170906`
--

DROP TABLE IF EXISTS `sqltools_updatesql_list_20170906`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_updatesql_list_20170906` (
  `ID` int(11) NOT NULL DEFAULT '0',
  `DBName` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `sql` longtext CHARACTER SET utf8mb4 COMMENT '提交的 sql',
  `status` int(11) DEFAULT '0' COMMENT '状态:0 待审批； 1: 审批通过; 2： 审批未通过; 3: 执行中; 4: 执行完成；5：执行失败',
  `retmsg` text CHARACTER SET utf8mb4 COMMENT '执行返回信息',
  `backinfo` text CHARACTER SET utf8mb4 COMMENT '备份信息',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_updatesql_list_20170906`
--

LOCK TABLES `sqltools_updatesql_list_20170906` WRITE;
/*!40000 ALTER TABLE `sqltools_updatesql_list_20170906` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqltools_updatesql_list_20170906` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_updatesql_list_20171030`
--

DROP TABLE IF EXISTS `sqltools_updatesql_list_20171030`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_updatesql_list_20171030` (
  `ID` int(11) NOT NULL DEFAULT '0',
  `DBName` varchar(64) CHARACTER SET utf8mb4 NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `sql` longtext CHARACTER SET utf8mb4 COMMENT '提交的 sql',
  `status` int(11) DEFAULT '0' COMMENT '状态:0 待审批； 1: 审批通过; 2： 审批未通过; 3: 执行中; 4: 执行完成；5：执行失败',
  `retmsg` text CHARACTER SET utf8mb4 COMMENT '执行返回信息',
  `backinfo` text CHARACTER SET utf8mb4 COMMENT '备份信息',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_updatesql_list_20171030`
--

LOCK TABLES `sqltools_updatesql_list_20171030` WRITE;
/*!40000 ALTER TABLE `sqltools_updatesql_list_20171030` DISABLE KEYS */;
/*!40000 ALTER TABLE `sqltools_updatesql_list_20171030` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_updatesql_log`
--

DROP TABLE IF EXISTS `sqltools_updatesql_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_updatesql_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '对应表  sqltools_updatesql_list 的 ID',
  `DBName` varchar(64) NOT NULL,
  `username` varchar(100) NOT NULL,
  `stage` varchar(128) NOT NULL DEFAULT '' COMMENT '执行步骤: CHECKED、EXECUTED、RERUN、NONE，NONE',
  `errlevel` int(11) DEFAULT '0' COMMENT 'errlevel：返回值为非0的情况下，说明是有错的。1表示警告，不影响执行，2表示严重错误，必须修改',
  `stagestatus` varchar(128) NOT NULL DEFAULT '' COMMENT '检查及执行的过程是成功还是失败: Audit completed / Execute Successfully / Execute failed / Backup successfully / Backup failed',
  `errormessage` text COMMENT '执行返回信息',
  `sql` longtext COMMENT '提交的 sql',
  `affected_rows` int(11) DEFAULT '0' COMMENT '真实影响行数',
  `sequence` varchar(128) NOT NULL DEFAULT '' COMMENT '对应$$Inception_backup_information$$表中的 opid_time 这个列',
  `backup_dbname` varchar(64) NOT NULL DEFAULT '' COMMENT '备份 db 名',
  `execute_time` varchar(24) NOT NULL DEFAULT '' COMMENT '当前语句执行时间，单位为秒，精确到小数点后两位',
  `SQLSHA1` varchar(128) NOT NULL DEFAULT '' COMMENT '标识这个语句是不是会使用OSC功能',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`ID`),
  KEY `idx_username` (`username`),
  KEY `idx_pid` (`pid`),
  KEY `idx_dbname` (`DBName`),
  KEY `idx_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `idx_DataChange_CreateTime` (`DataChange_CreateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=9995 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_updatesql_log`
--

LOCK TABLES `sqltools_updatesql_log` WRITE;
/*!40000 ALTER TABLE `sqltools_updatesql_log` DISABLE KEYS */;
INSERT INTO `sqltools_updatesql_log` VALUES (9981,1518,'dbtest4','admin','RERUN',0,'Execute Successfully','None','use dbtest4',0,'\'1514338285_2410015_0\'','None','0.000','','2017-12-27 09:31:25','2017-12-27 01:31:25'),(9982,1518,'dbtest4','admin','EXECUTED',2,'Execute Successfully\nBackup failed','Backup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)\nBackup: Access denied for user \'m_ince\'@\'localhost\' (using password: YES)','delete from cont where id=11',1,'\'1514338285_2410015_1\'','10_19_159_173_3306_dbtest4','0.000','','2017-12-27 09:31:25','2017-12-27 01:31:25'),(9983,1519,'dbtest4','admin','RERUN',0,'Execute Successfully','None','use dbtest4',0,'\'1514341558_2411226_0\'','None','0.000','','2017-12-27 10:25:58','2017-12-27 02:25:58'),(9984,1519,'dbtest4','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','delete from cont where id=12',1,'\'1514341558_2411226_1\'','10_19_159_173_3306_dbtest4','0.000','','2017-12-27 10:25:58','2017-12-27 02:25:58'),(9985,1520,'yonghuimicro','admin','RERUN',0,'Execute Successfully','None','use yonghuimicro',0,'\'1514975584_299255_0\'','None','0.000','','2018-01-03 18:33:04','2018-01-03 10:33:04'),(9986,1520,'yonghuimicro','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','insert into a(id) values(10)',1,'\'1514975584_299255_1\'','10_19_44_166_3306_yonghuimicro','0.010','','2018-01-03 18:33:04','2018-01-03 10:33:04'),(9987,1521,'yonghuimicro','admin','RERUN',0,'Execute Successfully','None','use yonghuimicro',0,'\'1514976395_299290_0\'','None','0.000','','2018-01-03 18:46:35','2018-01-03 10:46:35'),(9988,1521,'yonghuimicro','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','insert into a(id) values(100)',1,'\'1514976395_299290_1\'','10_19_44_166_3306_yonghuimicro','0.010','','2018-01-03 18:46:35','2018-01-03 10:46:35'),(9989,1522,'yonghuimicro','admin','RERUN',0,'Execute Successfully','None','use yonghuimicro',0,'\'1515034896_299414_0\'','None','0.000','','2018-01-04 11:01:36','2018-01-04 03:01:36'),(9990,1522,'yonghuimicro','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','insert into a(id) values(111)',1,'\'1515034896_299414_1\'','10_19_44_166_3306_yonghuimicro','0.000','','2018-01-04 11:01:36','2018-01-04 03:01:36'),(9991,1523,'yonghuimicro','admin','RERUN',0,'Execute Successfully','None','use yonghuimicro',0,'\'1515047325_299439_0\'','None','0.000','','2018-01-04 14:28:45','2018-01-04 06:28:45'),(9992,1523,'yonghuimicro','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','insert into a(id) values(1122)',1,'\'1515047325_299439_1\'','10_19_44_166_3306_yonghuimicro','0.010','','2018-01-04 14:28:45','2018-01-04 06:28:45'),(9993,1525,'test_partition','admin','RERUN',0,'Execute Successfully','None','use test_partition',0,'\'1515740880_187_0\'','None','0.000','','2018-01-12 15:08:00','2018-01-12 07:08:00'),(9994,1525,'test_partition','admin','EXECUTED',0,'Execute Successfully\nBackup successfully','None','insert into b(id) values(2)',1,'\'1515740880_187_1\'','10_19_44_166_3306_test_partition','0.010','','2018-01-12 15:08:00','2018-01-12 07:08:00');
/*!40000 ALTER TABLE `sqltools_updatesql_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqltools_user_db`
--

DROP TABLE IF EXISTS `sqltools_user_db`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqltools_user_db` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `dbid` int(11) DEFAULT NULL,
  `DBName` varchar(64) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `issupper` varchar(1) NOT NULL DEFAULT '0',
  `iswrite` varchar(1) NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT '0' COMMENT '0: 未审批; 1: 正常; 2: 审批未通过',
  PRIMARY KEY (`ID`),
  KEY `idx_dbname` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=529 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqltools_user_db`
--

LOCK TABLES `sqltools_user_db` WRITE;
/*!40000 ALTER TABLE `sqltools_user_db` DISABLE KEYS */;
INSERT INTO `sqltools_user_db` VALUES (520,26,'dbtest1','test01','aa','','0','1'),(521,39,'test_partition','admin','88888888@vip.com','0','0','0'),(522,39,'test_partition','admin','88888888@vip.com','0','0','0'),(523,39,'test_partition','admin','88888888@vip.com','0','0','0'),(524,39,'test_partition','admin','88888888@vip.com','0','0','0'),(525,40,'conn','admin','88888888@vip.com','0','0','0'),(526,39,'test_partition','test01','aa','0','0','0'),(527,40,'conn','test01','aa','','0','1');
/*!40000 ALTER TABLE `sqltools_user_db` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `syj_rollbackdblist`
--

DROP TABLE IF EXISTS `syj_rollbackdblist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `syj_rollbackdblist` (
  `dbname` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `syj_rollbackdblist`
--

LOCK TABLES `syj_rollbackdblist` WRITE;
/*!40000 ALTER TABLE `syj_rollbackdblist` DISABLE KEYS */;
/*!40000 ALTER TABLE `syj_rollbackdblist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dbnotice`
--

DROP TABLE IF EXISTS `t_dbnotice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dbnotice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `user` varchar(128) DEFAULT NULL,
  `dbname` varchar(128) NOT NULL DEFAULT '',
  `is_read` tinyint(4) DEFAULT '0',
  `type` int(4) DEFAULT '0' COMMENT '0: slow log; 1: big sql;',
  `title` varchar(800) DEFAULT '',
  `content` longtext,
  `news_url` varchar(3000) DEFAULT NULL,
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`id`),
  KEY `idx_user_dbname` (`user`,`dbname`),
  KEY `idx_dbname` (`dbname`),
  KEY `idx_user_is_read` (`user`,`is_read`),
  KEY `idx_title` (`title`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dbnotice`
--

LOCK TABLES `t_dbnotice` WRITE;
/*!40000 ALTER TABLE `t_dbnotice` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dbnotice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dbuser`
--

DROP TABLE IF EXISTS `t_dbuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dbuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `user` varchar(128) DEFAULT NULL,
  `host` varchar(128) DEFAULT NULL,
  `dbname` varchar(128) NOT NULL DEFAULT '',
  `envt` varchar(128) NOT NULL DEFAULT 'dev' COMMENT '环境类型: dev / fat / lpt / uat',
  `granttype` varchar(12) DEFAULT 'DML' COMMENT '权限类型: DDL / DML',
  `grants` varchar(512) DEFAULT NULL COMMENT '详细权限',
  `remark` varchar(512) NOT NULL DEFAULT '备用',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  KEY `idx_id` (`id`),
  KEY `idx_user` (`user`),
  KEY `idx_user_host` (`user`,`host`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dbuser`
--

LOCK TABLES `t_dbuser` WRITE;
/*!40000 ALTER TABLE `t_dbuser` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_dbuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_mydb`
--

DROP TABLE IF EXISTS `t_mydb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_mydb` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `user` varchar(128) DEFAULT NULL,
  `dbname` varchar(128) NOT NULL DEFAULT '',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idxunique_user_dbname` (`user`,`dbname`),
  KEY `idx_dbname` (`dbname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_mydb`
--

LOCK TABLES `t_mydb` WRITE;
/*!40000 ALTER TABLE `t_mydb` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_mydb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_userinfo`
--

DROP TABLE IF EXISTS `t_userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_userinfo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `username` varchar(128) DEFAULT NULL,
  `host` varchar(128) DEFAULT NULL,
  `dbuser` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `orginfo` varchar(128) NOT NULL DEFAULT '',
  `envt` varchar(128) NOT NULL DEFAULT 'dev' COMMENT '环境类型: dev / fat / lpt / uat',
  `DataChange_CreateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `DataChange_LastTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '编辑时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`username`),
  KEY `idx_DataChange_LastTime` (`DataChange_LastTime`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_userinfo`
--

LOCK TABLES `t_userinfo` WRITE;
/*!40000 ALTER TABLE `t_userinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp_dbowner`
--

DROP TABLE IF EXISTS `temp_dbowner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp_dbowner` (
  `dbuser` char(20) DEFAULT NULL,
  `dbname` char(30) DEFAULT NULL,
  `owner` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp_dbowner`
--

LOCK TABLES `temp_dbowner` WRITE;
/*!40000 ALTER TABLE `temp_dbowner` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_dbowner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `totalbackupinfo`
--

DROP TABLE IF EXISTS `totalbackupinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `totalbackupinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(128) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `backuptype` varchar(20) DEFAULT NULL,
  `filename` varchar(128) DEFAULT NULL,
  `filesize` varchar(128) DEFAULT NULL,
  `backup_start_time` datetime DEFAULT NULL,
  `backup_end_time` datetime DEFAULT NULL,
  `tar_end_time` datetime DEFAULT NULL,
  `ftp_end_time` datetime DEFAULT NULL,
  `retry` tinyint(4) DEFAULT '0',
  `success` char(1) DEFAULT 'F',
  PRIMARY KEY (`id`),
  KEY `idx_ip_machine_name` (`ip`,`machine_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `totalbackupinfo`
--

LOCK TABLES `totalbackupinfo` WRITE;
/*!40000 ALTER TABLE `totalbackupinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `totalbackupinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_etl_conninfo`
--

DROP TABLE IF EXISTS `v_etl_conninfo`;
/*!50001 DROP VIEW IF EXISTS `v_etl_conninfo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_etl_conninfo` AS SELECT 
 1 AS `dbname`,
 1 AS `host`,
 1 AS `port`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `xtrabackup_restore_to_sqlreview_setting`
--

DROP TABLE IF EXISTS `xtrabackup_restore_to_sqlreview_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xtrabackup_restore_to_sqlreview_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `cluster_name` varchar(25) NOT NULL COMMENT '要还原服务器的集群名',
  `reviewServer_hostname` varchar(20) NOT NULL COMMENT 'review服务器的hostname',
  `reviewServer_cluster_port` int(11) NOT NULL COMMENT 'review服务器上被还原的mysql实例的端口号，切记不要与已有的端口冲突',
  `priority` tinyint(4) DEFAULT '1' COMMENT '备份文件被还原的优先级,默认为1,数字越大优先级越低。',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '该机器被还原的状态：-1:disabled, 0:waiting, 1:ready, 2:restoring',
  `last_success_time` datetime NOT NULL DEFAULT '2016-01-01 00:00:00' COMMENT '最后一次还原成功的时间',
  `last_backup_begin_time` datetime NOT NULL DEFAULT '2016-01-01 00:00:00' COMMENT '最后一次还原成功的备份对应的备份开始时间',
  `innodb_buffer_pool_size` varchar(20) DEFAULT '500M' COMMENT '在review环境中数据库实例的innodb_buffer_pool_size',
  `restore_interval_days` tinyint(4) DEFAULT '1' COMMENT '还原频率，按天计算',
  `netdisk` varchar(50) DEFAULT NULL COMMENT '要还原的集群的slave上挂载的磁盘柜信息',
  `failures` tinyint(4) DEFAULT '0' COMMENT '失败次数',
  `review_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否进行review:0:表示不进行,1:表示进行',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_reviewServer_hostname_port` (`reviewServer_hostname`,`reviewServer_cluster_port`),
  KEY `idx_last_success_time` (`last_success_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xtrabackup_restore_to_sqlreview_setting`
--

LOCK TABLES `xtrabackup_restore_to_sqlreview_setting` WRITE;
/*!40000 ALTER TABLE `xtrabackup_restore_to_sqlreview_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `xtrabackup_restore_to_sqlreview_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yy_xtrabackup_machine`
--

DROP TABLE IF EXISTS `yy_xtrabackup_machine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yy_xtrabackup_machine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `machine_name` varchar(100) DEFAULT NULL,
  `is_xtra` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yy_xtrabackup_machine`
--

LOCK TABLES `yy_xtrabackup_machine` WRITE;
/*!40000 ALTER TABLE `yy_xtrabackup_machine` DISABLE KEYS */;
/*!40000 ALTER TABLE `yy_xtrabackup_machine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `v_etl_conninfo`
--

/*!50001 DROP VIEW IF EXISTS `v_etl_conninfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_etl_conninfo` AS select 1 AS `dbname`,1 AS `host`,1 AS `port` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-02 14:32:21
