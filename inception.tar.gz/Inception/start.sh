#!/bin/bash
inception-master/debug/mysql/bin/Inception --defaults-file=/etc/inc.cnf
